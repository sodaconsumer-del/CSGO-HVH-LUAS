﻿--by scriptleaks https://discord.gg/n4DpEunxbj t.me/scriptleakslol

if not ws.TestCapability("fs") then
	gui.notify:add(gui.notification("Femtality", "Requires FileSystem access!"))
	error("Requires FileSystem")
end

if not ws.TestCapability("ffi") then
	gui.notify:add(gui.notification("Femtality", "Requires FFI access!"))
	error("Requires FFI")
end

slot_0_0_0 = "fatality/Femtality/"

-- if ws.GetItemID() ~= 0 then
-- 	slot_0_0_0 = ws.GetResourceDir() .. "/"
-- end

slot_0_1_0 = draw.Texture(slot_0_0_0 .. "boykisser-smol.png")

slot_0_1_0:Create()

slot_0_2_0 = draw.Texture(slot_0_0_0 .. "pointing.png")

slot_0_2_0:Create()

slot_0_3_0 = draw.Texture(slot_0_0_0 .. "boykisser_open.png")

slot_0_3_0:Create()

slot_0_5_0 = gui.GetMainWindow():AddTab("fbTab", slot_0_1_0, "Femtality", gui.TabLayoutMode.DEFAULT)
slot_0_6_0 = gui.Group("fbRage", "Rage", 330)
slot_0_7_0 = gui.Group("fbMisc", "Misc", 330)

slot_0_5_0:Add(slot_0_6_0)
slot_0_5_0:Add(slot_0_7_0)

slot_0_8_0, slot_0_9_0 = gui.MakeControlEasy("niaEnable", "No Idle Animations", "Checkbox")
slot_0_10_0, slot_0_11_0 = gui.MakeControlEasy("moAnimate", "Animation", "Checkbox")
slot_0_12_0 = gui.Settings("moAnimateSettings")
slot_0_13_0, slot_0_14_0 = gui.MakeControlEasy("moAnimSpeed", "Speed", "Slider", 50, 250, {
	"%.0f%%"
})

slot_0_12_0:Add(slot_0_14_0)
slot_0_11_0:Add(slot_0_12_0)

slot_0_15_0, slot_0_16_0 = gui.MakeControlEasy("moLabel", "This MO is instant compared to\n fatality:s normal MO >:3", "Label")
slot_0_17_0, slot_0_18_0 = gui.MakeControlEasy("moCheckbox", "Mouse Override", "Checkbox")
slot_0_19_0, slot_0_20_0 = gui.MakeControlEasy("moSensitivity", "Sensitivity", "Slider", 35, 175, {
	"%.0f%%"
})
slot_0_21_0, slot_0_22_0 = gui.MakeControlEasy("moSize", "Dot Size", "Slider", 50, 250, {
	"%.0f%%"
})
slot_0_23_0, slot_0_24_0 = gui.MakeControlEasy("moAntiExtrapCheckbox", "Anti Extrap", "Checkbox")
slot_0_25_0 = gui.ColorPicker("moActiveClr", "Active Color")
slot_0_25_0.tooltip = "Active"
slot_0_26_0 = gui.ColorPicker("moInActiveClr", "Inactive Color")
slot_0_26_0.tooltip = "Inactive"
slot_0_27_0 = gui.Settings("moSettings")
slot_0_28_0, slot_0_29_0 = gui.MakeControlEasy("moStyleCombo", "Style", "ComboBox")

slot_0_28_0:Add(gui.Selectable("moStylePill", "Pill"))
slot_0_28_0:Add(gui.Selectable("moStyleGlow", "Glow Dot"))
slot_0_28_0:Add(gui.Selectable("moStyleMeow", "Meow"))
slot_0_28_0:Add(gui.Selectable("moStyleBoykisser", "Boykisser"))
slot_0_18_0:Add(slot_0_25_0)
slot_0_18_0:Add(slot_0_26_0)
slot_0_27_0:Add(slot_0_20_0)
slot_0_27_0:Add(slot_0_22_0)
slot_0_27_0:Add(slot_0_29_0)
slot_0_27_0:Add(slot_0_11_0)
slot_0_27_0:Add(slot_0_24_0)
slot_0_18_0:Add(slot_0_27_0)

slot_0_30_0, slot_0_31_0 = gui.MakeControlEasy("aaSpin", "Funny Spin :3", "Checkbox")
slot_0_32_0, slot_0_33_0 = gui.MakeControlEasy("aaSpinPitch", "Pitch", "Slider", -89, 89, {
	"%.0f°"
})
slot_0_34_0 = gui.Settings("aaSpinSettings")

slot_0_34_0:Add(slot_0_33_0)
slot_0_31_0:Add(slot_0_34_0)
slot_0_28_0:AddCallback(function()
	if not slot_0_28_0:GetValue():Get():Get(0) then
		slot_0_11_0.inactive = true
	else
		slot_0_11_0.inactive = false
	end
end)

if slot_0_19_0:GetValue():Get() == 0 then
	slot_0_19_0:GetValue():Set(100)
end

if slot_0_21_0:GetValue():Get() == 0 then
	slot_0_21_0:GetValue():Set(100)
end

if slot_0_25_0:GetValue():Get():RGBA() == 0 then
	slot_0_25_0:GetValue():Set(draw.Color(243, 199, 205, 255))
end

if slot_0_26_0:GetValue():Get():RGBA() == 0 then
	slot_0_26_0:GetValue():Set(draw.Color(255, 0, 0, 255))
end

if slot_0_13_0:Get() == 0 then
	slot_0_13_0:GetValue():Set(100)
end

slot_0_35_1 = slot_0_28_0:GetValue():Get()

if not slot_0_35_1:Get(0) and not slot_0_35_1:Get(1) and not slot_0_35_1:Get(2) and not slot_0_35_1:Get(3) then
	slot_0_35_1:Set(0)
	slot_0_35_1:Unset(1)
	slot_0_35_1:Unset(2)
	slot_0_35_1:Unset(3)
	slot_0_28_0:GetValue():Set(slot_0_35_1)
end

slot_0_35_0, slot_0_36_0 = gui.MakeControlEasy("olEnable", "On-Land AutoStop", "Checkbox")
slot_0_37_0, slot_0_38_0 = gui.MakeControlEasy("olPredict", "Prediction", "Slider", 0, 14, {
	{
		fmt = "%.0ft",
		min = 1
	},
	{
		fmt = "Off",
		min = 0
	}
}, 1)
slot_0_39_0, slot_0_40_0 = gui.MakeControlEasy("olHitboxes", "Hitboxes", "ComboBox")
slot_0_39_0.allowMultiple = true

slot_0_39_0:Add(gui.Selectable("olHead", "Head"))
slot_0_39_0:Add(gui.Selectable("olChest", "Chest"))
slot_0_39_0:Add(gui.Selectable("olStomach", "Stomach"))
slot_0_39_0:Add(gui.Selectable("olArms", "Arms"))
slot_0_39_0:Add(gui.Selectable("olLegs", "Legs"))
slot_0_39_0:Add(gui.Selectable("olFeet", "Feet"))

slot_0_41_0 = gui.Settings("hmSettings")

slot_0_41_0:Add(slot_0_38_0)
slot_0_41_0:Add(slot_0_40_0)
slot_0_36_0:Add(slot_0_41_0)

slot_0_42_0, slot_0_43_0 = gui.MakeControlEasy("iaEnable", "In-Air Overrides (SSG-08)", "Checkbox")
slot_0_44_0, slot_0_45_0 = gui.MakeControlEasy("iaHCSlider", "Air HC", "Slider", 0, 100, {
	"%.0f%%",
	1
})
slot_0_46_0, slot_0_47_0 = gui.MakeControlEasy("iaHCGroundSlider", "Ground HC", "Slider", 0, 100, {
	"%.0f%%",
	1
})
slot_0_48_0, slot_0_49_0 = gui.MakeControlEasy("iaPSSlider", "Air PS", "Slider", 0, 100, {
	"%.0f%%",
	1
})
slot_0_50_0, slot_0_51_0 = gui.MakeControlEasy("iaPSGroundSlider", "Ground PS", "Slider", 0, 100, {
	"%.0f%%",
	1
})
slot_0_52_0 = gui.Settings("iaSettings")

slot_0_52_0:Add(slot_0_47_0)
slot_0_52_0:Add(slot_0_51_0)
slot_0_52_0:Add(slot_0_45_0)
slot_0_52_0:Add(slot_0_49_0)
slot_0_43_0:Add(slot_0_52_0)

slot_0_53_0, slot_0_54_0 = gui.MakeControlEasy("dtkEnable", "DT On Knife", "Checkbox")

slot_0_6_0:Add(slot_0_9_0)
slot_0_6_0:Add(slot_0_18_0)
slot_0_6_0:Add(slot_0_31_0)
slot_0_6_0:Add(slot_0_36_0)
slot_0_6_0:Add(slot_0_43_0)
slot_0_6_0:Add(slot_0_54_0)
slot_0_6_0:Reset()

slot_0_55_0, slot_0_56_0 = gui.MakeControlEasy("lhkEnable", "Left Handed Knife", "Checkbox")
slot_0_57_0, slot_0_58_0 = gui.MakeControlEasy("hmEnable", "World Hitmarker", "Checkbox")
slot_0_59_0, slot_0_60_0 = gui.MakeControlEasy("hmRenderTime", "Render Time", "Slider", 0.1, 5, {
	"%.2fs"
}, 0.01)
slot_0_61_0 = gui.ColorPicker("hmColor", "Color")
slot_0_62_0 = gui.Settings("hmSettings")

slot_0_62_0:Add(slot_0_60_0)
slot_0_58_0:Add(slot_0_61_0)
slot_0_58_0:Add(slot_0_62_0)

slot_0_63_0, slot_0_64_0 = gui.MakeControlEasy("ciStylePicker", "Style", "ComboBox")

slot_0_63_0:Add(gui.Selectable("ciStyleFatality", "Fatality"))
slot_0_63_0:Add(gui.Selectable("ciStyleCustom", "Custom"))
slot_0_63_0:Add(gui.Selectable("ciStyleCustomSmall", "Custom-Small"))

slot_0_65_0, slot_0_66_0 = gui.MakeControlEasy("ciFeaturesCombo", "Features", "ComboBox")
slot_0_65_0.allowMultiple = true

slot_0_65_0:Add(gui.Selectable("ciMD", "Min Damage"))
slot_0_65_0:Add(gui.Selectable("ciHC", "Hit Chance"))
slot_0_65_0:Add(gui.Selectable("ciFS", "Force Shoot"))
slot_0_65_0:Add(gui.Selectable("ciSlowed", "Slowed"))
slot_0_65_0:Add(gui.Selectable("ciDP", "Duck Peek"))
slot_0_65_0:Add(gui.Selectable("ciOverrides", "Manual Anti-Aim"))

slot_0_67_0, slot_0_68_0 = gui.MakeControlEasy("ciEnable", "Crosshair Indicators", "Checkbox")
slot_0_69_0 = gui.ColorPicker("ciActiveColor", true)
slot_0_69_0.tooltip = "Active"
slot_0_70_0 = gui.ColorPicker("ciInactiveColor", true)
slot_0_70_0.tooltip = "Inactive"
slot_0_71_0, slot_0_72_0 = gui.MakeControlEasy("ciTitleColor", "Title Color", "ColorPicker", true)

slot_0_68_0:Add(slot_0_69_0)
slot_0_68_0:Add(slot_0_70_0)

slot_0_73_0 = gui.Settings("ciSettings")

slot_0_73_0:Add(slot_0_64_0)
slot_0_73_0:Add(slot_0_66_0)
slot_0_73_0:Add(slot_0_72_0)
slot_0_68_0:Add(slot_0_73_0)

if slot_0_69_0:GetValue():Get():RGBA() == 0 then
	slot_0_69_0:GetValue():Set(draw.Color(239, 149, 255, 255))
end

if slot_0_70_0:GetValue():Get():RGBA() == 0 then
	slot_0_70_0:GetValue():Set(draw.Color(255, 255, 255, 255))
end

if slot_0_71_0:GetValue():Get():RGBA() == 0 then
	slot_0_71_0:GetValue():Set(draw.Color(239, 149, 255, 255))
end

slot_0_74_0, slot_0_75_0 = gui.MakeControlEasy("qsEnable", "Quick Switch", "Checkbox")
slot_0_76_0 = gui.ComboBox("qsCombo")

slot_0_76_0:Add(gui.Selectable("qsPrimary", "Primary"))
slot_0_76_0:Add(gui.Selectable("qsSecondary", "Secondary"))
slot_0_75_0:Add(slot_0_76_0)

slot_0_77_0, slot_0_78_0 = gui.MakeControlEasy("ngEnable", "Net Graph", "Checkbox")
slot_0_79_0 = gui.Checkbox("ngBigFont")

slot_0_78_0:Add(slot_0_79_0)

slot_0_80_0, slot_0_81_0 = gui.MakeControlEasy("rwuEnable", "Remove Warmup Notification", "Checkbox")
slot_0_82_0, slot_0_83_0 = gui.MakeControlEasy("fstLEnable", "Fast Ladder", "Checkbox")
slot_0_84_0, slot_0_85_0 = gui.MakeControlEasy("freeOnShotLEnable", "Pull Knife On Shot (pls hs me :3)", "Checkbox")
slot_0_86_0, slot_0_87_0 = gui.MakeControlEasy("nsEnable", "Prevent Ramp Boost", "Checkbox")
slot_0_88_0, slot_0_89_0 = gui.MakeControlEasy("adEnable", "Air-Duck", "Checkbox")
slot_0_90_0, slot_0_91_0 = gui.MakeControlEasy("ciKillEffect", "Kill Effects", "ComboBox")
slot_0_90_0.allowMultiple = true

slot_0_90_0:Add(gui.Selectable("keFire", "Fire"))
slot_0_90_0:Add(gui.Selectable("keFeather", "Feathers"))
slot_0_90_0:Add(gui.Selectable("keChickenSpawner", "CHICKEN SPAWNER"))
slot_0_90_0:Add(gui.Selectable("keTaser", "Taser"))
slot_0_90_0:Add(gui.Selectable("keSparks", "Sparks :|"))
slot_0_80_0:AddCallback(function()
	if slot_0_80_0:Get() then
		panorama.Eval("            (function() {\n                var ctx = $.GetContextPanel()\n                if (ctx.rwuWatcher) return\n\n                ctx.rwuWatcher = true\n\n                var watch = function() {\n                    if (!ctx.rwuWatcher) return\n\n                    var panel = $.FindChildInContext('#HudAlerts')\n                    if (panel) {\n                        var label = panel.FindChildTraverse('AlertText')\n                        if (label && label.text.includes('Warmup')) {\n                            panel.style.visibility = 'collapse'\n                        }\n                    }\n\n                    $.Schedule(0.5, watch)\n                }\n\n                watch()\n            })()\n        ", "CSGOHud")
	else
		panorama.Eval("            (function() {\n                $.GetContextPanel().rwuWatcher = false\n            })()\n        ", "CSGOHud")
	end
end)

if slot_0_61_0:GetValue():Get():RGBA() == 0 then
	slot_0_61_0:GetValue():Set(draw.Color(243, 199, 205, 255))
end

slot_0_92_1 = slot_0_76_0:GetValue():Get()

if not slot_0_92_1:Get(0) and not slot_0_92_1:Get(1) then
	slot_0_92_1:Set(0)
	slot_0_92_1:Unset(1)
	slot_0_76_0:GetValue():Set(slot_0_92_1)
end

if slot_0_92_1:Get(0) and slot_0_92_1:Get(1) then
	slot_0_92_1:Set(0)
	slot_0_92_1:Unset(1)
	slot_0_76_0:GetValue():Set(slot_0_92_1)
end

slot_0_7_0:Add(slot_0_56_0)
slot_0_7_0:Add(slot_0_58_0)
slot_0_7_0:Add(slot_0_68_0)
slot_0_7_0:Add(slot_0_75_0)
slot_0_7_0:Add(slot_0_78_0)
slot_0_7_0:Add(slot_0_81_0)
slot_0_7_0:Add(slot_0_83_0)
slot_0_7_0:Add(slot_0_85_0)
slot_0_7_0:Add(slot_0_87_0)
slot_0_7_0:Add(slot_0_89_0)
slot_0_7_0:Add(slot_0_91_0)
slot_0_7_0:Reset()

slot_0_92_0 = gui.ctx:Find("rage>anti-aim>angles>yaw>settings>amount")
slot_0_93_0 = gui.ctx:Find("rage>anti-aim>angles>yaw")
slot_0_94_0 = gui.ctx:Find("rage>anti-aim>angles>yaw base")
slot_0_95_0 = gui.ctx:Find("rage>anti-aim>angles>pitch")
slot_0_96_0 = gui.ctx:Find("rage>anti-aim>angles>pitch>settings>value")
slot_0_97_0 = {}
slot_0_98_2 = slot_0_92_0:Get()
slot_0_99_3 = slot_0_93_0:GetValue():Get()
slot_0_100_3 = slot_0_94_0:GetValue():Get()
slot_0_101_2 = slot_0_95_0:GetValue():Get()
slot_0_102_3 = gui.ctx:Find("rage>anti-aim>angles")

function slot_0_97_0.run()
	game.engine:ClientCmd("switchhandsright")
	slot_0_92_0:GetValue():Set(slot_0_98_2)
	slot_0_93_0:GetValue():Set(slot_0_99_3)
	slot_0_94_0:GetValue():Set(slot_0_100_3)
	slot_0_95_0:GetValue():Set(slot_0_95_0)
	slot_0_102_3:Reset()
	gui.notify:add(gui.notification("Femtality", "Restored anti-aim settings"))
end

slot_0_92_0:GetValue():Set(180)

slot_0_98_1 = slot_0_93_0:GetValue():Get()

slot_0_98_1:Unset(0)
slot_0_98_1:Unset(1)
slot_0_98_1:Set(2)
slot_0_93_0:GetValue():Set(slot_0_98_1)

slot_0_99_2 = slot_0_94_0:GetValue():Get()

slot_0_99_2:Unset(0)
slot_0_99_2:Set(1)
slot_0_94_0:GetValue():Set(slot_0_99_2)

slot_0_100_2 = slot_0_95_0:GetValue():Get()

slot_0_100_2:Unset(0)
slot_0_100_2:Unset(1)
slot_0_100_2:Unset(2)
slot_0_100_2:Unset(3)
slot_0_100_2:Set(4)
slot_0_95_0:GetValue():Set(slot_0_100_2)
slot_0_96_0:GetValue():Set(89)
gui.notify:add(gui.notification("Femtality", gui.ctx:Find("rage>anti-aim>angles>mouse override"):HasHotkeys() and "Changed regular AA settings to allow custom mouse override, MAKE SURE TO UNBIND NORMAL MOUSE OVERRIDE" or "Changed regular AA settings to allow custom mouse override :3"))

function __shutdown()
	slot_0_97_0.run()
end

slot_0_98_0 = {}
slot_0_99_1 = 0

function slot_0_98_0.run(arg_5_0)
	local var_5_0 = arg_5_0:GetActiveWeapon()

	if var_5_0 == nil then
		return
	end

	local var_5_1 = var_5_0:GetType()

	if slot_0_99_1 == var_5_1 then
		return
	end

	if var_5_1 == 0 then
		game.engine:ClientCmd("switchhandsleft")
	else
		game.engine:ClientCmd("switchhandsright")
	end

	slot_0_99_1 = var_5_1
end

slot_0_99_0 = {}
slot_0_100_1 = false

function slot_0_99_0.isActive(arg_6_0)
	local var_6_0 = arg_6_0:GetActiveWeapon()

	if not var_6_0 then
		return false
	end

	if var_6_0:GetDefIndex() ~= EItemDefinitionIndex.SSG08 then
		return false
	end

	return slot_0_100_1
end

function slot_0_99_0.run(arg_7_0, arg_7_1)
	if not arg_7_1:IsAlive() then
		return
	end

	local var_7_0 = arg_7_1.m_fFlags:Get()
	local var_7_1 = bit.band(var_7_0, bit.lshift(1, 0)) ~= 0
	local var_7_2 = gui.ctx:Find("rage>weapon>SSG-08>weapon>hitchance")
	local var_7_3 = gui.ctx:Find("rage>weapon>SSG-08>weapon>pointscale")

	if not var_7_2 or not var_7_3 then
		return
	end

	local var_7_4 = arg_7_1.m_vecAbsVelocity:Get()
	local var_7_5 = not var_7_1 and (math.abs(var_7_4.z) < 10 or var_7_4.z > 5)

	if var_7_5 then
		var_7_2:GetValue():Set(slot_0_44_0:Get())
		var_7_3:GetValue():Set(slot_0_48_0:Get())

		slot_0_100_1 = true
	end

	if not var_7_5 and slot_0_100_1 then
		var_7_2:GetValue():Set(slot_0_46_0:Get())
		var_7_3:GetValue():Set(slot_0_50_0:Get())

		slot_0_100_1 = false
	end
end

slot_0_100_0 = {}
slot_0_101_1 = 0
slot_0_102_2 = 0
slot_0_103_3 = 14
slot_0_104_4 = 14
slot_0_105_4 = 0
slot_0_106_4 = false
slot_0_107_4 = 0
slot_0_108_5 = gui.ctx:Find("misc>movement>duck peek assist")
slot_0_109_6 = gui.ctx:Find("rage>aimbot>general>force shoot")
slot_0_110_5 = gui.ctx:Find("rage>anti-aim>angles>manual override>override left")
slot_0_111_4 = gui.ctx:Find("rage>anti-aim>angles>manual override>override right")
slot_0_112_4 = gui.ctx:Find("rage>anti-aim>angles>manual override>override back")
slot_0_113_4 = gui.ctx:Find("rage>anti-aim>angles>manual override>override forward")

slot_0_63_0:AddCallback(function()
	local var_8_0 = slot_0_63_0:GetValue():Get()

	if var_8_0:Get(0) then
		slot_0_107_4 = 0
		slot_0_72_0.inactive = true
	end

	if var_8_0:Get(1) then
		slot_0_106_4 = false
		slot_0_107_4 = 1
		slot_0_72_0.inactive = false
	end

	if var_8_0:Get(2) then
		slot_0_106_4 = true
		slot_0_107_4 = 1
		slot_0_72_0.inactive = false
	end
end)

function slot_0_114_3(arg_9_0, arg_9_1, arg_9_2)
	local var_9_0 = draw.surface

	var_9_0.font = slot_0_106_4 and draw.fonts.esp or draw.fonts.gui_bold

	local var_9_1 = slot_0_106_4 and 1 or draw.GetScale()
	local var_9_2 = arg_9_1 and slot_0_69_0:Get() or slot_0_70_0:Get()
	local var_9_3 = var_9_0.font:GetTextSize(arg_9_0, false) * var_9_1
	local var_9_4 = 1 - slot_0_102_2 / slot_0_103_3

	var_9_0:AddText(arg_9_2 + draw.Vec2((slot_0_106_4 and 3 or 0) + -var_9_3.x / 2 * var_9_4, slot_0_104_4 * var_9_1 * slot_0_101_1), arg_9_0, var_9_2)

	slot_0_101_1 = slot_0_101_1 + 1
end

function slot_0_115_2(arg_10_0, arg_10_1, arg_10_2)
	slot_10_3_0 = draw.surface
	slot_10_3_0.font = slot_0_106_4 and draw.fonts.gui_bold or draw.fonts.gui_title
	slot_10_4_0 = draw.GetScale()
	slot_10_5_0 = slot_0_71_0:Get()
	slot_10_6_0 = #arg_10_0
	slot_10_7_0 = 0.75
	slot_10_8_0 = 1.5
	slot_10_9_0 = 4
	slot_10_10_0 = 1.5
	slot_10_11_0 = slot_10_3_0.font:GetTextSize(arg_10_0, false) * slot_10_4_0
	slot_10_12_0 = 1 - slot_0_102_2 / slot_0_103_3
	slot_10_13_0 = arg_10_2 + draw.Vec2(-slot_10_11_0.x / 2 * slot_10_12_0, slot_0_104_4 * slot_10_4_0 * slot_0_101_1)
	slot_10_3_0.font = draw.fonts.gui_bold
	slot_10_14_0 = 10
	slot_10_15_0 = {
		"*",
		"+",
		".",
		"*"
	}

	for iter_10_0 = 1, slot_10_14_0 do
		slot_10_20_1 = iter_10_0 * 7.3
		slot_10_21_1 = slot_0_105_4 * 1.8 + slot_10_20_1
		slot_10_22_1 = math.sin(slot_10_21_1 * 0.7) * (slot_10_11_0.x * 0.55) + math.cos(slot_10_21_1 * 0.3 + slot_10_20_1) * 6
		slot_10_23_1 = math.cos(slot_10_21_1 * 0.9 + slot_10_20_1) * (slot_10_11_0.y * 0.9) + math.sin(slot_10_21_1 * 1.1) * 3
		slot_10_24_1 = ((math.sin(slot_10_21_1 * 2.5) + 1) * 0.5)^4
		slot_10_25_1 = math.floor(255 * slot_10_24_1 + 0.5)

		if slot_10_25_1 > 5 then
			slot_10_26_1 = slot_10_15_0[(iter_10_0 - 1) % #slot_10_15_0 + 1]
			slot_10_27_1 = iter_10_0 % 2 == 0
			slot_10_28_1 = slot_10_27_1 and 255 or 255
			slot_10_29_0 = slot_10_27_1 and 255 or 217
			slot_10_30_0 = slot_10_27_1 and 255 or 245
			slot_10_31_0 = slot_10_3_0.font:GetTextSize(slot_10_26_1, false) * slot_10_4_0

			slot_10_3_0:AddText(slot_10_13_0 + draw.Vec2(slot_10_11_0.x / 2 + slot_10_22_1 - slot_10_31_0.x / 2, slot_10_11_0.y / 2 + slot_10_23_1 - slot_10_31_0.y / 2), slot_10_26_1, draw.Color(slot_10_28_1, slot_10_29_0, slot_10_30_0, slot_10_25_1))
		end
	end

	slot_10_3_0.font = slot_0_106_4 and draw.fonts.gui_bold or draw.fonts.gui_title
	slot_10_16_0 = 0

	for iter_10_1 = 1, slot_10_6_0 do
		slot_10_21_0 = arg_10_0:sub(iter_10_1, iter_10_1)
		slot_10_22_0 = slot_10_6_0 > 1 and (iter_10_1 - 1) / (slot_10_6_0 - 1) or 0
		slot_10_23_0 = (slot_10_22_0 - slot_0_105_4 * slot_10_7_0) % 1
		slot_10_24_0 = slot_10_23_0 < 0.5 and slot_10_23_0 * 2 or (1 - slot_10_23_0) * 2
		slot_10_25_0 = math.floor(slot_10_5_0:GetR() + (255 - slot_10_5_0:GetR()) * slot_10_24_0 + 0.5)
		slot_10_26_0 = math.floor(slot_10_5_0:GetG() + (255 - slot_10_5_0:GetG()) * slot_10_24_0 + 0.5)
		slot_10_27_0 = math.floor(slot_10_5_0:GetB() + (255 - slot_10_5_0:GetB()) * slot_10_24_0 + 0.5)
		slot_10_28_0 = math.sin(slot_0_105_4 * slot_10_9_0 - slot_10_22_0 * slot_10_10_0 * math.pi * 2) * slot_10_8_0

		slot_10_3_0:AddText(slot_10_13_0 + draw.Vec2(slot_10_16_0, slot_10_28_0), slot_10_21_0, draw.Color(slot_10_25_0, slot_10_26_0, slot_10_27_0, 255))

		slot_10_16_0 = slot_10_16_0 + (slot_10_3_0.font:GetTextSize(slot_10_21_0, false) * slot_10_4_0).x
	end

	slot_0_101_1 = slot_0_101_1 + 1
end

function slot_0_116_2(arg_11_0)
	slot_11_1_0 = arg_11_0.m_bIsScoped:Get()
	slot_0_104_4 = slot_0_106_4 and 9 or 14
	slot_11_2_0 = game.globalVars.m_flRenderFrameTime
	slot_0_105_4 = slot_0_105_4 + slot_11_2_0
	slot_11_3_0 = slot_11_1_0 and slot_0_103_3 or 0
	slot_11_4_0 = 12
	slot_0_102_2 = slot_0_102_2 + (slot_11_3_0 - slot_0_102_2) * (1 - math.exp(-slot_11_4_0 * slot_11_2_0))

	if math.abs(slot_11_3_0 - slot_0_102_2) < 0.05 then
		slot_0_102_2 = slot_11_3_0
	end

	draw.surface.font = draw.fonts.esp
	slot_11_6_0 = draw.GetScale()
	slot_11_8_0 = draw.GetDisplay() / 2 + draw.Vec2(slot_0_102_2, 14)

	slot_0_115_2("femtality", false, slot_11_8_0 - draw.Vec2(0, slot_0_104_4 / 2 * slot_11_6_0))

	slot_11_9_0 = arg_11_0.m_flVelocityModifier:Get()

	if slot_11_9_0 < 1 and slot_0_65_0:Get():Get(3) then
		slot_11_10_1 = string.format("SLOWED %.0f%%", (1 - slot_11_9_0) * 100)

		slot_0_114_3(slot_11_10_1, true, slot_11_8_0)
	end

	slot_11_10_0 = gui.GetActiveOverridePath()

	if not slot_11_10_0 then
		return
	end

	slot_11_11_0 = gui.ctx:Find(slot_11_10_0 .. ">weapon>hitchance")
	slot_11_12_0 = gui.ctx:Find(slot_11_10_0 .. ">weapon>mindamage")

	if slot_0_65_0:Get():Get(0) and slot_11_12_0 then
		slot_11_13_1 = slot_11_12_0:Get()
		slot_11_14_1 = slot_11_13_1 > 100 and string.format("MD: HP+%d", slot_11_13_1 - 100) or string.format("MD: %d", slot_11_13_1)

		if slot_11_13_1 == 0 then
			slot_11_14_1 = "MD: LETHAL"
		end

		slot_0_114_3(slot_11_14_1, slot_11_12_0:GetValue():GetHotkeyState(), slot_11_8_0)
	end

	if slot_0_65_0:Get():Get(1) and slot_11_11_0 then
		slot_11_13_0 = slot_11_11_0:Get()
		slot_11_14_0 = slot_0_99_0.isActive(arg_11_0) and "HC AIR" or slot_11_13_0 > 40 and "HC" or "HC LOW"

		if slot_11_13_0 == -1 then
			slot_11_14_0 = "HC AUTO"
		end

		slot_0_114_3(slot_11_14_0, slot_11_11_0:GetValue():GetHotkeyState(), slot_11_8_0)
	end

	if slot_0_65_0:Get():Get(4) and slot_0_108_5:Get() then
		slot_0_114_3("DUCK PEEK", true, slot_11_8_0)
	end

	if slot_0_65_0:Get():Get(2) and slot_0_109_6:Get() then
		slot_0_114_3("FORCE", true, slot_11_8_0)
	end

	if slot_0_65_0:Get():Get(5) then
		if slot_0_110_5:Get() then
			slot_0_114_3("LEFT", true, slot_11_8_0)
		end

		if slot_0_111_4:Get() then
			slot_0_114_3("RIGHT", true, slot_11_8_0)
		end

		if slot_0_112_4:Get() then
			slot_0_114_3("BACK", true, slot_11_8_0)
		end

		if slot_0_113_4:Get() then
			slot_0_114_3("FORWARD", true, slot_11_8_0)
		end
	end
end

function slot_0_117_2(arg_12_0, arg_12_1, arg_12_2)
	local var_12_0 = draw.surface

	var_12_0.font = draw.fonts.esp

	local var_12_1 = arg_12_1 and slot_0_69_0:Get() or slot_0_70_0:Get()

	var_12_0:AddText(arg_12_2 - draw.Vec2(0, 9 * slot_0_101_1), arg_12_0, var_12_1)

	slot_0_101_1 = slot_0_101_1 + 1
end

function slot_0_118_2(arg_13_0)
	local var_13_0 = draw.GetDisplay() / 2 + draw.Vec2(11, -14)
	local var_13_1 = arg_13_0.m_flVelocityModifier:Get()

	if var_13_1 < 1 and slot_0_65_0:Get():Get(3) then
		local var_13_2 = string.format("SLOWED %.0f%%", (1 - var_13_1) * 100)

		slot_0_117_2(var_13_2, true, var_13_0)
	end

	if slot_0_65_0:Get():Get(5) then
		if slot_0_110_5:Get() then
			slot_0_117_2("LEFT", true, var_13_0)
		end

		if slot_0_111_4:Get() then
			slot_0_117_2("RIGHT", true, var_13_0)
		end

		if slot_0_112_4:Get() then
			slot_0_117_2("BACK", true, var_13_0)
		end

		if slot_0_113_4:Get() then
			slot_0_117_2("FORWARD", true, var_13_0)
		end
	end

	if slot_0_65_0:Get():Get(4) and slot_0_108_5:Get() then
		slot_0_117_2("DUCK PEEK", true, var_13_0)
	end

	if slot_0_65_0:Get():Get(2) and slot_0_109_6:Get() then
		slot_0_117_2("FORCE", true, var_13_0)
	end

	local var_13_3 = gui.GetActiveOverridePath()

	if not var_13_3 then
		return
	end

	local var_13_4 = gui.ctx:Find(var_13_3 .. ">weapon>hitchance")
	local var_13_5 = gui.ctx:Find(var_13_3 .. ">weapon>mindamage")

	if slot_0_65_0:Get():Get(0) and var_13_5 then
		local var_13_6 = var_13_5:Get()
		local var_13_7 = var_13_6 > 100 and string.format("MD: HP+%d", var_13_6 - 100) or string.format("MD: %d", var_13_6)

		if var_13_6 == 0 then
			var_13_7 = "MD: LETHAL"
		end

		slot_0_117_2(var_13_7, var_13_5:GetValue():GetHotkeyState(), var_13_0)
	end

	if slot_0_65_0:Get():Get(1) and var_13_4 then
		local var_13_8 = var_13_4:Get()
		local var_13_9 = slot_0_99_0.isActive(arg_13_0) and "HC AIR" or var_13_8 > 40 and "HC" or "HC LOW"

		if var_13_8 == -1 then
			var_13_9 = "HC AUTO"
		end

		slot_0_117_2(var_13_9, var_13_4:GetValue():GetHotkeyState(), var_13_0)
	end
end

function slot_0_100_0.onRender(arg_14_0)
	slot_0_101_1 = 0

	if slot_0_107_4 == 0 then
		slot_0_118_2(arg_14_0)
	else
		slot_0_116_2(arg_14_0)
	end
end

slot_0_101_0 = {}
slot_0_102_1 = draw.shader("        cbuffer cb : register(b0) {\n            float4x4 mvp;\n            float2 tex;\n            float time;\n            float alpha;\n        };\n\n        struct PS_INPUT {\n            float4 pos : SV_POSITION;\n            float4 col : COLOR0;\n            float2 uv  : TEXCOORD0;\n        };\n\n        sampler sampler0;\n        Texture2D texture0;\n\n        float4 main(PS_INPUT inp) : SV_Target {\n            float2 p = inp.uv * 2.0 - 1.0;\n\n            float d1 = abs(p.x - p.y);\n            float d2 = abs(p.x + p.y);\n            float shape = max(\n                smoothstep(0.1, 0.0, d1),\n                smoothstep(0.1, 0.0, d2)\n            );\n\n            float dist = length(p);\n            shape *= smoothstep(0.5, 0.1, dist); // hollow center\n            shape *= smoothstep(1.0, 0.3, dist); // soft outer edge\n\n            return float4(inp.col.rgb, shape * inp.col.a);\n        }\n    ")

slot_0_102_1:create()

slot_0_103_2 = 1
slot_0_104_3 = math.huge
slot_0_105_3 = nil
slot_0_106_3 = {}
slot_0_107_3 = {}

function slot_0_108_4(arg_15_0)
	if arg_15_0:GetPawnFromId("attacker") ~= entities.GetLocalPawn() then
		return
	end

	local var_15_0 = arg_15_0:GetPawnFromId("userid")

	if var_15_0 == nil then
		return
	end

	slot_0_105_3 = {
		time = game.globalVars.m_flCurTime,
		origin = var_15_0:GetAbsOrigin()
	}
end

function slot_0_109_5(arg_16_0)
	local var_16_0 = arg_16_0:GetPawnFromId("userid")

	if var_16_0 == nil or var_16_0 ~= entities.GetLocalPawn() then
		return
	end

	table.insert(slot_0_106_3, {
		time = game.globalVars.m_flCurTime,
		origin = vector(arg_16_0:GetFloat("x"), arg_16_0:GetFloat("y"), arg_16_0:GetFloat("z"))
	})
end

function slot_0_101_0.onGameEvent(arg_17_0)
	local var_17_0 = arg_17_0:GetName()

	if var_17_0 == "player_hurt" then
		slot_0_108_4(arg_17_0)
	end

	if var_17_0 == "bullet_impact" then
		slot_0_109_5(arg_17_0)
	end
end

function slot_0_110_4()
	local var_18_0 = game.globalVars.m_flCurTime

	if slot_0_105_3 and var_18_0 - slot_0_105_3.time > slot_0_103_2 then
		slot_0_105_3 = nil
	end

	local var_18_1
	local var_18_2 = slot_0_104_3

	for iter_18_0 = #slot_0_106_3, 1, -1 do
		local var_18_3 = slot_0_106_3[iter_18_0]

		if var_18_0 - var_18_3.time > slot_0_103_2 then
			table.remove(slot_0_106_3, iter_18_0)
		elseif slot_0_105_3 then
			local var_18_4 = var_18_3.origin:Dist2d(slot_0_105_3.origin)

			if var_18_4 < var_18_2 then
				var_18_2 = var_18_4
				var_18_1 = iter_18_0
			end
		end
	end

	if var_18_1 then
		local var_18_5 = table.remove(slot_0_106_3, var_18_1)

		slot_0_105_3 = nil

		if var_18_5 then
			table.insert(slot_0_107_3, {
				time = var_18_0,
				origin = var_18_5.origin
			})
		end
	end
end

function slot_0_101_0.onRender()
	local var_19_0 = draw.surface

	var_19_0.font = draw.fonts.esp

	local var_19_1 = var_19_0.g
	local var_19_2 = game.globalVars.m_flCurTime

	slot_0_110_4()

	for iter_19_0 = #slot_0_107_3, 1, -1 do
		local var_19_3 = slot_0_107_3[iter_19_0]
		local var_19_4 = var_19_2 - var_19_3.time

		if var_19_4 > slot_0_59_0:Get() then
			table.remove(slot_0_107_3, iter_19_0)
		else
			local var_19_5 = math.WorldToScreen(var_19_3.origin)

			if var_19_5 then
				local var_19_6 = math.clamp(1 - var_19_4 / slot_0_59_0:Get(), 0, 1)
				local var_19_7 = slot_0_61_0:Get():ModA(var_19_6)
				local var_19_8 = draw.Rect(var_19_5.x - 20, var_19_5.y - 20, var_19_5.x + 20, var_19_5.y + 20)

				var_19_0:AddGlow(draw.Rect(var_19_5.x, var_19_5.y, var_19_5.x, var_19_5.y), 8, var_19_7)
				var_19_1:SetShader(slot_0_102_1)

				var_19_1.uv_rect = nil

				var_19_0:AddRectFilled(var_19_8, var_19_7)
				var_19_1:SetShader(nil)
			end
		end
	end
end

slot_0_102_0 = {}
slot_0_103_1 = draw.shader("    cbuffer cb : register(b0) {\n        float4x4 mvp;\n        float2 tex;\n        float time;\n        float alpha;\n    };\n\n    struct PS_INPUT {\n        float4 pos : SV_POSITION;\n        float4 col : COLOR0;\n        float2 uv  : TEXCOORD0;\n    };\n\n    sampler sampler0;\n    Texture2D texture0;\n\n    float4 main(PS_INPUT inp) : SV_Target {\n        float2 centered = inp.uv * 2.0 - 1.0;\n        float aa = smoothstep(1.0, 0.92, length(centered));\n        float4 col = inp.col;\n        col.a *= aa * alpha;\n        return col;\n    }\n    ")

slot_0_103_1:create()

slot_0_104_2 = {
	[EItemDefinitionIndex.NONE] = nil,
	[EItemDefinitionIndex.DEAGLE] = {
		JUMP = 15.42045807871894,
		CROUCH = 14.364388869492645,
		STAND = 15.116808704140043
	},
	[EItemDefinitionIndex.ELITE] = {
		JUMP = 15.367260609405289,
		CROUCH = 13.90700800770461,
		STAND = 14.924248834528044
	},
	[EItemDefinitionIndex.FIVESEVEN] = {
		JUMP = 15.420445235200363,
		CROUCH = 14.079171696536376,
		STAND = 15.222428678841109
	},
	[EItemDefinitionIndex.GLOCK] = {
		JUMP = 15.420445235200363,
		CROUCH = 14.029317924530185,
		STAND = 14.475606999607836
	},
	[EItemDefinitionIndex.AK47] = {
		JUMP = 24.660094714771475,
		CROUCH = 16.59161620930366,
		STAND = 30.628560436260187
	},
	[EItemDefinitionIndex.AUG] = {
		JUMP = 24.55527232065089,
		CROUCH = 15.97123175597553,
		STAND = 31.600272087216734
	},
	[EItemDefinitionIndex.AWP] = {
		JUMP = 24.660094714771475,
		CROUCH = 16.59161620930366,
		STAND = 30.628560436260187
	},
	[EItemDefinitionIndex.FAMAS] = {
		JUMP = 24.838326950605463,
		CROUCH = 17.01322280391691,
		STAND = 32.208148027949846
	},
	[EItemDefinitionIndex.G3SG1] = {
		JUMP = 24.41540895073057,
		CROUCH = 15.782457455196743,
		STAND = 32.13726439737032
	},
	[EItemDefinitionIndex.GALILAR] = {
		JUMP = 24.486802121014172,
		CROUCH = 16.192048731847205,
		STAND = 31.729777789516945
	},
	[EItemDefinitionIndex.M249] = {
		JUMP = 24.700833045703988,
		CROUCH = 16.02503442860139,
		STAND = 31.937407862936308
	},
	[EItemDefinitionIndex.M4A1] = {
		JUMP = 24.57268013406646,
		CROUCH = 16.388950209280388,
		STAND = 31.638411308479217
	},
	[EItemDefinitionIndex.MAC10] = {
		JUMP = 19.744039459341046,
		CROUCH = 13.83785460352735,
		STAND = 24.415441998732888
	},
	[EItemDefinitionIndex.P90] = {
		JUMP = 24.49221484261521,
		CROUCH = 16.204376614264895,
		STAND = 31.273270529398356
	},
	[EItemDefinitionIndex.ZONE_REPULSOR] = nil,
	[EItemDefinitionIndex.MP5SD] = {
		JUMP = 19.345963117244416,
		CROUCH = 14.012007878075469,
		STAND = 23.692098088239455
	},
	[EItemDefinitionIndex.UMP45] = {
		JUMP = 24.094656499267128,
		CROUCH = 16.81424368828933,
		STAND = 30.620783804329815
	},
	[EItemDefinitionIndex.XM1014] = {
		JUMP = 24.581974897705628,
		CROUCH = 16.29169587364721,
		STAND = 32.08119371483731
	},
	[EItemDefinitionIndex.BIZON] = {
		JUMP = 24.781828084527774,
		CROUCH = 16.42484741600631,
		STAND = 32.70198585726575
	},
	[EItemDefinitionIndex.MAG7] = {
		JUMP = 24.587548532519467,
		CROUCH = 15.027055125145093,
		STAND = 32.55310074471733
	},
	[EItemDefinitionIndex.NEGEV] = {
		JUMP = 24.778788932781083,
		CROUCH = 16.355947820349652,
		STAND = 32.763394616383685
	},
	[EItemDefinitionIndex.SAWEDOFF] = {
		JUMP = 24.212561903097882,
		CROUCH = 16.21448185099236,
		STAND = 31.72055562055742
	},
	[EItemDefinitionIndex.TEC9] = {
		JUMP = 15.420445235200363,
		CROUCH = 14.249949027745712,
		STAND = 15.081095893098222
	},
	[EItemDefinitionIndex.TASER] = {
		JUMP = 14.554921681860208,
		CROUCH = 14.024795088237019,
		STAND = 15.103393299098478
	},
	[EItemDefinitionIndex.HKP2000] = {
		JUMP = 15.420445235200363,
		CROUCH = 14.071996115832258,
		STAND = 15.199181615694856
	},
	[EItemDefinitionIndex.MP7] = {
		JUMP = 19.719833778798844,
		CROUCH = 13.973082442580319,
		STAND = 24.472387436603046
	},
	[EItemDefinitionIndex.MP9] = {
		JUMP = 24.636822427878723,
		CROUCH = 16.395206583172303,
		STAND = 32.586368255980055
	},
	[EItemDefinitionIndex.NOVA] = {
		JUMP = 24.514364823027687,
		CROUCH = 16.21901864969942,
		STAND = 31.743970043723976
	},
	[EItemDefinitionIndex.P250] = {
		JUMP = 15.420445235200363,
		CROUCH = 14.327339979891244,
		STAND = 14.69681034107594
	},
	[EItemDefinitionIndex.SHIELD] = nil,
	[EItemDefinitionIndex.SCAR20] = {
		JUMP = 24.50532594757571,
		CROUCH = 15.562778546087365,
		STAND = 31.83230691642754
	},
	[EItemDefinitionIndex.SG556] = {
		JUMP = 23.12118574645518,
		CROUCH = 16.50938596578804,
		STAND = 28.697928019683697
	},
	[EItemDefinitionIndex.SSG08] = {
		JUMP = 23.567994762076953,
		CROUCH = 15.799399406976576,
		STAND = 35.54902210999487
	},
	[EItemDefinitionIndex.FLASHBANG] = {
		JUMP = 15.002166816256223,
		CROUCH = 12.857590485645382,
		STAND = 13.325319100856046
	},
	[EItemDefinitionIndex.HEGRENADE] = {
		JUMP = 15.002166816256223,
		CROUCH = 12.918253704689771,
		STAND = 13.362252899074416
	},
	[EItemDefinitionIndex.SMOKEGRENADE] = {
		JUMP = 15.002166816256223,
		CROUCH = 12.926179517063364,
		STAND = 13.325319100856046
	},
	[EItemDefinitionIndex.MOLOTOV] = {
		JUMP = 15.001177305608026,
		CROUCH = 12.974455852310001,
		STAND = 14.43461844044847
	},
	[EItemDefinitionIndex.DECOY] = {
		JUMP = 15.002166816256223,
		CROUCH = 12.901164114329084,
		STAND = 15.542335528188769
	},
	[EItemDefinitionIndex.INCGRENADE] = {
		JUMP = 15.001177305608026,
		CROUCH = 12.974455852310001,
		STAND = 14.43461844044847
	},
	[EItemDefinitionIndex.C4] = {
		JUMP = 16.327412317514845,
		CROUCH = 16.696635039390948,
		STAND = 15.9410439133859
	},
	[EItemDefinitionIndex.HEALTHSHOT] = {
		JUMP = 15.10678755264309,
		CROUCH = 13.249047393675852,
		STAND = 15.654962486768254
	},
	[EItemDefinitionIndex.M4A1_SILENCER] = {
		JUMP = 24.60023459947399,
		CROUCH = 16.440746426462926,
		STAND = 35.396256817699424
	},
	[EItemDefinitionIndex.USP_SILENCER] = {
		JUMP = 15.420445235200363,
		CROUCH = 14.05206542650378,
		STAND = 15.14986523784477
	},
	[EItemDefinitionIndex.CZ75A] = {
		JUMP = 15.420445235200363,
		CROUCH = 14.198274099740047,
		STAND = 15.14986523784477
	},
	[EItemDefinitionIndex.REVOLVER] = {
		JUMP = 15.420843379422866,
		CROUCH = 14.597558115285912,
		STAND = 15.056018771598504
	},
	[EItemDefinitionIndex.TAGRENADE] = nil,
	[EItemDefinitionIndex.FISTS] = nil,
	[EItemDefinitionIndex.BREACHCHARGE] = nil,
	[EItemDefinitionIndex.TABLET] = nil,
	[EItemDefinitionIndex.MELEE] = nil,
	[EItemDefinitionIndex.AXE] = nil,
	[EItemDefinitionIndex.HAMMER] = nil,
	[EItemDefinitionIndex.SPANNER] = nil,
	[EItemDefinitionIndex.FIREBOMB] = nil,
	[EItemDefinitionIndex.DIVERSION] = nil,
	[EItemDefinitionIndex.FRAGGRENADE] = nil,
	[EItemDefinitionIndex.SNOWBALL] = nil,
	[EItemDefinitionIndex.BUMPMINE] = nil,
	[EItemDefinitionIndex.KNIFEGG] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	},
	[EItemDefinitionIndex.KNIFE] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	},
	[EItemDefinitionIndex.KNIFE_T] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	},
	[EItemDefinitionIndex.KNIFE_BAYONET] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	},
	[EItemDefinitionIndex.KNIFE_CSS] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	},
	[EItemDefinitionIndex.KNIFE_FLIP] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	},
	[EItemDefinitionIndex.KNIFE_GUT] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	},
	[EItemDefinitionIndex.KNIFE_KARAMBIT] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	},
	[EItemDefinitionIndex.KNIFE_M9BAYONET] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	},
	[EItemDefinitionIndex.KNIFE_TACTICAL] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	},
	[EItemDefinitionIndex.KNIFE_FALCHION] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	},
	[EItemDefinitionIndex.KNIFE_SURVIVAL_BOWIE] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	},
	[EItemDefinitionIndex.KNIFE_BUTTERFLY] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	},
	[EItemDefinitionIndex.KNIFE_PUSH] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	},
	[EItemDefinitionIndex.KNIFE_CORD] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	},
	[EItemDefinitionIndex.KNIFE_CANIS] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	},
	[EItemDefinitionIndex.KNIFE_URSUS] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	},
	[EItemDefinitionIndex.KNIFE_GYPSY_JACKKNIFE] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	},
	[EItemDefinitionIndex.KNIFE_OUTDOOR] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	},
	[EItemDefinitionIndex.KNIFE_STILETTO] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	},
	[EItemDefinitionIndex.KNIFE_WIDOWMAKER] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	},
	[EItemDefinitionIndex.KNIFE_SKELETON] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	},
	[EItemDefinitionIndex.KNIFE_GHOST] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	},
	[EItemDefinitionIndex.KNIFE_KUKRI] = {
		JUMP = 16.437367478523797,
		CROUCH = 13.578105185295676,
		STAND = 17.730285597758968
	}
}
slot_0_105_2 = 25
slot_0_106_2 = {
	DIAGONAL = 20,
	BASE_OTHER = -170,
	BASE_PRIMARY_CROUCHED = -155,
	BASE_PRIMARY = -143,
	BASE = -143
}
slot_0_107_2 = false
slot_0_108_3 = nil
slot_0_109_4 = vector(0, 0, 0)
slot_0_110_3 = vector(0, 0, 0)
slot_0_111_3 = vector(0, 0, 0)
slot_0_112_3 = nil
slot_0_113_3 = false
slot_0_114_2 = 0
slot_0_115_1 = false
slot_0_116_1 = false
slot_0_117_1 = 0
slot_0_118_1 = true
slot_0_119_1 = 0
slot_0_120_1 = draw.Vec2(0, 0)

function slot_0_121_1(arg_20_0, arg_20_1)
	local var_20_0 = arg_20_0:Length()

	if arg_20_1 < var_20_0 then
		return vector(arg_20_0.x / var_20_0 * arg_20_1, arg_20_0.y / var_20_0 * arg_20_1, 0)
	end

	return arg_20_0
end

function slot_0_122_1(arg_21_0)
	return math.max(-180, math.min(180, arg_21_0 - 360 * math.floor(arg_21_0 / 360 + 0.5)))
end

function slot_0_123_0(arg_22_0)
	slot_0_92_0:GetValue():Set(slot_0_122_1(slot_0_106_2.BASE + arg_22_0))
end

function slot_0_124_0(arg_23_0)
	slot_0_96_0:GetValue():Set(arg_23_0)
end

function slot_0_125_0(arg_24_0)
	local var_24_0 = slot_0_94_0:GetValue():Get()

	if arg_24_0 then
		var_24_0:Unset(0)
		var_24_0:Set(1)
	else
		var_24_0:Set(0)
		var_24_0:Unset(1)
	end

	slot_0_94_0:GetValue():Set(var_24_0)
end

function slot_0_126_0()
	local var_25_0 = slot_0_17_0:GetValue():GetHotkeyState()

	if not var_25_0 then
		slot_0_108_3 = game.input:GetViewAngles()

		if slot_0_111_3:Length() < slot_0_105_2 then
			slot_0_111_3 = vector(0, 0, 0)
		end
	end

	if var_25_0 and not slot_0_107_2 then
		slot_0_110_3 = vector(0, 0, 0)
	end

	if slot_0_108_3 and var_25_0 then
		local var_25_1 = game.input:GetViewAngles()

		slot_0_109_4 = vector(var_25_1.x - slot_0_108_3.x, var_25_1.y - slot_0_108_3.y, 0)

		local var_25_2 = slot_0_19_0:Get() / 100

		slot_0_110_3.x = slot_0_110_3.x - slot_0_109_4.y * var_25_2
		slot_0_110_3.y = slot_0_110_3.y + slot_0_109_4.x * var_25_2
		slot_0_110_3 = slot_0_121_1(slot_0_110_3, 2)

		local var_25_3 = game.cvar:Find("m_yaw").value
		local var_25_4 = game.cvar:Find("m_pitch").value
		local var_25_5 = game.cvar:Find("sensitivity").value

		slot_0_111_3.x = slot_0_110_3.x / var_25_3 / var_25_5
		slot_0_111_3.y = slot_0_110_3.y / var_25_4 / var_25_5
	end

	slot_0_112_3 = slot_0_111_3:Length() > slot_0_105_2 and math.deg(math.atan2(slot_0_111_3.x, slot_0_111_3.y)) or nil
	slot_0_107_2 = var_25_0
end

function slot_0_127_0(arg_26_0, arg_26_1)
	local var_26_0 = entities.GetLocalPawn()

	if not var_26_0 then
		return
	end

	local var_26_1 = var_26_0:GetActiveWeapon()

	if var_26_1 then
		local var_26_2 = var_26_1:GetDefIndex()
		local var_26_3 = var_26_0.m_fFlags:Get()
		local var_26_4 = bit.band(var_26_3, bit.lshift(1, 0)) ~= 0
		local var_26_5 = arg_26_0:GetButton(input_bit_mask.IN_DUCK)
		local var_26_6 = slot_0_104_2[var_26_2]

		slot_0_106_2.BASE = -180 + var_26_6.STAND

		if var_26_5 then
			slot_0_106_2.BASE = -180 + var_26_6.CROUCH
		end

		if not var_26_4 then
			slot_0_106_2.BASE = -180 + var_26_6.JUMP
		end
	end

	if slot_0_92_0:Get() ~= slot_0_106_2.BASE then
		slot_0_92_0:GetValue():Set(slot_0_106_2.BASE)
	end

	slot_0_125_0(not slot_0_112_3)

	if slot_0_112_3 then
		local var_26_7 = slot_0_112_3 >= 0 and slot_0_106_2.DIAGONAL or -slot_0_106_2.DIAGONAL

		slot_0_123_0(slot_0_113_3 and slot_0_112_3 or slot_0_112_3 + var_26_7)

		slot_0_114_2 = var_26_7
		slot_0_113_3 = true
	elseif slot_0_113_3 then
		slot_0_123_0(-slot_0_114_2)

		slot_0_113_3 = false
	end

	local var_26_8 = slot_0_23_0:Get()

	if not slot_0_116_1 and var_26_8 then
		slot_0_115_1 = false
	end

	slot_0_116_1 = var_26_8

	if var_26_8 and slot_0_112_3 then
		local var_26_9 = arg_26_0:GetViewangles():GetForward()
		local var_26_10 = var_26_0:GetEyePos()
		local var_26_11 = 90
		local var_26_12

		entities.players:ForEach(function(arg_27_0)
			local var_27_0 = arg_27_0.entity

			if not var_27_0 then
				-- block empty
			elseif var_27_0 == var_26_0 then
				-- block empty
			elseif not var_27_0:IsAlive() then
				-- block empty
			elseif not var_27_0:IsEnemy() then
				-- block empty
			else
				local var_27_1 = (var_27_0:GetHitboxCenter(EHitBox.HEAD) - var_26_10):Normalized()
				local var_27_2 = var_26_9:Dot(var_27_1)
				local var_27_3 = math.deg(math.acos(math.max(-1, math.min(1, var_27_2))))

				if var_27_3 > var_26_11 then
					-- block empty
				else
					var_26_11 = var_27_3
					var_26_12 = var_27_0
				end
			end
		end)

		if var_26_12 then
			local var_26_13 = var_26_12:GetHitboxCenter(EHitBox.HEAD)
			local var_26_14 = var_26_0:GetHitboxCenter(EHitBox.HEAD)
			local var_26_15 = var_26_12:GetActiveWeapon()
			local var_26_16 = var_26_14 + var_26_0:GetAbsVelocity() * 0.03125

			if var_26_15 then
				local var_26_17, var_26_18 = mods.penetration.FireBullet(var_26_16, var_26_13 - var_26_16, var_26_15, var_26_12)

				if var_26_18.damage > 15 then
					slot_0_115_1 = true
				end
			end
		end

		if not slot_0_115_1 then
			slot_0_123_0(-slot_0_112_3)
		end
	end

	if slot_0_30_0:Get() then
		slot_0_119_1 = slot_0_119_1 + game.globalVars.m_flRenderFrameTime

		if slot_0_119_1 > 0.25 then
			slot_0_119_1 = 0
			slot_0_118_1 = not slot_0_118_1
		end

		if slot_0_118_1 then
			slot_0_117_1 = slot_0_117_1 + 11

			if slot_0_117_1 > 180 then
				slot_0_117_1 = -180
			end
		else
			slot_0_117_1 = slot_0_117_1 - 11

			if slot_0_117_1 < -180 then
				slot_0_117_1 = 180
			end
		end

		slot_0_124_0(slot_0_32_0:Get())
		slot_0_123_0(slot_0_117_1)
	else
		slot_0_117_1 = slot_0_106_2.BASE

		slot_0_124_0(89)
	end
end

function slot_0_102_0.run(arg_28_0, arg_28_1)
	slot_0_126_0()
	slot_0_127_0(arg_28_0, arg_28_1)
end

function slot_0_102_0.onSetupViewPre(arg_29_0)
	if not arg_29_0:IsAlive() then
		slot_0_108_3 = nil
		slot_0_112_3 = nil
		slot_0_110_3 = vector(0, 0, 0)
		slot_0_111_3 = vector(0, 0, 0)

		return
	end

	if slot_0_108_3 and slot_0_17_0:GetValue():GetHotkeyState() then
		game.input:SetViewAngles(slot_0_108_3)
	end
end

function slot_0_128_0(arg_30_0, arg_30_1, arg_30_2, arg_30_3)
	local var_30_0 = arg_30_2 / 2
	local var_30_1 = arg_30_3 / 2
	local var_30_2 = draw.Vec2(var_30_0 + slot_0_111_3.x, var_30_1 + slot_0_111_3.y)
	local var_30_3 = game.globalVars.m_flRenderFrameTime
	local var_30_4 = math.min(15 * var_30_3 * (slot_0_13_0:Get() / 100), 1)

	slot_0_120_1.x = slot_0_120_1.x + (var_30_2.x - slot_0_120_1.x) * var_30_4
	slot_0_120_1.y = slot_0_120_1.y + (var_30_2.y - slot_0_120_1.y) * var_30_4

	local var_30_5 = 15 * (slot_0_21_0:Get() / 100)
	local var_30_6 = var_30_2.x - slot_0_120_1.x
	local var_30_7 = var_30_2.y - slot_0_120_1.y
	local var_30_8 = math.sqrt(var_30_6 * var_30_6 + var_30_7 * var_30_7)
	local var_30_9 = math.max(1, var_30_5 * (1 - math.min(var_30_8 / 200, 1)))

	arg_30_0.g:SetShader(slot_0_103_1)

	if slot_0_10_0:Get() then
		arg_30_0:AddPillMulticolor(draw.Vec2(slot_0_120_1.x, slot_0_120_1.y), var_30_2, var_30_9, var_30_5, {
			draw.Color(arg_30_1:GetR(), arg_30_1:GetG(), arg_30_1:GetB(), 0),
			arg_30_1
		}, 32)
	else
		arg_30_0:AddPillMulticolor(var_30_2, var_30_2, var_30_5, var_30_5, {
			draw.Color(arg_30_1:GetR(), arg_30_1:GetG(), arg_30_1:GetB(), 0),
			arg_30_1
		}, 32)
	end

	arg_30_0.g:SetShader(nil)
end

function slot_0_129_0(arg_31_0, arg_31_1, arg_31_2, arg_31_3)
	local var_31_0 = arg_31_2 / 2
	local var_31_1 = arg_31_3 / 2
	local var_31_2 = draw.Vec2(var_31_0 + slot_0_111_3.x, var_31_1 + slot_0_111_3.y)
	local var_31_3 = draw.Rect(var_31_2.x, var_31_2.y, var_31_2.x, var_31_2.y)

	arg_31_0:AddGlow(var_31_3, 15 * (slot_0_21_0:Get() / 100), arg_31_1)
end

function slot_0_130_0(arg_32_0, arg_32_1, arg_32_2, arg_32_3)
	local var_32_0 = arg_32_2 / 2
	local var_32_1 = arg_32_3 / 2
	local var_32_2 = draw.Vec2(var_32_0 + slot_0_111_3.x, var_32_1 + slot_0_111_3.y)
	local var_32_3 = draw.Rect(var_32_2.x - 158, var_32_2.y - 15, var_32_2.x, var_32_2.y + 282 - 15)

	arg_32_0.g:SetTexture(slot_0_2_0)
	arg_32_0:AddRectFilled(var_32_3, draw.Color(255, 255, 255, 255))
	arg_32_0.g:SetTexture(nil)
	arg_32_0:AddCircleFilled(var_32_2, 3, arg_32_1)
end

function slot_0_131_0(arg_33_0, arg_33_1, arg_33_2, arg_33_3)
	local var_33_0 = arg_33_2 / 2
	local var_33_1 = arg_33_3 / 2
	local var_33_2 = draw.Vec2(var_33_0 + slot_0_111_3.x, var_33_1 + slot_0_111_3.y)
	local var_33_3 = draw.Rect(var_33_2.x - 32, var_33_2.y - 30, var_33_2.x + 33, var_33_2.y + 65 - 30)

	if slot_0_17_0:GetValue():GetHotkeyState() then
		arg_33_0.g:SetTexture(slot_0_3_0)
	else
		arg_33_0.g:SetTexture(slot_0_1_0)
	end

	arg_33_0:AddRectFilled(var_33_3, draw.Color(255, 255, 255, 255))
	arg_33_0.g:SetTexture(nil)
end

function slot_0_102_0.onRender()
	local var_34_0 = draw.surface

	var_34_0.g.antiAlias = true
	var_34_0.font = draw.fonts.esp

	if not slot_0_108_3 then
		var_34_0.g.antiAlias = false

		return
	end

	if slot_0_111_3:Length() <= slot_0_105_2 and not slot_0_17_0:GetValue():GetHotkeyState() then
		var_34_0.g.antiAlias = false

		return
	end

	local var_34_1 = slot_0_111_3:Length() >= slot_0_105_2 and slot_0_25_0:Get() or slot_0_26_0:Get()
	local var_34_2, var_34_3 = game.engine:GetScreenSize()
	local var_34_4 = slot_0_28_0:GetValue():Get()

	if var_34_4:Get(0) then
		slot_0_128_0(var_34_0, var_34_1, var_34_2, var_34_3)
	elseif var_34_4:Get(1) then
		slot_0_129_0(var_34_0, var_34_1, var_34_2, var_34_3)
	elseif var_34_4:Get(2) then
		slot_0_130_0(var_34_0, var_34_1, var_34_2, var_34_3)
	elseif var_34_4:Get(3) then
		slot_0_131_0(var_34_0, var_34_1, var_34_2, var_34_3)
	end

	if slot_0_23_0:Get() then
		if not slot_0_115_1 and slot_0_112_3 then
			var_34_0:AddText(draw.Vec2(var_34_2 / 2 + 11, var_34_3 / 2 + 8), "ANTI-EXTRAP", draw.Color(0, 255, 0, 255))
		else
			var_34_0:AddText(draw.Vec2(var_34_2 / 2 + 11, var_34_3 / 2 + 8), "ANTI-EXTRAP", draw.Color(255, 0, 0, 255))
		end
	end

	var_34_0.g.antiAlias = false
end

slot_0_103_0 = {}
slot_0_104_1 = gui.ctx:Find("misc>movement>peek assist")
slot_0_105_1 = gui.ctx:Find("misc>movement>duck peek assist")

function slot_0_103_0.run(arg_35_0, arg_35_1)
	if arg_35_0:GetButton(InputBitMask_t.IN_MOVELEFT) or arg_35_0:GetButton(InputBitMask_t.IN_MOVERIGHT) or arg_35_0:GetButton(InputBitMask_t.IN_JUMP) or arg_35_0:GetButton(InputBitMask_t.IN_FORWARD) or arg_35_0:GetButton(InputBitMask_t.IN_BACK) then
		return
	end

	if slot_0_104_1:Get() then
		return
	end

	if not arg_35_1:IsAlive() then
		return
	end

	local var_35_0 = arg_35_1.m_fFlags:Get()

	if not (bit.band(var_35_0, bit.lshift(1, 0)) ~= 0) then
		return
	end

	local var_35_1 = game.globalVars.m_iTickCount
	local var_35_2 = 0.020087999999999998
	local var_35_3 = arg_35_1:GetActiveWeapon()

	if not var_35_3 then
		return
	end

	if var_35_3:GetType() == CSWeaponType.GRENADE then
		return
	end

	local var_35_4 = var_35_2 * (250 / var_35_3:GetMaxSpeed())

	if arg_35_0:GetButton(InputBitMask_t.IN_DUCK) or slot_0_105_1:Get() then
		var_35_4 = var_35_4 * 2.941176470588235
	end

	if var_35_1 % 2 == 0 then
		arg_35_0:SetLeftMove(var_35_4)
	else
		arg_35_0:SetLeftMove(-var_35_4)
	end
end

slot_0_104_0 = {
	run = function(arg_36_0)
		if not arg_36_0:IsAlive() then
			return
		end

		local var_36_0 = arg_36_0:GetActiveWeapon()

		if not var_36_0 then
			return
		end

		local var_36_1 = var_36_0:GetType()

		if var_36_1 == CSWeaponType.TASER then
			local var_36_2 = ffi.cast("uintptr_t*", var_36_0)[0]
			local var_36_3 = ffi.cast("float*", var_36_2 + var_36_0.m_fLastShotTime.offset)[0]

			if math.abs(var_36_3 - game.globalVars.m_flCurTime) < 0.1 then
				if slot_0_76_0:Get():Get(1) then
					game.engine:ClientCmd("slot2")
				else
					game.engine:ClientCmd("slot1")
				end
			end
		end

		if var_36_1 == CSWeaponType.GRENADE then
			local var_36_4 = ffi.cast("uintptr_t*", var_36_0)[0]
			local var_36_5 = ffi.cast("float*", var_36_4 + var_36_0.m_fThrowTime.offset)[0]

			if math.abs(var_36_5 - game.globalVars.m_flCurTime) < 0.1 then
				if slot_0_76_0:Get():Get(1) then
					game.engine:ClientCmd("slot2")
				else
					game.engine:ClientCmd("slot1")
				end
			end
		end
	end
}
slot_0_105_0 = {}
slot_0_106_1 = 0.015625

function slot_0_105_0.run(arg_37_0, arg_37_1)
	if not arg_37_1:IsAlive() then
		return
	end

	local var_37_0 = arg_37_1:GetActiveWeapon()

	if not var_37_0 then
		return
	end

	if not var_37_0:IsAttackable() then
		return
	end

	if not var_37_0:IsGun() then
		return
	end

	if var_37_0.m_nNextPrimaryAttackTick:Get().value > game.globalVars.m_iTickCount then
		return
	end

	local var_37_1 = var_37_0:GetData()

	if not var_37_1 then
		return
	end

	local var_37_2 = var_37_1.m_nDamage:Get()
	local var_37_3 = gui.GetActiveOverridePath(false)
	local var_37_4 = gui.ctx:Find(var_37_3 .. ">weapon>mindamage"):Get()
	local var_37_5 = false

	if var_37_4 > 100 then
		var_37_4 = var_37_4 - 100
		var_37_5 = true
	end

	local var_37_6 = slot_0_37_0:Get()
	local var_37_7 = arg_37_1:GetAbsVelocity()
	local var_37_8 = arg_37_1:GetEyePos()
	local var_37_9 = var_37_8 + var_37_7 * (slot_0_106_1 * var_37_6)
	local var_37_10 = false

	entities.players:ForEach(function(arg_38_0)
		slot_38_1_0 = arg_38_0.entity

		if not slot_38_1_0 then
			-- block empty
		elseif slot_38_1_0 == arg_37_1 then
			-- block empty
		elseif not slot_38_1_0:IsAlive() then
			-- block empty
		elseif not slot_38_1_0:IsEnemy() then
			-- block empty
		else
			slot_38_2_0 = mods.penetration.ScaleDamage(var_37_2, var_37_0, HitGroup_t.HEAD, slot_38_1_0)
			slot_38_3_0 = mods.penetration.ScaleDamage(var_37_2, var_37_0, HitGroup_t.GENERIC, slot_38_1_0)
			slot_38_4_0 = mods.penetration.ScaleDamage(var_37_2, var_37_0, HitGroup_t.STOMACH, slot_38_1_0)
			slot_38_5_0 = mods.penetration.ScaleDamage(var_37_2, var_37_0, HitGroup_t.LEFTARM, slot_38_1_0)
			slot_38_6_0 = mods.penetration.ScaleDamage(var_37_2, var_37_0, HitGroup_t.LEFTLEG, slot_38_1_0)
			slot_38_7_0 = slot_38_1_0.m_iHealth:Get()
			slot_38_8_0 = var_37_4

			if var_37_5 then
				slot_38_8_0 = slot_38_7_0 + var_37_4
			end

			slot_38_9_0 = {}

			if slot_0_39_0:Get():Get(0) and slot_38_8_0 < slot_38_2_0 then
				slot_38_10_1 = slot_38_1_0:GetHitboxCenter(EHitBox.HEAD)
				slot_38_11_0 = slot_38_10_1 + slot_38_10_1 + Vector(0, 0, 4.4)

				table.insert(slot_38_9_0, slot_38_10_1)
				table.insert(slot_38_9_0, slot_38_11_0)
			end

			if slot_0_39_0:Get():Get(1) and slot_38_8_0 < slot_38_3_0 then
				table.insert(slot_38_9_0, slot_38_1_0:GetHitboxCenter(EHitBox.UPPER_CHEST))
				table.insert(slot_38_9_0, slot_38_1_0:GetHitboxCenter(EHitBox.CHEST))
			end

			if slot_0_39_0:Get():Get(2) and slot_38_8_0 < slot_38_4_0 then
				table.insert(slot_38_9_0, slot_38_1_0:GetHitboxCenter(EHitBox.THORAX))
				table.insert(slot_38_9_0, slot_38_1_0:GetHitboxCenter(EHitBox.STOMACH))
			end

			if slot_0_39_0:Get():Get(3) and slot_38_8_0 < slot_38_5_0 then
				table.insert(slot_38_9_0, slot_38_1_0:GetHitboxCenter(EHitBox.RIGHT_UPPER_ARM))
				table.insert(slot_38_9_0, slot_38_1_0:GetHitboxCenter(EHitBox.LEFT_UPPER_ARM))
				table.insert(slot_38_9_0, slot_38_1_0:GetHitboxCenter(EHitBox.RIGHT_LOWER_ARM))
				table.insert(slot_38_9_0, slot_38_1_0:GetHitboxCenter(EHitBox.LEFT_LOWER_ARM))
			end

			if slot_0_39_0:Get():Get(4) and slot_38_8_0 < slot_38_6_0 then
				table.insert(slot_38_9_0, slot_38_1_0:GetHitboxCenter(EHitBox.RIGHT_UPPER_LEG))
				table.insert(slot_38_9_0, slot_38_1_0:GetHitboxCenter(EHitBox.LEFT_UPPER_LEG))
				table.insert(slot_38_9_0, slot_38_1_0:GetHitboxCenter(EHitBox.RIGHT_LOWER_LEG))
				table.insert(slot_38_9_0, slot_38_1_0:GetHitboxCenter(EHitBox.LEFT_LOWER_LEG))
			end

			if slot_0_39_0:Get():Get(5) and slot_38_8_0 < slot_38_6_0 then
				table.insert(slot_38_9_0, slot_38_1_0:GetHitboxCenter(EHitBox.RIGHT_FOOT))
				table.insert(slot_38_9_0, slot_38_1_0:GetHitboxCenter(EHitBox.LEFT_FOOT))
			end

			slot_38_10_0 = slot_38_1_0:GetAbsVelocity()

			for iter_38_0 in pairs(slot_38_9_0) do
				slot_38_15_0 = slot_38_9_0[iter_38_0]
				slot_38_16_0, slot_38_17_0 = mods.penetration.FireBullet(var_37_8, slot_38_15_0 - var_37_8, var_37_0, slot_38_1_0)

				if slot_38_8_0 < slot_38_17_0.damage then
					var_37_10 = true
				end

				if var_37_6 > 0 then
					slot_38_18_0 = slot_38_15_0 + slot_38_10_0 * (slot_0_106_1 * var_37_6)
					slot_38_19_0, slot_38_20_0 = mods.penetration.FireBullet(var_37_9, slot_38_15_0 - var_37_9, var_37_0, slot_38_1_0)
					slot_38_21_0, slot_38_22_0 = mods.penetration.FireBullet(var_37_9, slot_38_18_0 - var_37_9, var_37_0, slot_38_1_0)
					slot_38_23_0, slot_38_24_0 = mods.penetration.FireBullet(var_37_8, slot_38_18_0 - var_37_8, var_37_0, slot_38_1_0)

					if slot_38_8_0 < slot_38_24_0.damage or slot_38_8_0 < slot_38_20_0.damage or slot_38_8_0 < slot_38_22_0.damage then
						var_37_10 = true
					end
				end
			end
		end
	end)

	if var_37_10 then
		arg_37_0:RemoveButton(InputBitMask_t.IN_JUMP)
	end
end

slot_0_106_0 = {}
slot_0_107_1 = bit.bor(draw.FontFlags.OUTLINE, draw.FontFlags.NO_DPI)
slot_0_108_2 = draw.FontGDI("C:\\Windows\\Fonts\\verdana.ttf", 10, slot_0_107_1, 0, 255, 0)
slot_0_109_3 = draw.FontGDI("C:\\Windows\\Fonts\\verdana.ttf", 23, slot_0_107_1, 0, 255, 0)

slot_0_108_2:Create()
slot_0_109_3:Create()

function slot_0_110_2()
	if not game.globalVars then
		return 0
	end

	local var_39_0 = 1 / game.globalVars.m_flRenderFrameTime

	if not var_39_0 then
		return 0
	end

	if var_39_0 == math.huge or var_39_0 == -math.huge then
		return 0
	end

	return var_39_0
end

slot_0_111_2 = 64
slot_0_112_2 = {}
slot_0_113_2 = 1

function slot_0_114_1()
	if not game.globalVars then
		return
	end

	local var_40_0 = game.globalVars.m_flRenderFrameTime

	slot_0_112_2[slot_0_113_2] = var_40_0
	slot_0_113_2 = slot_0_113_2 % slot_0_111_2 + 1
end

function slot_0_115_0()
	local var_41_0 = #slot_0_112_2

	if var_41_0 < 2 then
		return 0
	end

	local var_41_1 = 0

	for iter_41_0, iter_41_1 in ipairs(slot_0_112_2) do
		var_41_1 = var_41_1 + iter_41_1
	end

	local var_41_2 = var_41_1 / var_41_0
	local var_41_3 = 0

	for iter_41_2, iter_41_3 in ipairs(slot_0_112_2) do
		local var_41_4 = iter_41_3 - var_41_2

		var_41_3 = var_41_3 + var_41_4 * var_41_4
	end

	return math.sqrt(var_41_3 / var_41_0) * 1000
end

function slot_0_116_0()
	local var_42_0 = game.engine:GetNetChan()

	if not var_42_0 then
		return 0
	end

	if var_42_0:IsNull() then
		return 0
	end

	return var_42_0:GetLatency() * 1000
end

function slot_0_117_0()
	local var_43_0 = game.engine:GetNetChan()

	if not var_43_0 then
		return "local"
	end

	if var_43_0:IsNull() then
		return "local"
	end

	return var_43_0:IsLoopback() and "local" or "online"
end

slot_0_118_0 = {}
slot_0_119_0 = 1
slot_0_120_0 = 64

function slot_0_121_0()
	if math.random() > 0.1 then
		return
	end

	local var_44_0 = 2.1 + math.random() * 0.9

	slot_0_118_0[slot_0_119_0] = var_44_0
	slot_0_119_0 = slot_0_119_0 % slot_0_120_0 + 1
end

function slot_0_122_0()
	if slot_0_117_0() == "local" then
		return 0, 0
	end

	local var_45_0 = #slot_0_118_0

	if var_45_0 < 2 then
		return 2.5, 0.5
	end

	local var_45_1 = 0

	for iter_45_0, iter_45_1 in ipairs(slot_0_118_0) do
		var_45_1 = var_45_1 + iter_45_1
	end

	local var_45_2 = var_45_1 / var_45_0
	local var_45_3 = 0

	for iter_45_2, iter_45_3 in ipairs(slot_0_118_0) do
		local var_45_4 = iter_45_3 - var_45_2

		var_45_3 = var_45_3 + var_45_4 * var_45_4
	end

	return var_45_2, math.sqrt(var_45_3 / var_45_0)
end

function slot_0_106_0.run()
	slot_46_0_0 = draw.surface
	slot_46_0_0.font = slot_0_108_2
	slot_46_1_0, slot_46_2_0 = game.engine:GetScreenSize()
	slot_46_4_0 = game.cvar:Find("hud_scaling").value
	slot_46_6_0 = slot_46_2_0 - slot_46_2_0 * 0.078 * slot_46_4_0
	slot_46_7_0 = 1

	if slot_0_79_0:Get() then
		slot_46_0_0.font = slot_0_109_3
		slot_46_7_0 = 2.2
		slot_46_6_0 = slot_46_2_0 * 0.875
	end

	slot_46_8_0 = draw.Vec2(slot_46_1_0 / 2 - slot_46_1_0 * (0.115 * slot_46_7_0), slot_46_6_0)

	slot_0_114_1()
	slot_0_121_0()
	slot_46_0_0:AddText(slot_46_8_0, "fps:", draw.Color(255, 255, 255, 255))
	slot_46_0_0:AddText(slot_46_8_0 + draw.Vec2(45 * slot_46_7_0, 0), string.format("%.0f", slot_0_110_2()), draw.Color(255, 255, 255, 255), draw.TextParams.WithH(draw.TextAlignment.RIGHT))

	slot_46_9_0 = 0
	slot_46_10_0 = game.globalVars.m_iTickCount % 500

	if slot_46_10_0 > 1 and slot_46_10_0 < 10 then
		slot_46_9_0 = 1
	end

	slot_46_0_0:AddText(slot_46_8_0 + draw.Vec2(0, 13 * slot_46_7_0), "loss:", draw.Color(255, 255, 255, 255))
	slot_46_0_0:AddText(slot_46_8_0 + draw.Vec2(45 * slot_46_7_0, 13 * slot_46_7_0), string.format("%.0f%%", slot_46_9_0), draw.Color(255, 255, 255, 255), draw.TextParams.WithH(draw.TextAlignment.RIGHT))
	slot_46_0_0:AddText(slot_46_8_0 + draw.Vec2(0, 26 * slot_46_7_0), "tick:", draw.Color(255, 255, 255, 255))
	slot_46_0_0:AddText(slot_46_8_0 + draw.Vec2(45 * slot_46_7_0, 26 * slot_46_7_0), string.format("%.1f", 64), draw.Color(255, 255, 255, 255), draw.TextParams.WithH(draw.TextAlignment.RIGHT))

	slot_46_11_0 = slot_0_115_0()
	slot_46_12_0 = draw.Color(255, 255, 255, 255)

	if slot_46_11_0 > 1 then
		slot_46_12_0 = draw.Color(255, 165, 0, 255)
	end

	if slot_46_11_0 > 2 then
		slot_46_12_0 = draw.Color(255, 69, 0, 255)
	end

	slot_46_0_0:AddText(slot_46_8_0 + draw.Vec2(55 * slot_46_7_0, 0), string.format("var: %.1f  ms", slot_46_11_0), slot_46_12_0)

	slot_46_13_0 = slot_0_117_0() == "online" and 0.3 + math.random() * 0.4 or 0
	slot_46_14_0, slot_46_15_0 = slot_0_122_0()

	slot_46_0_0:AddText(slot_46_8_0 + draw.Vec2(55 * slot_46_7_0, 13 * slot_46_7_0), string.format("choke: %.0f%%", 0), draw.Color(255, 255, 255, 255))
	slot_46_0_0:AddText(slot_46_8_0 + draw.Vec2(55 * slot_46_7_0, 26 * slot_46_7_0), string.format("sv: %.1f +- %.1f ms", slot_46_14_0, slot_46_13_0), draw.Color(255, 255, 255, 255))
	slot_46_0_0:AddText(slot_46_8_0 + draw.Vec2(105 * slot_46_7_0, 0), string.format("ping: %.0f  ms", slot_0_116_0()), draw.Color(255, 255, 255, 255))

	slot_46_16_0 = utils.GetDate()

	slot_46_0_0:AddText(slot_46_8_0 + draw.Vec2(105 * slot_46_7_0, 13 * slot_46_7_0), string.format("ver: %.0f%.0f", slot_46_16_0.hour, slot_46_16_0.minute), draw.Color(255, 255, 255, 255))
	slot_46_0_0:AddText(slot_46_8_0 + draw.Vec2(130 * slot_46_7_0, 26 * slot_46_7_0), string.format("var: %.3f  ms", slot_46_15_0), draw.Color(255, 255, 255, 255))

	slot_46_17_0 = draw.Vec2(slot_46_1_0 / 2 + slot_46_1_0 * (0.115 * slot_46_7_0), slot_46_6_0)

	slot_46_0_0:AddText(slot_46_17_0 + draw.Vec2(0, 0), string.format("up:%.0f/s", 64), draw.Color(255, 255, 255, 255), draw.TextParams.WithH(draw.TextAlignment.RIGHT))
	slot_46_0_0:AddText(slot_46_17_0 + draw.Vec2(0, 13 * slot_46_7_0), string.format("cmd:%.0f/s", 64), draw.Color(255, 255, 255, 255), draw.TextParams.WithH(draw.TextAlignment.RIGHT))
	slot_46_0_0:AddText(slot_46_17_0 + draw.Vec2(0, 26 * slot_46_7_0), slot_0_117_0(), draw.Color(255, 255, 255, 255), draw.TextParams.WithH(draw.TextAlignment.RIGHT))
end

slot_0_107_0 = {}
slot_0_108_1 = gui.ctx:Find("rage>aimbot>doubletap")
slot_0_109_2 = gui.ctx:Find("rage>aimbot>doubletap>settings>on manual shot")
slot_0_110_1 = -1

function slot_0_107_0.run(arg_47_0, arg_47_1)
	if not slot_0_108_1 or not slot_0_109_2 then
		return
	end

	local var_47_0 = arg_47_1:GetActiveWeapon()

	if not var_47_0 then
		return
	end

	local var_47_1 = var_47_0:GetType()

	if slot_0_110_1 ~= var_47_1 then
		if var_47_0:GetType() == CSWeaponType.KNIFE then
			slot_0_108_1:GetValue():Set(true)
			slot_0_109_2:GetValue():Set(true)
		else
			slot_0_108_1:GetValue():Set(false)
			slot_0_109_2:GetValue():Set(false)
		end

		slot_0_110_1 = var_47_1
	end
end

slot_0_108_0 = {}
slot_0_109_1 = nil

function slot_0_108_0.run(arg_48_0, arg_48_1)
	if not arg_48_1:IsAlive() then
		return
	end

	local var_48_0 = ffi.cast("uintptr_t*", arg_48_1)[0]

	if ffi.cast("uint8_t*", var_48_0 + arg_48_1.m_MoveType.offset)[0] ~= 9 then
		slot_0_109_1 = arg_48_0:GetViewangles()

		return
	end

	local var_48_1 = arg_48_0:GetViewangles().x
	local var_48_2 = arg_48_0:GetForwardMove()

	if var_48_2 < 0.5 and var_48_2 > -0.5 then
		return
	end

	local var_48_3 = true

	if var_48_2 < 0 then
		var_48_3 = false
	end

	if var_48_3 then
		arg_48_0:SetLeftMove(-1)
	else
		arg_48_0:SetLeftMove(1)
	end

	local var_48_4 = slot_0_109_1 + Vector(0, 60, 0)

	var_48_4.y = math.AngleNormalize(var_48_4.y)
	var_48_4.x = -80

	if var_48_1 > 10 then
		arg_48_0:SetForwardMove(-1)
		arg_48_0:SetLeftMove(1)
	end

	arg_48_0:SetViewangles(var_48_4)
end

slot_0_109_0 = {
	run = function(arg_49_0, arg_49_1)
		if not arg_49_1:IsAlive() then
			return
		end

		local var_49_0 = arg_49_1:GetActiveWeapon()

		if not var_49_0 then
			return
		end

		if var_49_0:GetType() ~= CSWeaponType.SNIPER_RIFLE then
			return
		end

		local var_49_1 = ffi.cast("uintptr_t*", var_49_0)[0]
		local var_49_2 = ffi.cast("float*", var_49_1 + var_49_0.m_fLastShotTime.offset)[0]

		if math.abs(var_49_2 - game.globalVars.m_flCurTime) < 0.01 then
			game.engine:ClientCmd("slot3")
			Delay(0.015625, function()
				game.engine:ClientCmd("slot1")
			end)
		end
	end
}
slot_0_110_0 = {}
slot_0_111_1 = gui.ctx:Find("misc>movement>slowwalk")
slot_0_112_1 = 0.015625
slot_0_113_1 = true

function slot_0_110_0.run(arg_51_0, arg_51_1)
	if not slot_0_113_1 then
		return
	end

	if not arg_51_1:IsAlive() then
		return
	end

	local var_51_0 = arg_51_1.m_fFlags:Get()

	if bit.band(var_51_0, bit.lshift(1, 0)) ~= 0 then
		return
	end

	local var_51_1 = Ray_t()
	local var_51_2 = arg_51_1.m_pCollision:GetAs("client.dll", "CCollisionProperty")

	var_51_1:SetHull(var_51_2.m_vecMins:Get(), var_51_2.m_vecMaxs:Get())

	local var_51_3 = arg_51_1:GetAbsVelocity()
	local var_51_4 = arg_51_1:GetAbsOrigin()
	local var_51_5 = arg_51_1:GetAbsOrigin() + var_51_3 * (slot_0_112_1 * 1)
	local var_51_6 = game.physicsQueryInterface:TraceMovement(var_51_1, var_51_4, var_51_5)

	if not var_51_6:DidHitWorld() then
		return
	end

	local var_51_7 = var_51_6.m_Plane.normal

	if var_51_7.z > 0.97 or var_51_7.z < 0.5 then
		return
	end

	local var_51_8 = var_51_3.x * var_51_3.x + var_51_3.y * var_51_3.y

	if var_51_8 > 0 then
		local var_51_9 = 1 / math.sqrt(var_51_8)
		local var_51_10 = var_51_3.x * var_51_9
		local var_51_11 = var_51_3.y * var_51_9

		if var_51_10 * var_51_7.x + var_51_11 * var_51_7.y > 0 then
			return
		end
	end

	slot_0_111_1:GetValue():Set(true)

	slot_0_113_1 = false

	Delay(slot_0_112_1 * 1.2, function()
		slot_0_111_1:GetValue():Set(false)

		slot_0_113_1 = true
	end)
end

slot_0_111_0 = {
	run = function(arg_53_0, arg_53_1)
		if not arg_53_1:IsAlive() then
			return
		end

		local var_53_0 = arg_53_1.m_fFlags:Get()

		if bit.band(var_53_0, bit.lshift(1, 0)) ~= 0 then
			return
		end

		arg_53_0:SetButton(InputBitMask_t.IN_DUCK)
	end
}
slot_0_112_0 = {}
slot_0_113_0 = utils.FindPattern("client.dll", "48 89 5C 24 ? 48 89 7C 24 ? 55 41")

if not slot_0_113_0 or slot_0_113_0 == 0 then
	error("KillEffect pattern failed!")
end

slot_0_114_0 = ffi.cast("void(__fastcall*)(const char*, int, void*, bool, int, int, uint32_t, int, bool)", slot_0_113_0)

function slot_0_112_0.onGameEvent(arg_54_0)
	if arg_54_0:GetName() ~= "player_death" then
		return
	end

	if arg_54_0:GetPawnFromId("attacker") ~= entities.GetLocalPawn() then
		return
	end

	local var_54_0 = arg_54_0:GetPawnFromId("userid")
	local var_54_1 = ffi.cast("void**", var_54_0)[0]

	if not var_54_1 then
		return
	end

	local var_54_2 = slot_0_90_0:Get()

	if var_54_2:Get(0) then
		slot_0_114_0("particles/critters/chicken/chicken_gone_feathers_fire.vpcf", 3, var_54_1, false, 0, 0, 4294967295, 0, false)
	end

	if var_54_2:Get(1) then
		slot_0_114_0("particles/critters/chicken/chicken_gone_feathers.vpcf", 3, var_54_1, false, 0, 0, 4294967295, 0, false)
	end

	if var_54_2:Get(2) then
		slot_0_114_0("particles/critters/chicken/chicken_roasted.vpcf", 3, var_54_1, false, 0, 0, 4294967295, 0, false)
	end

	if var_54_2:Get(3) then
		slot_0_114_0("particles/blood_impact/impact_taser_bodyfx.vpcf", 3, var_54_1, false, 0, 0, 4294967295, 0, false)
	end

	if var_54_2:Get(4) then
		slot_0_114_0("particles/inferno_fx/explosion_incend_air_splash07a.vpcf", 3, var_54_1, false, 0, 0, 4294967295, 0, false)
	end
end

events.createMove:Add(function(arg_55_0)
	local var_55_0 = entities.GetLocalPawn()

	if var_55_0 == nil then
		return
	end

	if slot_0_55_0:Get() then
		slot_0_98_0.run(var_55_0)
	end

	if slot_0_8_0:Get() then
		slot_0_103_0.run(arg_55_0, var_55_0)
	end

	if slot_0_74_0:Get() then
		slot_0_104_0.run(var_55_0)
	end

	if slot_0_42_0:Get() then
		slot_0_99_0.run(arg_55_0, var_55_0)
	end

	if slot_0_35_0:Get() then
		slot_0_105_0.run(arg_55_0, var_55_0)
	end

	if slot_0_53_0:Get() then
		slot_0_107_0.run(arg_55_0, var_55_0)
	end

	if slot_0_82_0:Get() then
		slot_0_108_0.run(arg_55_0, var_55_0)
	end

	if slot_0_84_0:Get() then
		slot_0_109_0.run(arg_55_0, var_55_0)
	end

	if slot_0_86_0:Get() then
		slot_0_110_0.run(arg_55_0, var_55_0)
	end

	if slot_0_88_0:Get() then
		slot_0_111_0.run(arg_55_0, var_55_0)
	end

	slot_0_102_0.run(arg_55_0, var_55_0)
end)
events.presentQueue:Add(function()
	if slot_0_57_0:Get() then
		slot_0_101_0.onRender()
	end

	if slot_0_77_0:Get() then
		slot_0_106_0.run()
	end

	slot_0_102_0.onRender()

	local var_56_0 = entities.GetLocalPawn()

	if var_56_0 == nil then
		return
	end

	if slot_0_67_0:Get() and var_56_0:IsAlive() then
		slot_0_100_0.onRender(var_56_0)
	end
end)
events.setupViewPre:Add(function()
	local var_57_0 = entities.GetLocalPawn()

	if not var_57_0 then
		return
	end

	slot_0_102_0.onSetupViewPre(var_57_0)
end)
mods.events:AddListener("player_hurt")
mods.events:AddListener("player_death")
events.event:Add(function(arg_58_0)
	if slot_0_57_0:Get() then
		slot_0_101_0.onGameEvent(arg_58_0)
	end

	if not slot_0_90_0:Get():None() then
		slot_0_112_0.onGameEvent(arg_58_0)
	end
end)
gui.notify:add(gui.notification("Femtality", "We have loaded PEAK femboy lua!"))
