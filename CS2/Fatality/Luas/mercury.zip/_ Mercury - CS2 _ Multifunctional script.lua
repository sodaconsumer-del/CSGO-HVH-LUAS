﻿--by scriptleaks https://discord.gg/n4DpEunxbj t.me/scriptleakslol

if ffi == nil then
	slot_0_0_1 = gui.notification("Mercury", "Allow insecure mod")

	return gui.notify:add(slot_0_0_1)
end

slot_0_0_0 = "none"
slot_0_1_0 = "http://95.181.175.169:8080"

ffi.cdef("   \n    typedef struct _SYSTEMTIME {\n        unsigned short wYear;         // Year\n        unsigned short wMonth;        // Month (1-12)\n        unsigned short wDayOfWeek;    // Day of the week (0 = Sunday, 6 = Saturday)\n        unsigned short wDay;          // Day of the month (1-31)\n        unsigned short wHour;         // Hour (0-23, UTC or local time)\n        unsigned short wMinute;       // Minute (0-59)\n        unsigned short wSecond;       // Second (0-59)\n        unsigned short wMilliseconds; // Milliseconds (0-999)\n    } SYSTEMTIME; \n")

function slot_0_2_0()
	-- if tostring(ws.get_item_id()) ~= "0" then
	-- 	return ws.get_resource_dir()
	-- end

	local var_1_0 = utils.find_export("kernel32.dll", "GetModuleFileNameA")
	local var_1_1 = ffi.cast("unsigned int(__stdcall*)(void*, char*, unsigned int)", var_1_0)
	local var_1_2 = ffi.new("char[260]")
	local var_1_3 = var_1_1(nil, var_1_2, 260)
	local var_1_4 = ffi.string(var_1_2, var_1_3)

	print("[Mercury] Local folder")

	return string.gsub(var_1_4, "\\bin\\win64\\cs2.exe", "\\csgo\\fatality\\mercury\\")
end

slot_0_3_0 = {}
slot_0_4_0 = {}
slot_0_5_0 = {}
slot_0_6_0 = {}
slot_0_7_0 = {}
slot_0_7_0 = {
	vars = {
		callback_id = {},
		timer_list = {},
		cycle_list = {},
		wait_list = {}
	},
	timer = function(arg_2_0, arg_2_1)
		table.insert(slot_0_7_0.vars.timer_list, {
			time = slot_0_6_0.real_time + arg_2_0,
			func = arg_2_1
		})
	end,
	cycle = function(arg_3_0, arg_3_1, arg_3_2)
		local var_3_0 = {
			_destroy = false,
			time = slot_0_6_0.real_time + (arg_3_2 and 0.1 or arg_3_0),
			func = arg_3_1,
			period = arg_3_0,
			destroy = function(arg_4_0)
				arg_4_0._destroy = true
			end
		}

		table.insert(slot_0_7_0.vars.cycle_list, var_3_0)

		return var_3_0
	end,
	callback = function(arg_5_0, arg_5_1, arg_5_2)
		local var_5_0 = #slot_0_7_0.vars.callback_id + 1

		table.insert(slot_0_7_0.vars.callback_id, 0)

		return slot_0_7_0.cycle(arg_5_0, function()
			local var_6_0 = slot_0_7_0.vars.callback_id[var_5_0]
			local var_6_1, var_6_2 = arg_5_1()

			if var_6_1 ~= var_6_0 then
				slot_0_7_0.vars.callback_id[var_5_0] = var_6_1

				arg_5_2(var_6_1, var_6_2)
			end
		end)
	end,
	wait_until = function(arg_7_0, arg_7_1)
		if type(arg_7_0) ~= "function" or type(arg_7_1) ~= "function" then
			return
		end

		table.insert(slot_0_7_0.vars.wait_list, {
			arg_7_0,
			arg_7_1
		})
	end,
	update_timer = function()
		local var_8_0 = slot_0_6_0.real_time
		local var_8_1 = 0

		for iter_8_0 = 1, #slot_0_7_0.vars.timer_list do
			iter_8_0 = iter_8_0 - var_8_1

			if var_8_0 >= slot_0_7_0.vars.timer_list[iter_8_0].time then
				xpcall(function()
					slot_0_7_0.vars.timer_list[iter_8_0].func()
				end, function()
					print("[Mercury:Error] Timer func")
				end)
				table.remove(slot_0_7_0.vars.timer_list, iter_8_0)

				var_8_1 = var_8_1 + 1
			end
		end

		local var_8_2 = 0

		for iter_8_1 = 1, #slot_0_7_0.vars.cycle_list do
			iter_8_1 = iter_8_1 - var_8_2

			local var_8_3 = slot_0_7_0.vars.cycle_list[iter_8_1]

			if var_8_3._destroy then
				table.remove(slot_0_7_0.vars.cycle_list, iter_8_1)

				var_8_2 = var_8_2 + 1
			elseif var_8_0 >= var_8_3.time then
				xpcall(function()
					var_8_3.func()
				end, function()
					print("[Mercury:Error] Cycle func")
				end)

				var_8_3.time = var_8_0 + var_8_3.period
			end
		end

		local var_8_4 = 0

		for iter_8_2 = 1, #slot_0_7_0.vars.wait_list do
			iter_8_2 = iter_8_2 - var_8_4

			local var_8_5 = slot_0_7_0.vars.wait_list[iter_8_2]

			if var_8_5[1]() then
				var_8_5[2]()
				table.remove(slot_0_7_0.vars.wait_list, iter_8_2)

				var_8_4 = var_8_4 + 1
			end
		end
	end
}
slot_0_8_0 = {
	gr_counter = 0,
	counter = 0
}

function slot_0_9_1(arg_13_0)
	return string.format("_m3rcury:%s", arg_13_0)
end

slot_0_10_2 = slot_0_8_0
slot_0_10_2.script_tab = gui.GetMainWindow():AddTab(slot_0_9_1("merc"), draw.textures.gui_icon_down, "Mercury", gui.TabLayoutMode.SUBTABS)
slot_0_10_2._pages = {}
slot_0_10_2._groups = {}
slot_0_12_1 = true

function slot_0_10_2.add_page(arg_14_0, arg_14_1)
	if slot_0_10_2._pages[arg_14_0] then
		return
	end

	slot_0_10_2._pages[arg_14_0] = slot_0_10_2.script_tab:AddTab(slot_0_9_1(arg_14_0), arg_14_1, gui.TabLayoutMode.DEFAULT, slot_0_12_1)
	slot_0_12_1 = false
end

function slot_0_10_2.add_group(arg_15_0, arg_15_1, arg_15_2, arg_15_3)
	if not slot_0_10_2._pages[arg_15_0] then
		error("[ui_list] failed find group")
	end

	slot_0_10_2._groups[arg_15_0] = slot_0_10_2._groups[arg_15_0] or {}

	table.insert(slot_0_10_2._groups[arg_15_0], {
		arg_15_1,
		arg_15_2,
		size = arg_15_3
	})
end

function slot_0_10_2.init_groups(arg_16_0)
	for iter_16_0, iter_16_1 in pairs(slot_0_10_2._pages) do
		local var_16_0 = slot_0_10_2._groups[iter_16_0]

		if var_16_0 then
			for iter_16_2 = 1, #var_16_0 do
				local var_16_1 = var_16_0[iter_16_2][1]
				local var_16_2 = var_16_0[iter_16_2][2]
				local var_16_3 = gui.Group(slot_0_9_1(string.format("%s_%s", iter_16_0, var_16_1)), var_16_2, var_16_0[iter_16_2].size or 120, gui.GroupWidthMode.REDUCED)

				iter_16_1:Add(var_16_3)

				var_16_0[iter_16_2][3] = var_16_3
				slot_0_10_2._groups[iter_16_0][var_16_1] = var_16_3
			end
		else
			error(string.format("No group definitions for page: %s", iter_16_0))
		end
	end

	local var_16_4 = {}

	for iter_16_3, iter_16_4 in pairs(arg_16_0._groups) do
		local var_16_5 = {}

		for iter_16_5 = 1, #iter_16_4 do
			local var_16_6 = iter_16_4[iter_16_5][1]
			local var_16_7 = iter_16_4[iter_16_5][3]

			var_16_5[var_16_6] = slot_0_8_0.init(var_16_7, string.format("%s>%s", iter_16_3, var_16_6))
		end

		var_16_4[iter_16_3] = var_16_5
	end

	return var_16_4
end

slot_0_9_0 = {}
slot_0_9_0.__index = slot_0_9_0

function slot_0_9_0.element(arg_17_0)
	return arg_17_0.var
end

function slot_0_9_0.get(arg_18_0, arg_18_1, arg_18_2)
	local var_18_0 = arg_18_0.type == "input" and arg_18_0.var.value or arg_18_0.var:GetValue():Get()

	if arg_18_0.type == "multibox" or arg_18_0.type == "combobox" then
		local var_18_1 = var_18_0:GetRaw()

		if type(arg_18_1) == "string" then
			local var_18_2 = arg_18_0.index_items[arg_18_1] or -1

			return bit.band(var_18_1, var_18_2) == var_18_2
		elseif type(arg_18_1) == "number" then
			local var_18_3 = 2^(arg_18_1 - 1)

			return bit.band(var_18_1, var_18_3) == var_18_3
		end

		return arg_18_2 and math.log(var_18_1, 2) or var_18_1
	end

	return var_18_0
end

function slot_0_9_0.set(arg_19_0, arg_19_1, arg_19_2, arg_19_3)
	if arg_19_0.type == "input" then
		arg_19_0.var:SetValue(arg_19_1)

		return
	end

	local var_19_0 = arg_19_0.var:GetValue()

	if arg_19_0.type == "multibox" or arg_19_0.type == "combobox" then
		local var_19_1 = var_19_0:Get()
		local var_19_2 = var_19_1:GetRaw()
		local var_19_3 = -1

		if arg_19_3 and arg_19_0.type == "combobox" or arg_19_0.type == "multibox" then
			if type(arg_19_1) == "string" then
				var_19_3 = arg_19_0.index_items[arg_19_1] or -1
			elseif type(arg_19_1) == "number" then
				var_19_3 = 2^(arg_19_1 - 1)
			end
		else
			var_19_3 = arg_19_1
		end

		if arg_19_0.type == "multibox" then
			if arg_19_2 ~= nil then
				var_19_1:SetRaw(arg_19_2 and bit.bor(var_19_2, var_19_3) or bit.band(var_19_2, bit.bnot(var_19_3)))
			else
				var_19_1:SetRaw(arg_19_1)
			end
		else
			var_19_1:SetRaw(var_19_3)
		end

		var_19_0:Set(var_19_1)
	else
		var_19_0:Set(arg_19_1)
	end
end

function slot_0_9_0.get_items(arg_20_0)
	return arg_20_0.items
end

function slot_0_9_0.set_visible(arg_21_0, arg_21_1)
	if arg_21_0.row then
		arg_21_0.row:set_visible(arg_21_1)
	elseif arg_21_0.var.set_visible then
		arg_21_0.var:set_visible(arg_21_1)
	end
end

function slot_0_9_0.set_gui_visible(arg_22_0, arg_22_1)
	arg_22_0.is_visible = arg_22_1
end

function slot_0_9_0.get_visible(arg_23_0, arg_23_1)
	if arg_23_0.is_visible == nil then
		return true
	end

	if type(arg_23_0.is_visible) == "function" then
		return arg_23_0.is_visible()
	end

	return arg_23_0.is_visible
end

function slot_0_9_0.add_callback(arg_24_0, arg_24_1)
	if not arg_24_1 then
		return
	end

	arg_24_0.var:AddCallback(arg_24_1)

	arg_24_0.update = arg_24_1

	slot_0_7_0.timer(0.1, function()
		arg_24_1()
	end)
end

function slot_0_9_0.__call(arg_26_0)
	return arg_26_0:get()
end

function slot_0_8_0.init(arg_27_0, arg_27_1)
	if not arg_27_0 then
		error("[ui_list:init] " .. tostring(arg_27_1))
	end

	local var_27_0 = {}

	slot_0_8_0.gr_counter = slot_0_8_0.gr_counter + (arg_27_1 and 0 or 1)

	local var_27_1 = string.format("m3rcury:%s", arg_27_1 or slot_0_8_0.gr_counter)

	local function var_27_2(arg_28_0, arg_28_1)
		return string.format("%s>%s>%s", var_27_1, arg_28_0 or "", arg_28_1):gsub(">>", ">")
	end

	local function var_27_3(arg_29_0, arg_29_1, arg_29_2, arg_29_3, arg_29_4, arg_29_5, arg_29_6, arg_29_7)
		local var_29_0 = var_27_2(arg_29_2, arg_29_1)
		local var_29_1 = gui.control_id(var_29_0)
		local var_29_2, var_29_3 = arg_29_4(var_29_1, var_29_0)
		local var_29_4

		if arg_29_6 then
			arg_29_6:Add(arg_29_7 and gui.MakeControl(arg_29_1, var_29_2) or var_29_2)
		else
			var_29_4 = gui.MakeControl(arg_29_1, var_29_2)

			arg_27_0:Add(var_29_4)
		end

		local var_29_5 = setmetatable({
			type = arg_29_0,
			name = arg_29_1,
			var = var_29_2,
			controller = var_29_3,
			row = var_29_4,
			id = var_29_1,
			tooltip = arg_29_3,
			var_name = arg_29_2 or arg_29_1
		}, slot_0_9_0)

		if arg_29_5 then
			for iter_29_0, iter_29_1 in pairs(arg_29_5) do
				var_29_5[iter_29_0] = iter_29_1
			end
		end

		return var_29_5
	end

	function var_27_0.add_check_box(arg_30_0, arg_30_1, arg_30_2, arg_30_3, arg_30_4, arg_30_5)
		return var_27_3("checkbox", arg_30_1, arg_30_3, arg_30_2, function(arg_31_0)
			local var_31_0, var_31_1 = gui.MakeControlEasy(arg_31_0, arg_30_1, "checkbox")

			var_31_0.tooltip = arg_30_2

			return var_31_0, var_31_1
		end, nil, arg_30_4, arg_30_5)
	end

	function var_27_0.add_slider(arg_32_0, arg_32_1, arg_32_2, arg_32_3, arg_32_4, arg_32_5, arg_32_6, arg_32_7, arg_32_8, arg_32_9, arg_32_10)
		return var_27_3("slider", arg_32_2, arg_32_1, arg_32_8, function(arg_33_0)
			local var_33_0, var_33_1 = gui.MakeControlEasy(arg_33_0, arg_32_2, "slider", arg_32_3, arg_32_4, {
				"%." .. tostring(arg_32_6 or 0) .. "f"
			}, arg_32_7)

			var_33_0.tooltip = arg_32_8

			if var_33_0:GetValue():Get() == 0 and arg_32_5 then
				var_33_0:GetValue():Set(arg_32_5)
			end

			return var_33_0, var_33_1
		end, {
			min = arg_32_3,
			max = arg_32_4,
			points = arg_32_6
		}, arg_32_9, arg_32_10)
	end

	function var_27_0.add_combo_box(arg_34_0, arg_34_1, arg_34_2, arg_34_3, arg_34_4, arg_34_5, arg_34_6, arg_34_7)
		local var_34_0 = {}

		return var_27_3(arg_34_2 and "multibox" or "combobox", arg_34_1, arg_34_4, arg_34_5, function(arg_35_0, arg_35_1)
			local var_35_0, var_35_1 = gui.MakeControlEasy(arg_35_0, arg_34_1, "combo_box")

			var_35_0.tooltip = arg_34_5
			var_35_0.allow_multiple = arg_34_2

			for iter_35_0 = 1, #arg_34_3 do
				local var_35_2 = tostring(arg_34_3[iter_35_0])

				var_34_0[var_35_2] = 2^(iter_35_0 - 1)

				var_35_0:add(gui.Selectable(gui.control_id(arg_35_1 .. ">" .. var_35_2), var_35_2))
			end

			return var_35_0, var_35_1
		end, {
			items = arg_34_3,
			index_items = var_34_0
		}, arg_34_6, arg_34_7)
	end

	function var_27_0.add_color_picker(arg_36_0, arg_36_1, arg_36_2, arg_36_3, arg_36_4, arg_36_5, arg_36_6, arg_36_7)
		return var_27_3("coloredit", arg_36_2, arg_36_1, arg_36_5, function(arg_37_0)
			local var_37_0, var_37_1 = gui.MakeControlEasy(arg_37_0, arg_36_2, "color_picker", arg_36_3)

			var_37_0.tooltip = arg_36_5

			if arg_36_4 then
				local var_37_2 = var_37_0:GetValue():Get()

				if var_37_2:get_r() == 0 and var_37_2:get_a() == 0 then
					var_37_0:GetValue():Set(arg_36_4)
				end
			end

			return var_37_0, var_37_1
		end, nil, arg_36_6, arg_36_7)
	end

	function var_27_0.add_text_input(arg_38_0, arg_38_1, arg_38_2, arg_38_3, arg_38_4, arg_38_5, arg_38_6)
		return var_27_3("input", arg_38_2, arg_38_1, arg_38_4, function(arg_39_0)
			local var_39_0, var_39_1 = gui.MakeControlEasy(arg_39_0, arg_38_2, "text_input")

			var_39_0.placeholder = arg_38_3 or ""
			var_39_0.tooltip = arg_38_4

			return var_39_0, var_39_1
		end, nil, arg_38_5, arg_38_6)
	end

	function var_27_0.init_parrent_to_child(arg_40_0, arg_40_1, arg_40_2, arg_40_3, arg_40_4, arg_40_5)
		local var_40_0 = {
			[arg_40_1] = arg_40_3
		}
		local var_40_1 = arg_40_3.row

		if arg_40_5 then
			arg_40_3.settings = gui.Settings(string.format("%s>settings", arg_40_1))

			arg_40_3.row:Add(arg_40_3.settings)

			var_40_1 = arg_40_3.settings
		end

		if not var_40_1 then
			error("[Mercury:Error] Parent has no row")

			return arg_40_3
		end

		for iter_40_0, iter_40_1 in pairs(arg_40_4) do
			if iter_40_0 == "is_visible" then
				var_40_0[iter_40_0] = iter_40_1
			else
				local var_40_2 = iter_40_1[1]
				local var_40_3 = iter_40_1.info or iter_40_1[2] or {}
				local var_40_4 = string.format("%s>%s", arg_40_2, iter_40_0):gsub(">>", ">")
				local var_40_5

				if var_40_2 == "checkbox" then
					var_40_5 = arg_40_0:add_check_box(var_40_3.title, var_40_3.tooltip, var_40_4, var_40_1, arg_40_5)
				elseif var_40_2 == "slider" then
					var_40_5 = arg_40_0:add_slider(var_40_4, var_40_3.title, var_40_3.min, var_40_3.max, var_40_3.default, var_40_3.points, var_40_3.step, var_40_3.tooltip, var_40_1, arg_40_5)
				elseif var_40_2 == "combo_box" or var_40_2 == "combobox" or var_40_2 == "multibox" then
					local var_40_6 = var_40_2 == "multibox" or var_40_3.multi

					var_40_5 = arg_40_0:add_combo_box(var_40_3.title, var_40_6, var_40_3.items, var_40_4, var_40_3.tooltip, var_40_1, arg_40_5)
				elseif var_40_2 == "color_picker" or var_40_2 == "coloredit" then
					var_40_5 = arg_40_0:add_color_picker(var_40_4, var_40_3.title, var_40_3.use_alpha or var_40_3.alpha, var_40_3.default, var_40_3.tooltip, var_40_1, arg_40_5)
				elseif var_40_2 == "text_input" or var_40_2 == "input" then
					var_40_5 = arg_40_0:add_text_input(var_40_4, var_40_3.title, var_40_3.default, var_40_3.tooltip, var_40_1, arg_40_5)
				end

				if var_40_5 then
					var_40_0[iter_40_0] = var_40_5
				end
			end
		end

		return setmetatable(var_40_0, {
			__index = arg_40_0,
			__call = function()
				return arg_40_3:Get()
			end
		})
	end

	function var_27_0.reset(arg_42_0)
		arg_27_0:reset()
	end

	return var_27_0
end

function slot_0_10_1()
	return
end

function slot_0_10_0(arg_44_0, arg_44_1)
	local var_44_0 = (arg_44_1 == true or arg_44_1 == false) and arg_44_1 or arg_44_1 == nil
	local var_44_1 = var_44_0

	if type(arg_44_0) == "table" then
		if var_44_0 and arg_44_0.is_visible then
			var_44_1 = arg_44_0.is_visible()
		end

		for iter_44_0, iter_44_1 in pairs(arg_44_0) do
			local var_44_2 = type(iter_44_1)

			if var_44_2 == "table" and not iter_44_1.set_visible then
				slot_0_10_0(iter_44_1, var_44_1)
			elseif var_44_2 == "table" and iter_44_1.set_visible then
				iter_44_1:set_visible(var_44_1)
			end
		end
	end
end

function slot_0_11_0(arg_45_0, arg_45_1, arg_45_2)
	return arg_45_2 and Vector(arg_45_0, arg_45_1, arg_45_2) or math.vec2(arg_45_0, arg_45_1)
end

function draw.Vec2.__add(arg_46_0, arg_46_1)
	if type(arg_46_1) == "number" then
		return draw.Vec2(arg_46_0.x + arg_46_1, arg_46_0.y + arg_46_1)
	end

	return draw.Vec2(arg_46_0.x + arg_46_1.x, arg_46_0.y + arg_46_1.y)
end

function draw.Vec2.__sub(arg_47_0, arg_47_1)
	if type(arg_47_1) == "number" then
		return draw.Vec2(arg_47_0.x - arg_47_1, arg_47_0.y - arg_47_1)
	end

	return draw.Vec2(arg_47_0.x - arg_47_1.x, arg_47_0.y - arg_47_1.y)
end

function draw.Vec2.__mul(arg_48_0, arg_48_1)
	if type(arg_48_1) == "number" then
		return draw.Vec2(arg_48_0.x * arg_48_1, arg_48_0.y * arg_48_1)
	end

	return draw.Vec2(arg_48_0.x * arg_48_1.x, arg_48_0.y * arg_48_1.y)
end

function draw.Vec2.__div(arg_49_0, arg_49_1)
	if type(arg_49_1) == "number" then
		return draw.Vec2(arg_49_0.x / arg_49_1, arg_49_0.y / arg_49_1)
	end

	return draw.Vec2(arg_49_0.x / arg_49_1.x, arg_49_0.y / arg_49_1.y)
end

function Vector.set(arg_50_0, arg_50_1, arg_50_2, arg_50_3)
	arg_50_0.x = arg_50_1
	arg_50_0.y = arg_50_2
	arg_50_0.z = arg_50_3

	return arg_50_0
end

function draw.Vec2.set(arg_51_0, arg_51_1, arg_51_2)
	arg_51_0.x = arg_51_1
	arg_51_0.y = arg_51_2

	return arg_51_0
end

function slot_0_12_0(arg_52_0, arg_52_1, arg_52_2, arg_52_3)
	return draw.color(arg_52_0 or 255, arg_52_2 and arg_52_1 or arg_52_0 or 255, arg_52_2 or arg_52_0 or 255, arg_52_3 or not arg_52_2 and arg_52_1 or 255)
end

function draw.color.self_a(arg_53_0, arg_53_1)
	return arg_53_0:a(arg_53_0:get_a() / 255 * arg_53_1)
end

slot_0_13_0 = {}

slot_0_8_0.add_page("ui", "UI")
slot_0_8_0.add_group("ui", "widgets", "Widgets", 350)
slot_0_8_0.add_group("ui", "other", "Other", nil)
slot_0_8_0.add_group("ui", "rage_logs", "Rage Logs", 120)
slot_0_8_0.add_page("visuals", "Visuals")
slot_0_8_0.add_group("visuals", "world", "World", 400)
slot_0_8_0.add_group("visuals", "player", "Player", 400)
slot_0_8_0.add_group("visuals", "misc", "Misc")
slot_0_8_0.add_page("gameplay", "Gameplay")
slot_0_8_0.add_group("gameplay", "builder", "Builder", 400)
slot_0_8_0.add_group("gameplay", "movement", "Movement", 400)
slot_0_8_0.add_group("gameplay", "other", "other", 400)
slot_0_8_0.add_page("ow", "One-way")
slot_0_8_0.add_group("ow", "settings", "Settings [main]", 400)
slot_0_8_0.add_group("ow", "style", "Settings [style]", 400)
slot_0_8_0.add_group("ow", "create", "Create", 400)

slot_0_14_2 = slot_0_8_0:init_groups()
slot_0_8_0._GR = slot_0_14_2
slot_0_15_2 = slot_0_14_2.ui.widgets
slot_0_16_2 = slot_0_14_2.ui.other
slot_0_17_2 = slot_0_14_2.ui.rage_logs
slot_0_13_0.ui = {
	widgets = {
		settings = slot_0_15_2:add_combo_box("GLOBAL", true, {
			"Watermark",
			"Crosshair indicator",
			"Hotkeys",
			" > Hotkeys: solid style",
			" > Hotkeys: legit binds",
			"Velocity modifier",
			"Manuals indicator",
			"Notify: Rage logs",
			"Notify: Buy logs",
			"Rage logs",
			"Rage logs: Buy logs"
		}, "widgets>main"),
		visual = slot_0_15_2:init_parrent_to_child("background", "widgets>visual", slot_0_15_2:add_color_picker("widg_col", "Widgets color", true, slot_0_12_0(31, 100), "Background color"), {
			accent = {
				"color_picker",
				info = {
					tooltip = "Accent color. Alpha - shadow transparency",
					default = slot_0_12_0(40, 152, 255, 165)
				}
			},
			is_visible = function()
				return slot_0_13_0.ui.widgets.settings:get("Watermark") or slot_0_13_0.ui.widgets.settings:get("Hotkeys")
			end
		}),
		watermark = {
			settings = slot_0_15_2:add_combo_box("Watermark", true, {
				"Icons",
				"Title",
				"User name",
				"Avg fps",
				"0.1% fps",
				"Time"
			}, "watermark>settings"),
			is_visible = function()
				return slot_0_13_0.ui.widgets.settings:get("Watermark")
			end
		},
		crosshair_indicator = {
			visual = slot_0_15_2:init_parrent_to_child("background", "crosshair_indicator>visual", slot_0_15_2:add_color_picker("crosshair_indicator_b", "Crosshair indicator", true, slot_0_12_0(60, 255), "Background color"), {
				accent = {
					"color_picker",
					info = {
						tooltip = "Accent color",
						default = slot_0_12_0(170, 159, 255)
					}
				}
			}),
			is_visible = function()
				return slot_0_13_0.ui.widgets.settings:get("Crosshair indicator")
			end
		},
		velocity_modifier = {
			visual = slot_0_15_2:init_parrent_to_child("first", "widgets>velocity_modifier>visual", slot_0_15_2:add_color_picker("vel_mod", "Velocity modifier", false, slot_0_12_0(255, 115, 100), "First color"), {
				second = {
					"color_picker",
					info = {
						tooltip = "Second color",
						default = slot_0_12_0(160, 255, 120)
					}
				}
			}),
			is_visible = function()
				return slot_0_13_0.ui.widgets.settings:get("Velocity modifier")
			end
		},
		manuals_indicator = {
			visual = slot_0_16_2:init_parrent_to_child("first", "widgets>manuals_indicator>visual", slot_0_16_2:add_color_picker("manuals_i", "Manuals indicator", false, slot_0_12_0(160, 150, 255), "First color"), {
				second = {
					"color_picker",
					info = {
						tooltip = "Second color",
						default = slot_0_12_0(31, 255)
					}
				}
			}),
			is_visible = function()
				return slot_0_13_0.ui.widgets.settings:get("Manuals indicator")
			end
		},
		rage_logs = {
			visual = slot_0_17_2:init_parrent_to_child("background", "rage_logs>visual", slot_0_17_2:add_color_picker("rage_logs", "Rage logs", true, slot_0_12_0(31, 140), "Background color"), {
				hit = {
					"color_picker",
					info = {
						tooltip = "Hit color | Check \"widgets\" rage logs settings",
						default = slot_0_12_0(255, 100, 100)
					}
				},
				hurt = {
					"color_picker",
					info = {
						tooltip = "Hurt color | Check \"widgets\" rage logs settings",
						default = slot_0_12_0(255, 161, 74)
					}
				},
				buy = {
					"color_picker",
					info = {
						tooltip = "Buy color | Check \"widgets\" buy logs settings",
						default = slot_0_12_0(125, 255, 138)
					}
				}
			}),
			display = slot_0_17_2:add_combo_box("> Params", true, {
				"Background",
				"Blur",
				"Glow",
				"Outline"
			}, "rage_logs>display"),
			lifetime = slot_0_17_2:add_slider("rage_logs", "> Lifetime", 1, 8, 4),
			is_visible = function()
				return slot_0_13_0.ui.widgets.settings:get("Rage logs") or slot_0_13_0.ui.widgets.settings:get("Rage logs: Buy logs")
			end
		}
	}
}
slot_0_18_1 = slot_0_14_2.visuals.world
slot_0_19_0 = slot_0_14_2.visuals.player
slot_0_20_1 = slot_0_14_2.visuals.misc
slot_0_13_0.visuals = {
	free_cam = slot_0_18_1:init_parrent_to_child("parrent", "free_cam", slot_0_18_1:add_check_box("Free cam"), {
		marker = {
			"checkbox",
			info = {
				tooltip = "[Recommended] World marker: player position"
			}
		},
		multiplier = {
			"slider",
			info = {
				default = 15,
				max = 30,
				min = 5
			}
		}
	}),
	target_cam = slot_0_18_1:init_parrent_to_child("enable", "target_cam", slot_0_18_1:add_check_box("Target cam"), {}),
	head_hat = {
		settings = slot_0_19_0:add_combo_box("Hat", true, {
			"Nimbus",
			" > Nimbus: Glow",
			"Chinese",
			" > Chinese: outline",
			"Global: Fade",
			"Global: Rainbow"
		}, "hat>settings"),
		params = {
			color = slot_0_19_0:init_parrent_to_child("main", "head_hat_colors", slot_0_19_0:add_color_picker("hat_c", " > Color", true, slot_0_12_0(145, 164, 255, 80), "Main color"), {
				fade = {
					"color_picker",
					info = {
						tooltip = "Fade color | Hat settings > Fade",
						default = slot_0_12_0(240, 145, 255, 80)
					}
				}
			}),
			segments = slot_0_19_0:add_slider("hat_seg", " > Segments", 3, 30, 14),
			is_visible = function()
				return slot_0_13_0.visuals.head_hat.settings:get("Nimbus") or slot_0_13_0.visuals.head_hat.settings:get("Chinese")
			end
		}
	},
	world_marker = {
		settings = slot_0_18_1:add_combo_box("World markers", true, {
			"Impact",
			" > Impact: horizontal",
			"Damage",
			" > Damage: simple style"
		}, "world_markers>settings"),
		impact = {
			colors = slot_0_18_1:init_parrent_to_child("first", "world_marker>impact", slot_0_18_1:add_color_picker("imp_mark", "Impact marker", true, slot_0_12_0(255, 1), "First color"), {
				second = {
					"color_picker",
					info = {
						tooltip = "Second color",
						default = slot_0_12_0(255, 255)
					}
				}
			}),
			lifetime = slot_0_18_1:add_slider("impact", "> Lifetime", 1, 8, 4),
			offset = slot_0_18_1:add_slider("impact", "> Offset", 0, 20),
			length = slot_0_18_1:add_slider("impact", "> Length", 0, 20, 8),
			is_visible = function()
				return slot_0_13_0.visuals.world_marker.settings:get("Impact")
			end
		},
		damage = {
			params = slot_0_18_1:init_parrent_to_child("color", "world_marker>damage", slot_0_18_1:add_color_picker("dmg_mark", "Damage marker", false, slot_0_12_0(), "Text color"), {
				lifetime = {
					"slider",
					info = {
						default = 4,
						tooltip = "Lifetime",
						max = 8,
						min = 1
					}
				}
			}),
			is_visible = function()
				return slot_0_13_0.visuals.world_marker.settings:get("Damage")
			end
		}
	},
	trails = {
		settings = slot_0_19_0:add_combo_box("Trails", true, {
			"Line",
			" > Line: glow [Fps]",
			" > Line: afk animation",
			" > Line: rainbow"
		}, "trails>settings"),
		params = {
			colors = slot_0_19_0:init_parrent_to_child("first", "visuals>trails>colors", slot_0_19_0:add_color_picker("trails_c", "> Colors", true, slot_0_12_0(), "First color"), {
				second = {
					"color_picker",
					info = {
						tooltip = "Second color",
						default = slot_0_12_0(255, 1)
					}
				}
			}),
			lifetime = slot_0_19_0:add_slider("trails", "> Lifetime", 0.1, 5, 1, 1, 0.1),
			is_visible = function()
				return slot_0_13_0.visuals.trails.settings:get("Line")
			end
		}
	},
	physic_text = {
		settings = slot_0_18_1:add_combo_box("Physic text", true, {
			"Damage",
			"Headshot",
			"Domination: counter",
			"Killstreak: announcer"
		}, "physic_text>settings"),
		params = {
			style = slot_0_18_1:add_combo_box(" > Style", false, {
				"Solid",
				"Outline",
				"Fatality",
				"Ghosting"
			}),
			accent = slot_0_18_1:add_color_picker("physic_text_c", " > Accent color", true, slot_0_12_0()),
			is_visible = function()
				return slot_0_13_0.visuals.physic_text.settings:get() ~= 0
			end
		}
	}
}
slot_0_21_1 = slot_0_14_2.gameplay.movement
slot_0_22_1 = slot_0_14_2.gameplay.other
slot_0_23_1 = slot_0_14_2.gameplay.builder
slot_0_13_0.misc = {
	global = slot_0_22_1:add_combo_box("Global", true, {
		"Hide draggable zone",
		"Knife left hand",
		"Fast throw",
		"Taskbar notify on round",
		"Anti afk",
		"Jumpbug: auto",
		"Fast ladder"
	}, "misc>global"),
	jump_scout = {
		settings = slot_0_21_1:add_combo_box("Jump scout", true, {
			"Hitchance",
			"Pointscale",
			"In air autostop"
		}),
		hitchance = {
			value = slot_0_21_1:add_slider("jump_scout_hitchance", " > Hitchance", 20, 100, 50),
			is_visible = function()
				return slot_0_13_0.misc.jump_scout.settings:get("Hitchance")
			end
		},
		pointscale = {
			value = slot_0_21_1:add_slider("jump_scout_points", " > Pointscale", 1, 100, 50),
			is_visible = function()
				return slot_0_13_0.misc.jump_scout.settings:get("Pointscale")
			end
		}
	},
	knife_bot = slot_0_22_1:add_check_box("DT Knife bot", "Important: 1) Use only on DT servers. \n\n2) Rage > Aimbot > Double Tap > On manual shot", "dt_knife_bot")
}
slot_0_13_0.anti_aim = {
	freestand = slot_0_21_1:add_check_box("Freestand", "! Set: Rage > Anti-aim > Yaw > Custom"),
	freestand_dist = slot_0_21_1:add_slider("freestand_dist", " > Max distance", 50, 300, 150),
	master_switch = slot_0_23_1:add_check_box("Enable anti-aim bulider", "Enable/disable anti-aim"),
	condition = slot_0_23_1:add_combo_box("Condition", false, {
		"Share",
		"Stand",
		"Run",
		"Air",
		"Crouch",
		"Crouch Air"
	}, "anti-aim>condition"),
	conditions = {
		is_visible = function()
			return slot_0_13_0.anti_aim.master_switch:get()
		end
	}
}
slot_0_24_1 = slot_0_14_2.ow.settings
slot_0_25_0 = slot_0_14_2.ow.style
slot_0_26_1 = slot_0_14_2.ow.create
slot_0_13_0.one_way = {
	enable = slot_0_24_1:add_check_box("Enable [Use bind]", "tooltip", "one_way_enable"),
	show = {
		main = slot_0_24_1:add_combo_box("Settings", true, {
			"Show only safe / unsafe",
			"Disable title for other side",
			"Visualization of \"from - to\""
		}, "one_way>main settings", "EN:\n\nShow only safe / unsafe - shows only those points near which the enemy is located" .. "\n\nDisable title for other side - removes the title and leaves a period" .. "\n\n\nRU:" .. "\n\nShow only safe / unsafe - показывает только те точки, рядом с которыми находится противник" .. "\n\nDisable title for other side - удаляет оглавление и оставляет только точку"),
		trigger_radius = slot_0_24_1:add_slider("1w>trigger_radius", "Enemy trigger radius", 100, 500, 200, nil, nil, "The range of enemy detection at the location [safe / unsafe]"),
		full = slot_0_24_1:add_slider("1w>full_visible", "Dist - full visible", 50, 300, 80, nil, nil),
		update_rate = slot_0_24_1:add_slider("1w>update_rate", "Update rate", 10, 150, 90, nil, nil, "Frequency of location updates by proximity | 10 - quality  150 - performance"),
		grid_size = slot_0_24_1:add_slider("1w>grid_size", "Grid size [soon]", 150, 400, 250, nil, nil, "The size of the location update area")
	},
	colors = {
		safe = slot_0_25_0:add_color_picker("1w>colors>safe", "Safe color", true, slot_0_12_0(120, 255, 140, 34)),
		unsafe = slot_0_25_0:add_color_picker("1w>colors>unsafe", "Unsafe color", true, slot_0_12_0(255, 100, 100, 40))
	}
}
slot_0_14_1 = slot_0_8_0._GR.gameplay.builder
slot_0_15_1 = {
	"Share",
	"Stand",
	"Run",
	"Air",
	"Crouch",
	"Crouch Air"
}
slot_0_16_1 = {
	"share",
	"stand",
	"run",
	"air",
	"crouch",
	"crouch_air"
}
slot_0_17_1 = slot_0_13_0.anti_aim.conditions

for iter_0_0 = 1, #slot_0_15_1 do
	slot_0_17_1[slot_0_16_1[iter_0_0]] = {
		enable = slot_0_16_1[iter_0_0] ~= "share" and slot_0_14_1:add_check_box(slot_0_15_1[iter_0_0], nil, ">cond"),
		params = {
			pitch = slot_0_14_1:add_combo_box("Pitch", false, {
				"None",
				"Down",
				"Up",
				"Zero",
				"Custom",
				"Fake"
			}, slot_0_16_1[iter_0_0]),
			pitch_params = {
				angle = slot_0_14_1:add_slider(slot_0_16_1[iter_0_0], " > Angle", -89, 89),
				is_visible = function()
					return slot_0_17_1[slot_0_16_1[iter_0_0]].params.pitch:get("Custom")
				end
			},
			pitch_jitter = slot_0_14_1:add_combo_box("Pitch jitter", false, {
				"None",
				"Center",
				"Offset"
			}, slot_0_16_1[iter_0_0]),
			pitch_jitter_params = {
				amount = slot_0_14_1:add_slider(slot_0_16_1[iter_0_0], " > Amount", -89, 89),
				way = slot_0_14_1:add_check_box(" > 3 way", nil, slot_0_16_1[iter_0_0]),
				is_visible = function()
					return not slot_0_17_1[slot_0_16_1[iter_0_0]].params.pitch_jitter:get("None")
				end
			},
			yaw_base = slot_0_14_1:add_combo_box("Yaw base", false, {
				"Viewangles",
				"At target"
			}, slot_0_16_1[iter_0_0] .. ">yaw"),
			yaw_jitter = slot_0_14_1:add_combo_box("Yaw jitter", false, {
				"None",
				"Center",
				"Offset"
			}, slot_0_16_1[iter_0_0] .. ">yaw"),
			yaw_jitter_params = {
				amount = slot_0_14_1:add_slider(slot_0_16_1[iter_0_0] .. ">yaw", " > Amount", -180, 180),
				way = slot_0_14_1:add_check_box(" > 3 way", nil, slot_0_16_1[iter_0_0] .. ">yaw"),
				is_visible = function()
					return not slot_0_17_1[slot_0_16_1[iter_0_0]].params.yaw_jitter:get("None")
				end
			},
			is_visible = function()
				return slot_0_16_1[iter_0_0] == "share" or slot_0_17_1[slot_0_16_1[iter_0_0]].enable:get()
			end
		},
		is_visible = function()
			return slot_0_13_0.anti_aim.condition:get(slot_0_15_1[iter_0_0])
		end
	}
end

slot_0_14_0 = {
	mt = {},
	funcs = {},
	delays = {},
	update_times = {},
	cache = {
		hotkeys = {}
	},
	target = {}
}
slot_0_15_0 = {
	manual_left = gui.ctx:find("rage>anti-aim>angles>manual override>override left"),
	manual_right = gui.ctx:find("rage>anti-aim>angles>manual override>override right"),
	manual_back = gui.ctx:find("rage>anti-aim>angles>manual override>override back"),
	manual_forward = gui.ctx:find("rage>anti-aim>angles>manual override>override forward"),
	yaw_override = gui.ctx:find("rage>anti-aim>angles>yaw>settings>amount"),
	no_spread = gui.ctx:find("rage>aimbot>nospread"),
	hide_shot = gui.ctx:find("rage>anti-aim>angles>hide shot"),
	double_tap = gui.ctx:find("rage>aimbot>doubletap"),
	duck_peek = gui.ctx:find("misc>movement>duck peek assist"),
	force_body = gui.ctx:find("rage>aimbot>general>force bodyaim"),
	force_shoot = gui.ctx:find("rage>aimbot>general>force shoot"),
	force_lethal_air = gui.ctx:find("rage>aimbot>general>force lethal in air"),
	force_head = gui.ctx:find("rage>aimbot>general>headshot only"),
	jump_bug = gui.ctx:find("misc>movement>jumpbug"),
	peek_assist = gui.ctx:find("misc>movement>peek assist"),
	edge_jump = gui.ctx:find("misc>movement>edge jump"),
	slow_walk = gui.ctx:find("misc>movement>slowwalk"),
	temp = {},
	rage = {
		bolt_hitchance = gui.ctx:find("rage>weapon>Bolt Snipers>weapon>hitchance"),
		scout_hitchance = gui.ctx:find("rage>weapon>SSG-08>weapon>hitchance"),
		bolt_pointscale = gui.ctx:find("rage>weapon>Bolt Snipers>weapon>pointscale"),
		scout_pointscale = gui.ctx:find("rage>weapon>SSG-08>weapon>pointscale"),
		bolt_autostop = gui.ctx:find("rage>weapon>Bolt Snipers>extra>autostop>settings>mode"),
		scout_autostop = gui.ctx:find("rage>weapon>SSG-08>extra>autostop>settings>mode")
	},
	legit = {
		penetration = gui.ctx:find("legit>general>penetration")
	},
	yaw = {
		yaw = gui.ctx:find("rage>anti-aim>angles>yaw"),
		yaw_amount = gui.ctx:find("rage>anti-aim>angles>yaw>settings>amount")
	}
}
slot_0_16_0 = {
	m_modelState = 352,
	m_pGameSceneNode = 824,
	m_nActualMoveType = 1326,
	m_steamID = 1920,
	TraceFilter = "E8 ? ? ? ? 48 81 4B ? ? ? ? ? 48 8D 05 ? ? ? ?",
	TraceShape = "48 89 5C 24 ? 48 89 4C 24 ? 55 57",
	TraceManager = "75 0E 48 8B 0D ? ? ? ? 33 D2",
	m_nNextPrimaryAttackTick = 6336,
	GlobalVars = "48 8B 05 ?? ?? ?? ?? 8B 48 04 FF C1"
}
slot_0_6_0 = {
	real_time = 0,
	update_time_delay = 0,
	is_loaded = false,
	global = {
		local_time = "00:00"
	},
	white_color = slot_0_12_0(),
	f_SYSTEMTIME = ffi.new("SYSTEMTIME"),
	C_GetLocalTime = ffi.cast("void(__stdcall*)(struct _SYSTEMTIME*)", utils.find_export("kernel32.dll", "GetLocalTime")),
	frame_time = game.global_vars.frame_time,
	tick_count = game.global_vars.tick_count,
	screen_size = slot_0_11_0(game.engine:get_screen_size()),
	killstreak_notify = {
		"DOUBLE",
		"TRIPLE",
		"UNSTOPPABLE",
		"RAMPAGE",
		"GODLIKE",
		"UNTOUCHABLE"
	},
	player_hitbox = {
		[0] = "generic",
		"head",
		"chest",
		"stomach",
		"left arm",
		"right arm",
		"left leg",
		"right leg",
		"neck",
		"generic",
		"gear"
	},
	icon_by_name = {
		crown = "b",
		clock = "R",
		pistol = "l",
		miss = "G",
		chart = "L",
		coins = "Y",
		buy = "K",
		hit = "j",
		cloud_storm = "T",
		cloud = "S",
		warning = "E",
		keyboard = "B",
		fire = "k",
		file_x = "f",
		bomb = "J",
		lightning = "I",
		bullet = "s",
		gear = "l",
		refresh = "t",
		discord = "r",
		online = "q",
		cloud_check = "U",
		file_export = "p",
		file_import = "o",
		hurt = "A",
		file_remove = "h",
		file_error = "g",
		file_check = "e",
		file = "d",
		palette = "D",
		taser = "H",
		user = "P",
		file_add = "i",
		light = "C"
	},
	custom_icon_from_weapon = {
		molotov = "k",
		inferno = "k",
		taser = "H",
		hegrenade = "J",
		knife = "E"
	},
	weapon_name_to_font = {
		p2000 = "1",
		["hkp-2000"] = "1",
		m4a4 = "q",
		["tec-9"] = "6",
		flashbang = "G",
		hegrenade = "H",
		smokegrenade = "I",
		molotov = "J",
		decoy = "F",
		knife = "A",
		revolver = "9",
		["m4a1-s"] = "r",
		["dual berettas"] = "4",
		["sg-553"] = "o",
		taser = "L",
		["glock-18"] = "0",
		["p-250"] = "3",
		["ak-47"] = "n",
		scar20 = "w",
		galil = "m",
		sg556 = "o",
		["ump-45"] = "c",
		inferno = "J",
		["mp5-sd"] = "x",
		mp9 = "b",
		["mac-10"] = "a",
		["r8 revolver"] = "9",
		ssg08 = "t",
		["mag-7"] = "i",
		["sawed-off"] = "h",
		["ssg-08"] = "t",
		["scar-20"] = "w",
		nova = "g",
		deagle = "8",
		elite = "4",
		fiveseven = "7",
		glock = "0",
		ak47 = "n",
		aug = "s",
		awp = "u",
		famas = "p",
		g3sg1 = "v",
		galilar = "m",
		m249 = "l",
		m4a1 = "q",
		mac10 = "a",
		p90 = "e",
		mp7 = "d",
		incgrenade = "K",
		ump45 = "c",
		xm1014 = "j",
		bizon = "f",
		mag7 = "i",
		negev = "k",
		sawedoff = "h",
		tec9 = "6",
		hkp2000 = "1",
		["usp-s"] = "2",
		["cz75-auto"] = "5",
		["five-seven"] = "7",
		p250 = "3"
	},
	weapon_by_index = {
		"Desert Eagle",
		"Dual Berettas",
		"Five-SeveN",
		"Glock-18",
		[31] = "Taser",
		[589885] = "Pistols",
		[11] = "G3SG1",
		[41] = "knife",
		[23] = "MP5-SD",
		[197117] = "knife",
		[589856] = "Pistols",
		[63] = "CZ75-Auto",
		[589826] = "Pistols",
		[197133] = "knife",
		[589858] = "SMGs",
		[47] = "Decoy",
		[589859] = "Shotguns",
		[589828] = "Pistols",
		[505] = "knife",
		[197118] = "knife",
		[507] = "knife",
		[506] = "knife",
		[509] = "knife",
		[508] = "knife",
		[197126] = "knife",
		[14] = "M249",
		[512] = "knife",
		[516] = "knife",
		[29] = "Sawed-Off",
		[521] = "knife",
		[523] = "knife",
		[589847] = "SMGs",
		[80] = "knife",
		[589854] = "Pistols",
		[196667] = "knife",
		[589848] = "SMGs",
		[589825] = "Desert Eagle",
		[7] = "AK-47",
		[197125] = "knife",
		[589849] = "Shotguns",
		[197127] = "knife",
		[589857] = "SMGs",
		[589827] = "Pistols",
		[589850] = "SMGs",
		[28] = "Negev",
		[503] = "knife",
		[26] = "Bizon",
		[589851] = "Shotguns",
		[589860] = "Pistols",
		[61] = "USP-S",
		[515] = "knife",
		[514] = "knife",
		[589852] = "Rifle",
		[197120] = "knife",
		[589837] = "Rifle",
		[519] = "knife",
		[589884] = "Rifle",
		[197128] = "knife",
		[589838] = "Rifle",
		[520] = "knife",
		[522] = "knife",
		[525] = "knife",
		[27] = "Mag-7",
		[48] = "CT_Molotov",
		[197113] = "knife",
		[46] = "Molotov",
		[589840] = "Rifle",
		[197119] = "knife",
		[19] = "P90",
		[197121] = "knife",
		[589841] = "SMGs",
		[45] = "Smoke",
		[262205] = "Pistols",
		[197129] = "knife",
		[32] = "P2000",
		[44] = "Hegrenade",
		[43] = "Flash",
		[9] = "AWP",
		[589843] = "SMGs",
		[589833] = "AWP",
		[24] = "UMP-45",
		[33] = "MP7",
		[589862] = "SCAR-20",
		[518] = "knife",
		[40] = "SSG-08",
		[589864] = "SSG-08",
		[197122] = "knife",
		[13] = "Galil",
		[38] = "SCAR-20",
		[34] = "MP9",
		[589888] = "R8 Revolver",
		[64] = "R8 Revolver",
		[262208] = "R8 Revolver",
		[589831] = "Rifle",
		[35] = "Nova",
		[25] = "XM1014",
		[39] = "SG-553",
		[197115] = "knife",
		[8] = "AUG",
		[589863] = "Rifle",
		[589832] = "Rifle",
		[17] = "Mac-10",
		[197123] = "knife",
		[10] = "FAMAS",
		[36] = "P250",
		[196650] = "knife",
		[197114] = "knife",
		[30] = "Tec-9",
		[589834] = "Rifle",
		[589835] = "G3SG1",
		[197108] = "knife",
		[60] = "M4A1-S",
		[16] = "M4A4",
		[262167] = "SMGs",
		[197116] = "knife",
		[589887] = "Pistols",
		[59] = "knife",
		[517] = "knife",
		[42] = "knife",
		[197124] = "knife",
		[589853] = "Shotguns"
	},
	weapon_group_by_index = {
		"Heavy Pistols",
		"Pistols",
		"Pistols",
		"Pistols",
		[31] = "taser",
		[589885] = "Pistols",
		[11] = "Auto Snipers",
		[41] = "knife",
		[23] = "SMGs",
		[197117] = "knife",
		[589856] = "Pistols",
		[63] = "Pistols",
		[589826] = "Pistols",
		[197133] = "knife",
		[589858] = "SMGs",
		[47] = "grenade",
		[589859] = "Heavy",
		[589828] = "Pistols",
		[505] = "knife",
		[197118] = "knife",
		[507] = "knife",
		[506] = "knife",
		[509] = "knife",
		[508] = "knife",
		[197126] = "knife",
		[14] = "Rifles",
		[512] = "knife",
		[516] = "knife",
		[29] = "Heavy",
		[521] = "knife",
		[523] = "knife",
		[589847] = "SMGs",
		[80] = "knife",
		[589854] = "Pistols",
		[196667] = "knife",
		[589848] = "SMGs",
		[589825] = "Heavy Pistols",
		[7] = "Rifles",
		[197125] = "knife",
		[589849] = "Heavy",
		[197127] = "knife",
		[589857] = "SMGs",
		[589827] = "Pistols",
		[589850] = "SMGs",
		[28] = "Rifles",
		[503] = "knife",
		[26] = "SMGs",
		[589851] = "Heavy",
		[589860] = "Pistols",
		[61] = "Pistols",
		[515] = "knife",
		[514] = "knife",
		[589852] = "Rifles",
		[197120] = "knife",
		[589837] = "Rifles",
		[519] = "knife",
		[589884] = "Rifles",
		[197128] = "knife",
		[589838] = "Rifles",
		[520] = "knife",
		[522] = "knife",
		[525] = "knife",
		[27] = "Heavy",
		[48] = "grenade",
		[197113] = "knife",
		[46] = "grenade",
		[589840] = "Rifles",
		[197119] = "knife",
		[19] = "SMGs",
		[197121] = "knife",
		[589841] = "SMGs",
		[45] = "grenade",
		[262205] = "Pistols",
		[197129] = "knife",
		[32] = "Pistols",
		[44] = "grenade",
		[43] = "grenade",
		[589862] = "Auto Snipers",
		[589843] = "SMGs",
		[518] = "knife",
		[24] = "SMGs",
		[33] = "SMGs",
		[9] = "Bolt Snipers",
		[589833] = "Bolt Snipers",
		[40] = "Bolt Snipers",
		[589864] = "Bolt Snipers",
		[197122] = "knife",
		[13] = "Rifles",
		[38] = "Auto Snipers",
		[34] = "SMGs",
		[589888] = "Heavy Pistols",
		[64] = "Heavy Pistols",
		[262208] = "Heavy Pistols",
		[589831] = "Rifles",
		[35] = "Heavy",
		[25] = "Heavy",
		[39] = "Rifles",
		[197115] = "knife",
		[8] = "Rifles",
		[589863] = "Rifles",
		[589832] = "Rifles",
		[17] = "SMGs",
		[197123] = "knife",
		[10] = "Rifles",
		[36] = "Pistols",
		[196650] = "knife",
		[197114] = "knife",
		[30] = "Pistols",
		[589834] = "Rifles",
		[589835] = "Auto Snipers",
		[197108] = "knife",
		[60] = "Rifles",
		[16] = "Rifles",
		[262167] = "SMGs",
		[197116] = "knife",
		[589887] = "Pistols",
		[59] = "knife",
		[517] = "knife",
		[42] = "knife",
		[197124] = "knife",
		[589853] = "Heavy"
	},
	get_local_time = function()
		if slot_0_6_0.update_time_delay < slot_0_6_0.real_time then
			slot_0_6_0.update_time_delay = slot_0_6_0.real_time + 10

			slot_0_6_0.C_GetLocalTime(slot_0_6_0.f_SYSTEMTIME)

			local var_73_0 = slot_0_6_0.f_SYSTEMTIME.wHour
			local var_73_1 = slot_0_6_0.f_SYSTEMTIME.wMinute

			slot_0_6_0.global.local_time = string.format("%s:%s", (var_73_0 < 10 and "0" or "") .. tostring(var_73_0), (var_73_1 < 10 and "0" or "") .. tostring(var_73_1))
		end

		return slot_0_6_0.global.local_time
	end,
	taskbar_notify = (function()
		ffi.cdef("  \n            typedef struct {\n                unsigned long   cbSize;\n                void*    hwnd;\n                unsigned int    dwFlags;\n                unsigned int    uCount;\n                unsigned int    dwTimeout;\n            } FLASHWINFO;\n        ")

		local var_74_0 = ffi.cast("void*(__stdcall*)(const char*, const char*)", utils.find_export("user32.dll", "FindWindowA"))
		local var_74_1 = ffi.cast("void*(__stdcall*)()", utils.find_export("user32.dll", "GetActiveWindow"))
		local var_74_2 = ffi.cast("bool(__stdcall*)(FLASHWINFO*)", utils.find_export("user32.dll", "FlashWindowEx"))
		local var_74_3 = ffi.new("FLASHWINFO")
		local var_74_4 = var_74_0(nil, "Counter-Strike 2")

		return function()
			if var_74_4 ~= ffi.cast("void*", 0) and var_74_1() ~= var_74_4 then
				local var_75_0 = var_74_3

				var_75_0.cbSize = ffi.sizeof("FLASHWINFO")
				var_75_0.hwnd = var_74_4
				var_75_0.dwFlags = 2
				var_75_0.uCount = 5
				var_75_0.dwTimeout = 0

				var_74_2(var_75_0)
			end
		end
	end)(),
	hotkeys_list = {
		global = {
			{
				state = "visible",
				title = "Menu is",
				crosshair = false,
				active = function(arg_76_0)
					return slot_0_6_0.menu_visible
				end
			}
		},
		rage = {
			{
				crosshair_desc = "",
				state = " ",
				title = "DT Knifebot",
				crosshair_title = "KnifeBot",
				active = function(arg_77_0)
					return slot_0_13_0.misc.knife_bot:element():get_hotkey_state()
				end
			},
			{
				title = "Freestand",
				crosshair_title = "Freestand: ",
				active = function(arg_78_0)
					local var_78_0 = slot_0_5_0.vars.freestand
					local var_78_1 = var_78_0.active and (var_78_0.side == -1 and "left" or var_78_0.side == 1 and "right") or slot_0_13_0.anti_aim.freestand and slot_0_13_0.anti_aim.freestand:get() and "wait" or nil

					if var_78_1 then
						arg_78_0.state = var_78_1
						arg_78_0.crosshair_desc = var_78_1 == "left" and "<" or var_78_1 == "right" and ">" or "-"

						return true
					end

					return false
				end
			},
			{
				title = "Manual",
				crosshair_title = "Manual: ",
				active = function(arg_79_0)
					if not slot_0_15_0.manual_left then
						return false
					end

					local var_79_0 = slot_0_15_0.manual_left:get_value():get() and "left" or slot_0_15_0.manual_right:get_value():get() and "right" or slot_0_15_0.manual_back:get_value():get() and "back" or slot_0_15_0.manual_forward:get_value():get() and "forward" or nil

					if var_79_0 then
						arg_79_0.state = var_79_0
						arg_79_0.crosshair_desc = var_79_0 == "left" and "<" or var_79_0 == "right" and ">" or var_79_0 == "back" and "v" or var_79_0 == "forward" and "^" or "-"

						return true
					end

					return false
				end
			},
			{
				title = "Min damage",
				crosshair_title = "Min.D: ",
				active = function(arg_80_0)
					local var_80_0 = slot_0_14_0:get("get_weapon_id")

					if not slot_0_6_0.weapon_group_by_index[var_80_0] then
						return false
					end

					slot_0_15_0.temp.min_damage = slot_0_15_0.temp.min_damage or {}

					if not slot_0_15_0.temp.min_damage[var_80_0] then
						slot_0_15_0.temp.min_damage[var_80_0] = gui.ctx:find(string.format("rage>weapon>%s>weapon>mindamage", slot_0_6_0.weapon_by_index[var_80_0])) or gui.ctx:find(string.format("rage>weapon>%s>weapon>mindamage", slot_0_6_0.weapon_group_by_index[var_80_0])) or gui.ctx:find(string.format("rage>weapon>%s>weapon>mindamage", "general"))
					end

					local var_80_1 = slot_0_15_0.temp.min_damage[var_80_0]

					if not var_80_1 then
						return false
					end

					if not var_80_1.get_hotkey_state or not var_80_1:get_hotkey_state() then
						return false
					end

					arg_80_0.state = tostring(var_80_1:get_value():get())
					arg_80_0.crosshair_desc = arg_80_0.state

					return true
				end
			},
			{
				title = "Hitchance",
				crosshair_title = "Hitchance: ",
				crosshair_desc = "0",
				active = function(arg_81_0)
					local var_81_0 = slot_0_14_0:get("get_weapon_id")

					if not slot_0_6_0.weapon_group_by_index[var_81_0] then
						return false
					end

					slot_0_15_0.temp.hitchance = slot_0_15_0.temp.hitchance or {}

					if not slot_0_15_0.temp.hitchance[var_81_0] then
						slot_0_15_0.temp.hitchance[var_81_0] = gui.ctx:find(string.format("rage>weapon>%s>weapon>hitchance", slot_0_6_0.weapon_by_index[var_81_0])) or gui.ctx:find(string.format("rage>weapon>%s>weapon>hitchance", slot_0_6_0.weapon_group_by_index[var_81_0])) or gui.ctx:find(string.format("rage>weapon>%s>weapon>hitchance", "general"))
					end

					local var_81_1 = slot_0_15_0.temp.hitchance[var_81_0]

					if not var_81_1 then
						return false
					end

					if not var_81_1.get_hotkey_state or not var_81_1:get_hotkey_state() then
						return false
					end

					arg_81_0.state = tostring(var_81_1:get_value():get()) .. "%"
					arg_81_0.crosshair_desc = tostring(var_81_1:get_value():get())

					return true
				end
			},
			{
				state = "on",
				title = "No spread",
				active = slot_0_15_0.no_spread
			},
			{
				title = "Hitbox override",
				crosshair_title = "Hitbox: ",
				active = function(arg_82_0)
					local var_82_0 = slot_0_14_0:get("get_weapon_id")

					if not slot_0_6_0.weapon_group_by_index[var_82_0] then
						return false
					end

					slot_0_15_0.temp.hitboxes = slot_0_15_0.temp.hitboxes or {}

					if not slot_0_15_0.temp.hitboxes[var_82_0] then
						slot_0_15_0.temp.hitboxes[var_82_0] = gui.ctx:find(string.format("rage>weapon>%s>weapon>hitboxes", slot_0_6_0.weapon_by_index[var_82_0])) or gui.ctx:find(string.format("rage>weapon>%s>weapon>hitboxes", slot_0_6_0.weapon_group_by_index[var_82_0])) or gui.ctx:find(string.format("rage>weapon>%s>weapon>hitboxes", "general"))
					end

					local var_82_1 = slot_0_15_0.temp.hitboxes[var_82_0]

					if not var_82_1 then
						return false
					end

					if not var_82_1.get_hotkey_state or not var_82_1:get_hotkey_state() then
						return false
					end

					local var_82_2 = var_82_1:get_value():get():get_raw()
					local var_82_3 = bit.band(var_82_2, 1) == 1
					local var_82_4 = bit.band(var_82_2, 4) == 4 or bit.band(var_82_2, 8) == 8
					local var_82_5 = bit.band(var_82_2, 16) == 16 or bit.band(var_82_2, 32) == 32

					arg_82_0.state = var_82_2 == 0 and "none" or string.format("%s", var_82_2 > 1 and var_82_3 and "head+" or var_82_3 and "head" or var_82_2 > 15 and var_82_4 and "body+" or var_82_4 and "body" or var_82_5 and "legs" or bit.band(var_82_2, 64) == 64 and "arms" or "")
					arg_82_0.crosshair_desc = arg_82_0.state

					return true
				end
			},
			{
				title = "Yaw override",
				crosshair_title = "Yaw: ",
				crosshair_desc = "0",
				active = function(arg_83_0)
					if not bit.band(slot_0_15_0.yaw.yaw:get_value():get():get_raw() or 0, 4) == 4 then
						return false
					end

					if not slot_0_15_0.yaw.yaw_amount:get_hotkey_state() then
						return false
					end

					arg_83_0.state = tostring(slot_0_15_0.yaw.yaw_amount:get_value():get()) .. "°"
					arg_83_0.crosshair_desc = arg_83_0.state

					return true
				end
			},
			{
				state = "on",
				title = "Double tap",
				active = slot_0_15_0.double_tap
			},
			{
				state = "on",
				title = "Hide shot",
				active = slot_0_15_0.hide_shot
			},
			{
				state = "on",
				title = "Duck peek",
				active = slot_0_15_0.duck_peek
			},
			{
				state = "on",
				title = "Force body",
				active = slot_0_15_0.force_body
			},
			{
				state = "on",
				title = "Force shoot",
				active = slot_0_15_0.force_shoot
			},
			{
				state = "on",
				title = "Force lethal air",
				active = slot_0_15_0.force_lethal_air
			},
			{
				state = "on",
				title = "Force head",
				active = slot_0_15_0.force_head
			},
			{
				state = "on",
				title = "Jump bug",
				active = slot_0_15_0.jump_bug
			},
			{
				state = "on",
				title = "Peek assist",
				active = slot_0_15_0.peek_assist
			},
			{
				state = "on",
				title = "Edge jump",
				active = slot_0_15_0.edge_jump
			},
			{
				state = "on",
				title = "Slow walk",
				active = slot_0_15_0.slow_walk
			}
		},
		legit = {
			{
				state = "on",
				title = "Penetration",
				active = slot_0_15_0.legit.penetration
			},
			{
				state = "on",
				title = "Triggerbot",
				active = function(arg_84_0)
					local var_84_0 = slot_0_14_0:get("get_weapon_id")

					if not slot_0_6_0.weapon_group_by_index[var_84_0] then
						return false
					end

					slot_0_15_0.temp.l_Triggerbot = slot_0_15_0.temp.l_Triggerbot or {}

					if not slot_0_15_0.temp.l_Triggerbot[var_84_0] then
						slot_0_15_0.temp.l_Triggerbot[var_84_0] = gui.ctx:find(string.format("legit>weapon>%s>trigger>triggerbot", slot_0_6_0.weapon_by_index[var_84_0])) or gui.ctx:find(string.format("legit>weapon>%s>trigger>triggerbot", slot_0_6_0.weapon_group_by_index[var_84_0])) or gui.ctx:find(string.format("legit>weapon>%s>trigger>triggerbot", "general"))
					end

					local var_84_1 = slot_0_15_0.temp.l_Triggerbot[var_84_0]

					if not var_84_1 then
						return false
					end

					if not var_84_1.get_hotkey_state or not var_84_1:get_hotkey_state() then
						return false
					end

					return true
				end
			},
			{
				state = "on",
				title = "Aim assist",
				active = function(arg_85_0)
					local var_85_0 = slot_0_14_0:get("get_weapon_id")

					if not slot_0_6_0.weapon_group_by_index[var_85_0] then
						return false
					end

					slot_0_15_0.temp.l_aim_assist = slot_0_15_0.temp.l_aim_assist or {}

					if not slot_0_15_0.temp.l_aim_assist[var_85_0] then
						slot_0_15_0.temp.l_aim_assist[var_85_0] = gui.ctx:find(string.format("legit>weapon>%s>aim>aim assist", slot_0_6_0.weapon_by_index[var_85_0])) or gui.ctx:find(string.format("legit>weapon>%s>aim>aim assist", slot_0_6_0.weapon_group_by_index[var_85_0])) or gui.ctx:find(string.format("legit>weapon>%s>aim>aim assist", "general"))
					end

					local var_85_1 = slot_0_15_0.temp.l_aim_assist[var_85_0]

					if not var_85_1 then
						return false
					end

					if not var_85_1.get_hotkey_state or not var_85_1:get_hotkey_state() then
						return false
					end

					return true
				end
			},
			{
				title = "Trigger: hitchance",
				active = function(arg_86_0)
					local var_86_0 = slot_0_14_0:get("get_weapon_id")

					if not slot_0_6_0.weapon_group_by_index[var_86_0] then
						return false
					end

					slot_0_15_0.temp.l_trigger_hitch = slot_0_15_0.temp.l_trigger_hitch or {}

					if not slot_0_15_0.temp.l_trigger_hitch[var_86_0] then
						slot_0_15_0.temp.l_trigger_hitch[var_86_0] = gui.ctx:find(string.format("legit>weapon>%s>trigger>hitchance", slot_0_6_0.weapon_by_index[var_86_0])) or gui.ctx:find(string.format("legit>weapon>%s>trigger>hitchance", slot_0_6_0.weapon_group_by_index[var_86_0])) or gui.ctx:find(string.format("legit>weapon>%s>trigger>hitchance", "general"))
					end

					local var_86_1 = slot_0_15_0.temp.l_trigger_hitch[var_86_0]

					if not var_86_1 then
						return false
					end

					if not var_86_1.get_hotkey_state or not var_86_1:get_hotkey_state() then
						return false
					end

					arg_86_0.state = tostring(var_86_1:get_value():get())

					return true
				end
			},
			{
				title = "Trigger: min damage",
				active = function(arg_87_0)
					local var_87_0 = slot_0_14_0:get("get_weapon_id")

					if not slot_0_6_0.weapon_group_by_index[var_87_0] then
						return false
					end

					slot_0_15_0.temp.t_min_damage = slot_0_15_0.temp.t_min_damage or {}

					if not slot_0_15_0.temp.t_min_damage[var_87_0] then
						slot_0_15_0.temp.t_min_damage[var_87_0] = gui.ctx:find(string.format("legit>weapon>%s>trigger>mindamage", slot_0_6_0.weapon_by_index[var_87_0])) or gui.ctx:find(string.format("legit>weapon>%s>trigger>mindamage", slot_0_6_0.weapon_group_by_index[var_87_0])) or gui.ctx:find(string.format("legit>weapon>%s>trigger>mindamage", "general"))
					end

					local var_87_1 = slot_0_15_0.temp.t_min_damage[var_87_0]

					if not var_87_1 then
						return false
					end

					if not var_87_1.get_hotkey_state or not var_87_1:get_hotkey_state() then
						return false
					end

					arg_87_0.state = tostring(var_87_1:get_value():get())

					return true
				end
			},
			{
				title = "L. Min damage",
				active = function(arg_88_0)
					local var_88_0 = slot_0_14_0:get("get_weapon_id")

					if not slot_0_6_0.weapon_group_by_index[var_88_0] then
						return false
					end

					slot_0_15_0.temp.l_min_damage = slot_0_15_0.temp.l_min_damage or {}

					if not slot_0_15_0.temp.l_min_damage[var_88_0] then
						slot_0_15_0.temp.l_min_damage[var_88_0] = gui.ctx:find(string.format("legit>weapon>%s>aim>mindamage", slot_0_6_0.weapon_by_index[var_88_0])) or gui.ctx:find(string.format("legit>weapon>%s>aim>mindamage", slot_0_6_0.weapon_group_by_index[var_88_0])) or gui.ctx:find(string.format("legit>weapon>%s>aim>mindamage", "general"))
					end

					local var_88_1 = slot_0_15_0.temp.l_min_damage[var_88_0]

					if not var_88_1 then
						return false
					end

					if not var_88_1.get_hotkey_state or not var_88_1:get_hotkey_state() then
						return false
					end

					arg_88_0.state = tostring(var_88_1:get_value():get())

					return true
				end
			},
			{
				title = "L. Backtrack",
				active = function(arg_89_0)
					local var_89_0 = slot_0_14_0:get("get_weapon_id")

					if not slot_0_6_0.weapon_group_by_index[var_89_0] then
						return false
					end

					slot_0_15_0.temp.l_backtrack = slot_0_15_0.temp.l_backtrack or {}

					if not slot_0_15_0.temp.l_backtrack[var_89_0] then
						slot_0_15_0.temp.l_backtrack[var_89_0] = gui.ctx:find(string.format("legit>weapon>%s>backtrack>backtrack", slot_0_6_0.weapon_by_index[var_89_0])) or gui.ctx:find(string.format("legit>weapon>%s>backtrack>backtrack", slot_0_6_0.weapon_group_by_index[var_89_0])) or gui.ctx:find(string.format("legit>weapon>%s>backtrack>backtrack", "general"))
					end

					local var_89_1 = slot_0_15_0.temp.l_backtrack[var_89_0]

					if not var_89_1 then
						return false
					end

					if not var_89_1.get_hotkey_state or not var_89_1:get_hotkey_state() then
						return false
					end

					arg_89_0.state = tostring(var_89_1:get_value():get()) .. "ms"

					return true
				end
			}
		}
	}
}
slot_0_6_0.screen_point = slot_0_11_0(slot_0_6_0.screen_size.x / 1000, slot_0_6_0.screen_size.y / 1000)
slot_0_17_0 = {
	list = {
		["server-connect"] = {
			en = {
				"Connect to server",
				"Establishing a secure connection",
				"Checking server status"
			},
			ru = {
				"Подключение к серверу",
				"Устанавливаем безопасное соединение",
				"Проверяем статус сервера"
			}
		},
		["server-offsets"] = {
			en = {
				"Protect you from crashes...",
				"Convincing the system not to crash",
				"Tidying up memory",
				"Synchronizing data",
				"Resolving potential conflicts"
			},
			ru = {
				"Защищаем от крашей",
				"Убеждаем систему не ломаться",
				"Наводим порядок в памяти",
				"Синхронизируем данные",
				"Устраняем потенциальные конфликты"
			}
		},
		["server-notify"] = {
			en = {
				"Checking your digital mailbox for spam",
				"Gossiping with the database about updates",
				"Finding all the things you missed",
				"Sorting through digital spam",
				"Loading all the interesting stuff",
				"Searching for urgent news in the clutter",
				"Checking for new messages",
				"Finding everything you missed while resting"
			},
			ru = {
				"Разгребаем цифровой спам",
				"Загружаем все самое интересное",
				"Ищем срочные новости в куче хлама",
				"Проверяем наличие новых сообщений",
				"Ищем все, что вы пропустили, пока отдыхали"
			}
		},
		["failed-auth-3"] = {
			en = {
				"Waiting time exceeded",
				"We waited. We waited longer. Still waiting.",
				"Waiting time exceeded",
				"Target server is unresponsive. Possibly on fire.",
				"We waited. We waited longer. Got tired of waiting.",
				"Did not receive a response from the server"
			},
			ru = {
				"Превышено время ожидания",
				"Целевой сервер не отвечает. Возможно, он в огне.",
				"Ждали. Еще ждали. Устали ждать.",
				"Не дождались ответа от сервера"
			}
		},
		["failed-auth-0"] = {
			en = {
				"Failed auth [0]. Synchronize time in windows"
			},
			ru = {
				"Ошибка аутентификации [0]. Синхронизируйте время в Windows"
			}
		},
		["failed-auth-1"] = {
			en = {
				"Failed auth [1]. Try reload"
			},
			ru = {
				"Ошибка аутентификации [1]. Попробуйте перезагрузить"
			}
		}
	},
	lang = (function()
		local var_90_0 = ffi.cast("int(__stdcall*)(unsigned int, unsigned int, void*, int)", utils.find_export("kernel32.dll", "GetLocaleInfoA"))
		local var_90_1 = var_90_0(1024, 89, nil, 0)

		if var_90_1 == 0 then
			return "en"
		end

		local var_90_2 = ffi.new("char[?]", var_90_1)

		if var_90_0(1024, 89, var_90_2, var_90_1) > 0 then
			local var_90_3 = ffi.string(var_90_2)

			return (var_90_3 == "ru" or var_90_3 == "en") and var_90_3 or "en"
		end

		return "en"
	end)(),
	get = function(arg_91_0, arg_91_1, arg_91_2)
		return arg_91_0.list[arg_91_1] and arg_91_0.list[arg_91_1][arg_91_0.lang] and arg_91_0.list[arg_91_1][arg_91_0.lang][arg_91_2 or 1] or arg_91_0.list[arg_91_1] and arg_91_0.list[arg_91_1].en and arg_91_0.list[arg_91_1].en[arg_91_2 or 1] or "none"
	end,
	get_random = function(arg_92_0, arg_92_1)
		local var_92_0 = arg_92_0.list[arg_92_1] and arg_92_0.list[arg_92_1][arg_92_0.lang] or arg_92_0.list[arg_92_1] and arg_92_0.list[arg_92_1].en or {
			""
		}

		return var_92_0[math.random(1, #var_92_0)]
	end
}

function math.round(arg_93_0)
	return math.floor(arg_93_0 + 0.5)
end

function math.bounded_lerp(arg_94_0, arg_94_1, arg_94_2, arg_94_3, arg_94_4)
	if arg_94_4 then
		arg_94_0 = math.lerp(arg_94_0, arg_94_2 + 0.5, slot_0_6_0.frame_time * arg_94_3)
	else
		arg_94_0 = math.lerp(arg_94_0, arg_94_1 - 0.5, slot_0_6_0.frame_time * arg_94_3)
	end

	arg_94_0 = math.clamp(arg_94_0, arg_94_1, arg_94_2)

	return arg_94_0
end

function math.lerp_color(arg_95_0, arg_95_1, arg_95_2)
	return (slot_0_12_0(math.lerp(arg_95_0:get_r(), arg_95_1:get_r(), arg_95_2), math.lerp(arg_95_0:get_g(), arg_95_1:get_g(), arg_95_2), math.lerp(arg_95_0:get_b(), arg_95_1:get_b(), arg_95_2), math.lerp(arg_95_0:get_a(), arg_95_1:get_a(), arg_95_2)))
end

function math.lerp_vector(arg_96_0, arg_96_1, arg_96_2)
	return slot_0_11_0(math.lerp(arg_96_0.x, arg_96_1.x, arg_96_2), math.lerp(arg_96_0.y, arg_96_1.y, arg_96_2), arg_96_0.z and math.lerp(arg_96_0.z, arg_96_1.z, arg_96_2))
end

function math.cricle_animation(arg_97_0, arg_97_1, arg_97_2, arg_97_3, arg_97_4)
	local var_97_0 = arg_97_0.x + arg_97_1 * math.cos((arg_97_2 + arg_97_3 * arg_97_4) * 0.0174)
	local var_97_1 = arg_97_0.y + arg_97_1 * math.sin((arg_97_2 + arg_97_3 * arg_97_4) * 0.0174)

	return slot_0_11_0(var_97_0, var_97_1)
end

function math.calc_dist(arg_98_0, arg_98_1)
	if arg_98_1.z then
		return math.sqrt((arg_98_0.x - arg_98_1.x)^2 + (arg_98_0.y - arg_98_1.y)^2 + (arg_98_0.z - arg_98_1.z)^2)
	end

	return math.sqrt((arg_98_0.x - arg_98_1.x)^2 + (arg_98_0.y - arg_98_1.y)^2)
end

function math.multiply_vector(arg_99_0, arg_99_1)
	if arg_99_0.z then
		return slot_0_11_0(arg_99_0.x * arg_99_1, arg_99_0.y * arg_99_1, arg_99_0.z * arg_99_1)
	end

	return slot_0_11_0(arg_99_0.x * arg_99_1, arg_99_0.y * arg_99_1)
end

function math.add_vector(arg_100_0, arg_100_1)
	if arg_100_0.z then
		return slot_0_11_0(arg_100_0.x + arg_100_1.x, arg_100_0.y + arg_100_1.y, arg_100_0.z + arg_100_1.z)
	end

	return slot_0_11_0(arg_100_0.x + arg_100_1.x, arg_100_0.y + arg_100_1.y)
end

function math.calc_nearest_position(arg_101_0, arg_101_1, arg_101_2)
	local var_101_0 = math.calc_dist(arg_101_0, arg_101_2)
	local var_101_1 = slot_0_11_0(arg_101_1.x - arg_101_0.x, arg_101_1.y - arg_101_0.y, arg_101_1.z - arg_101_0.z)
	local var_101_2 = math.multiply_vector(var_101_1, 1 / var_101_1:length() * var_101_0)

	return slot_0_11_0(arg_101_0.x + var_101_2.x, arg_101_0.y + var_101_2.y, arg_101_0.z + var_101_2.z)
end

function math.calc_backtrack(arg_102_0, arg_102_1, arg_102_2)
	if not arg_102_0 then
		return -1
	end

	if arg_102_0:get_abs_velocity():length() < 3 then
		return 0
	end

	local var_102_0 = math.calc_dist(arg_102_1, arg_102_2)

	return math.max(0, var_102_0 - 19)
end

function math.angle_to_vector(arg_103_0)
	local var_103_0 = math.cos(arg_103_0.x * 0.0174)
	local var_103_1 = math.sin(arg_103_0.x * 0.0174)
	local var_103_2 = math.cos(arg_103_0.y * 0.0174)
	local var_103_3 = math.sin(arg_103_0.y * 0.0174)
	local var_103_4 = math.sin(arg_103_0.z * 0.0174)
	local var_103_5 = slot_0_11_0(0, 0, 0)

	var_103_5.x = var_103_0 * var_103_2
	var_103_5.y = var_103_0 * var_103_3
	var_103_5.z = -var_103_1

	return var_103_5
end

function math.angle_to_yaw_vector(arg_104_0)
	local var_104_0 = math.pi / 180

	return slot_0_11_0(math.cos(var_104_0 * arg_104_0), math.sin(var_104_0 * arg_104_0), 0)
end

function math.text_by_alpha(arg_105_0, arg_105_1, arg_105_2)
	if arg_105_1 == 0 then
		return ""
	elseif arg_105_1 == 1 then
		return arg_105_0
	end

	arg_105_0 = arg_105_0 or "err"

	return arg_105_2 and string.sub(arg_105_0, #arg_105_0 - #arg_105_0 * arg_105_1, -1) or string.sub(arg_105_0, 0, math.floor(#arg_105_0 * arg_105_1)) or ""
end

function math.bit_index(arg_106_0, arg_106_1)
	return bit.band(arg_106_0, 2^(arg_106_1 - 1)) ~= 0
end

ffi.cdef("    typedef struct Vector_xyz\n    {\n        float x;\n        float y;\n        float z;\n    } Vector; \n")

slot_0_18_0 = (function()
	local function var_107_0()
		local var_108_0 = utils.find_export("kernel32.dll", "GetSystemWindowsDirectoryW")

		if var_108_0 == 0 then
			return
		end

		local var_108_1 = ffi.cast("uint32_t(__stdcall*)(wchar_t*, uint32_t)", var_108_0)
		local var_108_2 = ffi.new("wchar_t[260]")
		local var_108_3 = var_108_1(var_108_2, 260)

		if var_108_3 > 0 then
			return ffi.string(var_108_2, var_108_3 * 2):sub(0, 1)
		end

		return "C"
	end

	local var_107_1 = false
	local var_107_2 = var_107_0()
	local var_107_3 = slot_0_2_0()

	local function var_107_4(arg_109_0, arg_109_1, arg_109_2, arg_109_3, arg_109_4, arg_109_5, arg_109_6)
		if not arg_109_1:find(":") then
			local var_109_0 = var_107_2

			arg_109_1 = string.format("%s:\\Windows\\Fonts\\%s", var_109_0, arg_109_1)
		end

		local var_109_1 = (arg_109_0 and draw.font_gdi or draw.font)(arg_109_1, arg_109_2, arg_109_3, arg_109_4 or 0, arg_109_5 or 2048, arg_109_6)

		var_109_1:create()

		return var_109_1
	end

	local function var_107_5(arg_110_0, arg_110_1, arg_110_2, arg_110_3, arg_110_4)
		local var_110_0 = arg_110_0

		if not var_110_0:find(":") then
			var_110_0 = string.format("%s/%s", var_107_3, var_110_0)
		end

		local var_110_1 = draw.font(var_110_0, arg_110_1, arg_110_2, arg_110_3 or 0, arg_110_4 or 2048)

		var_110_1:create()

		if var_110_1:get_text_size("m", true).y == 0 then
			var_110_1:destroy()

			if not var_107_1 then
				var_107_1 = true

				gui.notify:add(gui.notification("Mercury: Font loading error", "Check if all fonts are loaded [ game\\csgo\\fatality\\mercury\\ ]"))
				gui.notify:add(gui.notification("Mercury: Ошибка загрузки шрифта", "Проверьте, все ли шрифты загружены [ game\\csgo\\fatality\\mercury\\ ]"))
				print(string.format("\n\n\ncurrent file: %s\nactive path: %s \n\n\n", arg_110_0, var_110_0))
			end

			var_110_1 = var_107_4(false, arg_110_0, arg_110_1, arg_110_2, arg_110_3, arg_110_4)

			var_110_1:create()

			return var_110_1
		end

		return var_110_1
	end

	local function var_107_6()
		return
	end

	local var_107_7 = draw.font_flags
	local var_107_8 = {
		static = {
			alata_11 = var_107_5("alata.ttf", 11, var_107_7.no_dpi),
			auth = var_107_4(true, "Verdana.ttf", 14, bit.bor(var_107_7.no_kern, var_107_7.anti_alias, var_107_7.no_dpi), nil, nil, 600)
		},
		alata_main = var_107_5("alata.ttf", 11),
		alata_mini = var_107_5("alata.ttf", 10),
		verdana = var_107_4(false, "Verdana.ttf", 11, bit.bor(var_107_7.light), nil, nil, 400),
		verdanab = var_107_4(false, "verdanab.ttf", 11, bit.bor(var_107_7.light), nil, nil, 400),
		veradnab_mini = var_107_4(false, "verdanab.ttf", 9, bit.bor(var_107_7.light), nil, nil, 400),
		rage_logs = var_107_4(false, "Verdana.ttf", 11, bit.bor(var_107_7.light), nil, nil, 400),
		one_way = var_107_5("alata.ttf", 13),
		one_way_mini = var_107_5("alata.ttf", 11),
		keybinds = var_107_5("alata.ttf", 10),
		icons = {
			mercury = var_107_5("Mercury-icons-v1.ttf", 11),
			mercury_bold = var_107_5("Mercury-icons-v1.ttf", 13, draw.font_flags.light),
			cs_go14 = var_107_5("csgo_icons.ttf", 11)
		},
		offset = {}
	}
	local var_107_9 = var_107_8.alata_main:get_text_size("m", true).y

	var_107_8.offset.dpi_active = var_107_9 == 12 and 1 or var_107_9 == 14 and 2 or var_107_9 == 18 and 3 or var_107_9 == 24 and 4 or 0
	var_107_8.offset.global = var_107_9 == 12 and 1 or var_107_9 == 14 and 1 or var_107_9 == 18 and 2 or var_107_9 == 24 and 3 or 0

	local function var_107_10(arg_112_0, arg_112_1)
		for iter_112_0, iter_112_1 in pairs(arg_112_1) do
			local var_112_0 = type(iter_112_1)

			if iter_112_0 ~= "offset" and iter_112_1 ~= "number" then
				if type(iter_112_1) == "userdata" then
					iter_112_1:create()

					arg_112_0[iter_112_0] = iter_112_1:get_text_size("m", true).y - var_107_8.offset.global
				elseif type(iter_112_1) == "table" then
					arg_112_0[iter_112_0] = {}

					var_107_10(arg_112_0[iter_112_0], iter_112_1)
				end
			end
		end
	end

	var_107_10(var_107_8.offset, var_107_8)

	return var_107_8
end)()
slot_0_20_0 = (function()
	return ({
		c_json = function()
			function rawget(arg_115_0, arg_115_1)
				local var_115_0 = getmetatable(arg_115_0)

				if var_115_0 and var_115_0.__index then
					if type(var_115_0.__index) == "table" then
						return rawget(arg_115_0, arg_115_1)
					elseif type(var_115_0.__index) == "function" then
						return rawget(arg_115_0, arg_115_1)
					end
				end

				return arg_115_0[arg_115_1]
			end

			function next(arg_116_0, arg_116_1)
				local var_116_0 = false

				if arg_116_1 == nil then
					var_116_0 = true
				end

				for iter_116_0, iter_116_1 in pairs(arg_116_0) do
					if var_116_0 then
						return iter_116_0, iter_116_1
					end

					if iter_116_0 == arg_116_1 then
						var_116_0 = true
					end
				end

				return nil
			end

			local var_114_0 = {
				_version = "0.1.2"
			}
			local var_114_1
			local var_114_2 = {
				["\n"] = "n",
				["\f"] = "f",
				["\b"] = "b",
				["\""] = "\"",
				["\r"] = "r",
				["\t"] = "t",
				["\\"] = "\\"
			}
			local var_114_3 = {
				["/"] = "/"
			}

			for iter_114_0, iter_114_1 in pairs(var_114_2) do
				var_114_3[iter_114_1] = iter_114_0
			end

			function rec_userdata(arg_117_0)
				for iter_117_0, iter_117_1 in pairs(arg_117_0) do
					if type(iter_117_1) == "userdata" then
						if iter_117_1.x then
							arg_117_0[iter_117_0] = {
								iter_117_1.x,
								iter_117_1.y,
								iter_117_1.z
							}
						elseif iter_117_1.yaw then
							arg_117_0[iter_117_0] = {
								iter_117_1.pitch,
								iter_117_1.yaw,
								0
							}
						end
					elseif type(iter_117_1) == "table" then
						arg_117_0[iter_117_0] = rec_userdata(iter_117_1)
					end
				end

				return arg_117_0
			end

			local function var_114_4(arg_118_0)
				if type(arg_118_0) ~= "string" then
					return arg_118_0
				end

				local var_118_0 = 0
				local var_118_1 = "    "
				local var_118_2 = {}
				local var_118_3 = false
				local var_118_4
				local var_118_5 = 1

				while var_118_5 <= #arg_118_0 do
					local var_118_6 = arg_118_0:sub(var_118_5, var_118_5)

					if not var_118_3 then
						if var_118_6 == "{" or var_118_6 == "[" then
							table.insert(var_118_2, var_118_6)

							var_118_0 = var_118_0 + 1

							table.insert(var_118_2, "\n" .. string.rep(var_118_1, var_118_0))
						elseif var_118_6 == "}" or var_118_6 == "]" then
							var_118_0 = var_118_0 - 1

							table.insert(var_118_2, "\n" .. string.rep(var_118_1, var_118_0) .. var_118_6)
						elseif var_118_6 == "," then
							table.insert(var_118_2, var_118_6)
							table.insert(var_118_2, "\n" .. string.rep(var_118_1, var_118_0))
						elseif var_118_6 == "\"" or var_118_6 == "'" then
							var_118_3 = true
							var_118_4 = var_118_6

							table.insert(var_118_2, var_118_6)
						else
							table.insert(var_118_2, var_118_6)
						end
					else
						table.insert(var_118_2, var_118_6)

						if var_118_6 == var_118_4 and arg_118_0:sub(var_118_5 - 1, var_118_5 - 1) ~= "\\" then
							var_118_3 = false
							var_118_4 = nil
						end
					end

					var_118_5 = var_118_5 + 1
				end

				return table.concat(var_118_2)
			end

			local function var_114_5(arg_119_0)
				return "\\" .. (var_114_2[arg_119_0] or string.format("u%04x", arg_119_0:byte()))
			end

			local function var_114_6(arg_120_0)
				return "null"
			end

			local function var_114_7(arg_121_0, arg_121_1)
				local var_121_0 = {}

				arg_121_1 = arg_121_1 or {}

				if arg_121_1[arg_121_0] then
					error("circular reference")
				end

				arg_121_1[arg_121_0] = true

				if rawget(arg_121_0, 1) or next(arg_121_0) == nil then
					local var_121_1 = 0

					for iter_121_0 in pairs(arg_121_0) do
						if type(iter_121_0) ~= "number" then
							error("invalid table: mixed or invalid key types")
						end

						var_121_1 = var_121_1 + 1
					end

					if var_121_1 ~= #arg_121_0 then
						error("invalid table: sparse array")
					end

					for iter_121_1, iter_121_2 in ipairs(arg_121_0) do
						table.insert(var_121_0, var_114_1(iter_121_2, arg_121_1))
					end

					arg_121_1[arg_121_0] = nil

					return "[" .. table.concat(var_121_0, ",") .. "]"
				else
					for iter_121_3, iter_121_4 in pairs(arg_121_0) do
						if type(iter_121_3) ~= "string" then
							error("invalid table: mixed or invalid key types")
						end

						table.insert(var_121_0, var_114_1(iter_121_3, arg_121_1) .. ":" .. var_114_1(iter_121_4, arg_121_1))
					end

					arg_121_1[arg_121_0] = nil

					return "{" .. table.concat(var_121_0, ",") .. "}"
				end
			end

			local function var_114_8(arg_122_0)
				return "\"" .. arg_122_0:gsub("[%z\x01-\x1F\\\"]", var_114_5) .. "\""
			end

			local function var_114_9(arg_123_0)
				if arg_123_0 ~= arg_123_0 or arg_123_0 <= -math.huge or arg_123_0 >= math.huge then
					error("unexpected number value '" .. tostring(arg_123_0) .. "'")
				end

				return string.format("%.14g", arg_123_0)
			end

			local var_114_10 = {
				["nil"] = var_114_6,
				table = var_114_7,
				string = var_114_8,
				number = var_114_9,
				boolean = tostring
			}

			function var_114_1(arg_124_0, arg_124_1)
				local var_124_0 = type(arg_124_0)
				local var_124_1 = var_114_10[var_124_0]

				if var_124_1 then
					return var_124_1(arg_124_0, arg_124_1)
				end

				error("unexpected type '" .. var_124_0 .. "'")
			end

			function var_114_0.encode(arg_125_0)
				if type(arg_125_0) == "table" then
					arg_125_0 = rec_userdata(arg_125_0)
				end

				return var_114_4(var_114_1(arg_125_0))
			end

			local var_114_11

			local function var_114_12(...)
				local var_126_0 = {}

				for iter_126_0 = 1, select("#", ...) do
					var_126_0[select(iter_126_0, ...)] = true
				end

				return var_126_0
			end

			local var_114_13 = var_114_12(" ", "\t", "\r", "\n")
			local var_114_14 = var_114_12(" ", "\t", "\r", "\n", "]", "}", ",")
			local var_114_15 = var_114_12("\\", "/", "\"", "b", "f", "n", "r", "t", "u")
			local var_114_16 = var_114_12("true", "false", "null")
			local var_114_17 = {
				["true"] = true,
				null = nil,
				["false"] = false
			}

			local function var_114_18(arg_127_0, arg_127_1, arg_127_2, arg_127_3)
				for iter_127_0 = arg_127_1, #arg_127_0 do
					if arg_127_2[arg_127_0:sub(iter_127_0, iter_127_0)] ~= arg_127_3 then
						return iter_127_0
					end
				end

				return #arg_127_0 + 1
			end

			local function var_114_19(arg_128_0, arg_128_1, arg_128_2)
				local var_128_0 = 1
				local var_128_1 = 1

				for iter_128_0 = 1, arg_128_1 - 1 do
					var_128_1 = var_128_1 + 1

					if arg_128_0:sub(iter_128_0, iter_128_0) == "\n" then
						var_128_0 = var_128_0 + 1
						var_128_1 = 1
					end
				end

				error(string.format("%s at line %d col %d", arg_128_2, var_128_0, var_128_1))
			end

			local function var_114_20(arg_129_0)
				local var_129_0 = math.floor

				if arg_129_0 <= 127 then
					return string.char(arg_129_0)
				elseif arg_129_0 <= 2047 then
					return string.char(var_129_0(arg_129_0 / 64) + 192, arg_129_0 % 64 + 128)
				elseif arg_129_0 <= 65535 then
					return string.char(var_129_0(arg_129_0 / 4096) + 224, var_129_0(arg_129_0 % 4096 / 64) + 128, arg_129_0 % 64 + 128)
				elseif arg_129_0 <= 1114111 then
					return string.char(var_129_0(arg_129_0 / 262144) + 240, var_129_0(arg_129_0 % 262144 / 4096) + 128, var_129_0(arg_129_0 % 4096 / 64) + 128, arg_129_0 % 64 + 128)
				end

				error(string.format("invalid unicode codepoint '%x'", arg_129_0))
			end

			local function var_114_21(arg_130_0)
				local var_130_0 = tonumber(arg_130_0:sub(1, 4), 16)
				local var_130_1 = tonumber(arg_130_0:sub(7, 10), 16)

				if var_130_1 then
					return var_114_20((var_130_0 - 55296) * 1024 + var_130_1 - 56320 + 65536)
				else
					return var_114_20(var_130_0)
				end
			end

			local function var_114_22(arg_131_0, arg_131_1)
				local var_131_0 = ""
				local var_131_1 = arg_131_1 + 1
				local var_131_2 = var_131_1

				while var_131_1 <= #arg_131_0 do
					local var_131_3 = arg_131_0:byte(var_131_1)

					if var_131_3 < 32 then
						var_114_19(arg_131_0, var_131_1, "control character in string")
					elseif var_131_3 == 92 then
						var_131_0 = var_131_0 .. arg_131_0:sub(var_131_2, var_131_1 - 1)
						var_131_1 = var_131_1 + 1

						local var_131_4 = arg_131_0:sub(var_131_1, var_131_1)

						if var_131_4 == "u" then
							local var_131_5 = arg_131_0:match("^[dD][89aAbB]%x%x\\u%x%x%x%x", var_131_1 + 1) or arg_131_0:match("^%x%x%x%x", var_131_1 + 1) or var_114_19(arg_131_0, var_131_1 - 1, "invalid unicode escape in string")

							var_131_0 = var_131_0 .. var_114_21(var_131_5)
							var_131_1 = var_131_1 + #var_131_5
						else
							if not var_114_15[var_131_4] then
								var_114_19(arg_131_0, var_131_1 - 1, "invalid escape char '" .. var_131_4 .. "' in string")
							end

							var_131_0 = var_131_0 .. var_114_3[var_131_4]
						end

						var_131_2 = var_131_1 + 1
					elseif var_131_3 == 34 then
						var_131_0 = var_131_0 .. arg_131_0:sub(var_131_2, var_131_1 - 1)

						return var_131_0, var_131_1 + 1
					end

					var_131_1 = var_131_1 + 1
				end

				var_114_19(arg_131_0, arg_131_1, "expected closing quote for string")
			end

			local function var_114_23(arg_132_0, arg_132_1)
				local var_132_0 = var_114_18(arg_132_0, arg_132_1, var_114_14)
				local var_132_1 = arg_132_0:sub(arg_132_1, var_132_0 - 1)
				local var_132_2 = tonumber(var_132_1)

				if not var_132_2 then
					var_114_19(arg_132_0, arg_132_1, "invalid number '" .. var_132_1 .. "'")
				end

				return var_132_2, var_132_0
			end

			local function var_114_24(arg_133_0, arg_133_1)
				local var_133_0 = var_114_18(arg_133_0, arg_133_1, var_114_14)
				local var_133_1 = arg_133_0:sub(arg_133_1, var_133_0 - 1)

				if not var_114_16[var_133_1] then
					var_114_19(arg_133_0, arg_133_1, "invalid literal '" .. var_133_1 .. "'")
				end

				return var_114_17[var_133_1], var_133_0
			end

			local function var_114_25(arg_134_0, arg_134_1)
				local var_134_0 = {}
				local var_134_1 = 1

				arg_134_1 = arg_134_1 + 1

				while true do
					local var_134_2

					arg_134_1 = var_114_18(arg_134_0, arg_134_1, var_114_13, true)

					if arg_134_0:sub(arg_134_1, arg_134_1) == "]" then
						arg_134_1 = arg_134_1 + 1

						break
					end

					var_134_0[var_134_1], arg_134_1 = var_114_11(arg_134_0, arg_134_1)
					var_134_1 = var_134_1 + 1
					arg_134_1 = var_114_18(arg_134_0, arg_134_1, var_114_13, true)

					local var_134_3 = arg_134_0:sub(arg_134_1, arg_134_1)

					arg_134_1 = arg_134_1 + 1

					if var_134_3 == "]" then
						break
					end

					if var_134_3 ~= "," then
						var_114_19(arg_134_0, arg_134_1, "expected ']' or ','")
					end
				end

				return var_134_0, arg_134_1
			end

			local function var_114_26(arg_135_0, arg_135_1)
				local var_135_0 = {}

				arg_135_1 = arg_135_1 + 1

				while true do
					local var_135_1
					local var_135_2

					arg_135_1 = var_114_18(arg_135_0, arg_135_1, var_114_13, true)

					if arg_135_0:sub(arg_135_1, arg_135_1) == "}" then
						arg_135_1 = arg_135_1 + 1

						break
					end

					if arg_135_0:sub(arg_135_1, arg_135_1) ~= "\"" then
						var_114_19(arg_135_0, arg_135_1, "expected string for key")
					end

					local var_135_3

					var_135_3, arg_135_1 = var_114_11(arg_135_0, arg_135_1)
					arg_135_1 = var_114_18(arg_135_0, arg_135_1, var_114_13, true)

					if arg_135_0:sub(arg_135_1, arg_135_1) ~= ":" then
						var_114_19(arg_135_0, arg_135_1, "expected ':' after key")
					end

					arg_135_1 = var_114_18(arg_135_0, arg_135_1 + 1, var_114_13, true)
					var_135_0[var_135_3], arg_135_1 = var_114_11(arg_135_0, arg_135_1)
					arg_135_1 = var_114_18(arg_135_0, arg_135_1, var_114_13, true)

					local var_135_4 = arg_135_0:sub(arg_135_1, arg_135_1)

					arg_135_1 = arg_135_1 + 1

					if var_135_4 == "}" then
						break
					end

					if var_135_4 ~= "," then
						var_114_19(arg_135_0, arg_135_1, "expected '}' or ','")
					end
				end

				return var_135_0, arg_135_1
			end

			local var_114_27 = {
				["\""] = var_114_22,
				["0"] = var_114_23,
				["1"] = var_114_23,
				["2"] = var_114_23,
				["3"] = var_114_23,
				["4"] = var_114_23,
				["5"] = var_114_23,
				["6"] = var_114_23,
				["7"] = var_114_23,
				["8"] = var_114_23,
				["9"] = var_114_23,
				["-"] = var_114_23,
				t = var_114_24,
				f = var_114_24,
				n = var_114_24,
				["["] = var_114_25,
				["{"] = var_114_26
			}

			function var_114_11(arg_136_0, arg_136_1)
				local var_136_0 = arg_136_0:sub(arg_136_1, arg_136_1)
				local var_136_1 = var_114_27[var_136_0]

				if var_136_1 then
					return var_136_1(arg_136_0, arg_136_1)
				end

				var_114_19(arg_136_0, arg_136_1, "unexpected character '" .. var_136_0 .. "'")
			end

			function var_114_0.decode(arg_137_0)
				if type(arg_137_0) ~= "string" then
					error("expected argument of type string, got " .. type(arg_137_0))
				end

				local var_137_0, var_137_1 = var_114_11(arg_137_0, var_114_18(arg_137_0, 1, var_114_13, true))
				local var_137_2 = var_114_18(arg_137_0, var_137_1, var_114_13, true)

				if var_137_2 <= #arg_137_0 then
					var_114_19(arg_137_0, var_137_2, "trailing garbage")
				end

				return var_137_0
			end

			return var_114_0
		end
	}).c_json()
end)()
slot_0_22_0, slot_0_23_0 = (function()
	ffi.cdef("        typedef struct ISteamHTTP {\n        } ISteamHTTP;\n            \n        typedef struct ISteamClient {\n        } ISteamClient;\n\n        typedef struct IGlobalVars {\n            char pad_0x4[0x34];\n            float flCurtime;\n        } IGlobalVars;\n    ")

	local var_138_0 = ffi.cast("void* (__stdcall*)(const char*)", utils.find_export("kernel32.dll", "GetModuleHandleA"))
	local var_138_1 = ffi.cast("void* (__stdcall*)(void*, const char*)", utils.find_export("kernel32.dll", "GetProcAddress"))
	local var_138_2 = {
		pSteamManager = {},
		arrHttpRequests = {},
		nullptr = ffi.cast("void*", 0),
		ppGlobalVars = ffi.cast("void*", 0),
		EHTTPMethod = {
			get = 1,
			invalid = 0,
			delete = 5,
			put = 4,
			post = 3,
			options = 6,
			head = 2
		}
	}

	var_138_2.__index = setmetatable(var_138_2, {})

	function var_138_2.__index.BindArg(arg_139_0, arg_139_1, arg_139_2)
		return function(...)
			return arg_139_1(arg_139_2, ...)
		end
	end

	function var_138_2.__index.CBaseAddress(arg_141_0, arg_141_1)
		return setmetatable({
			uBase = ffi.cast("uintptr_t", arg_141_1)
		}, {
			__call = function(arg_142_0, arg_142_1)
				if not arg_142_0:IsValidate() then
					return nil
				end

				return ffi.cast(arg_142_1 or "void*", arg_142_0.uBase)
			end,
			__index = {
				IsValidate = function(arg_143_0)
					return arg_143_0.uBase > 4096 and arg_143_0.uBase < 140737488289791
				end,
				GetAddress = function(arg_144_0)
					return arg_144_0.uBase
				end,
				Get = function(arg_145_0, arg_145_1)
					if not arg_145_0:IsValidate() then
						return nil
					end

					return ffi.cast(arg_145_1 or "void*", arg_145_0.uBase)
				end,
				Copy = function(arg_146_0, arg_146_1)
					if arg_146_0:IsValidate() and type(arg_146_1) == "cdata" or type(arg_146_1) == "number" then
						return arg_141_0:CBaseAddress(arg_146_0.uBase + tonumber(arg_146_1))
					end

					return arg_141_0:CBaseAddress(arg_146_0.uBase)
				end,
				Field = function(arg_147_0, arg_147_1)
					if not arg_147_0:IsValidate() then
						return arg_147_0
					end

					arg_147_0.uBase = arg_147_0.uBase + arg_147_1

					return arg_147_0
				end,
				FieldOf = function(arg_148_0, arg_148_1)
					if not arg_148_0:IsValidate() then
						return arg_148_0:Copy()
					end

					return arg_141_0:CBaseAddress(arg_148_0.uBase + arg_148_1)
				end,
				ToAbsolute = function(arg_149_0, arg_149_1, arg_149_2)
					if not arg_149_0:IsValidate() then
						return arg_149_0
					end

					arg_149_0:Field(arg_149_1 or 1)
					arg_149_0:Field(ffi.sizeof("int") + ffi.cast("int64_t", ffi.cast("int*", arg_149_0.uBase)[0]))
					arg_149_0:Field(arg_149_2 or 0)

					return arg_149_0
				end,
				ToRelative = function(arg_150_0, arg_150_1, arg_150_2)
					if not arg_150_0:IsValidate() then
						return arg_150_0
					end

					arg_150_0:Field(ffi.cast("uint32_t*", arg_150_0.uBase + (arg_150_1 or 3))[0] + (arg_150_2 or 7))

					return arg_150_0
				end,
				Dereference = function(arg_151_0, arg_151_1)
					if not arg_151_0:IsValidate() then
						return arg_151_0
					end

					for iter_151_0 = 1, arg_151_1 or 1 do
						arg_151_0.uBase = ffi.cast("uintptr_t*", arg_151_0.uBase)[0]
					end

					return arg_151_0
				end,
				GetByteArray = function(arg_152_0, arg_152_1)
					local var_152_0 = arg_152_1 or 16

					if not arg_152_0:IsValidate() or var_152_0 <= 0 then
						return nil
					end

					local var_152_1 = ""
					local var_152_2 = ffi.cast("uint8_t*", arg_152_0.uBase)

					for iter_152_0 = 0, var_152_0 - 1 do
						var_152_1 = (iter_152_0 == var_152_0 - 1 and "%s%02X" or "%s%02X "):format(var_152_1, var_152_2[iter_152_0])
					end

					return var_152_1
				end
			}
		})
	end

	function var_138_2.__index.GetModuleProc(arg_153_0, arg_153_1, arg_153_2)
		local var_153_0 = var_138_0(arg_153_1)

		if var_153_0 == arg_153_0.nullptr then
			return nil
		end

		local var_153_1 = var_138_1(var_153_0, arg_153_2)

		if var_153_1 == arg_153_0.nullptr then
			return nil
		end

		return arg_153_0:CBaseAddress(var_153_1)
	end

	function var_138_2.__index.CallVirtual(arg_154_0, arg_154_1, arg_154_2, arg_154_3, ...)
		local var_154_0 = ffi.cast("uintptr_t**", arg_154_1)[0]

		return ffi.cast(arg_154_3, var_154_0[arg_154_2])(arg_154_1, ...)
	end

	function var_138_2.__index.ISteamManager(arg_155_0, arg_155_1, arg_155_2, arg_155_3)
		return setmetatable({
			pSteamPipe = arg_155_3,
			pSteamUser = arg_155_2,
			pSteamClient = arg_155_1
		}, {
			__index = {
				GetSteamHttp = function(arg_156_0)
					return arg_156_0.pSteamClient:GetISteamHTTP(arg_156_0.pSteamUser, arg_156_0.pSteamPipe, "STEAMHTTP_INTERFACE_VERSION003")
				end,
				Request = function(arg_157_0, arg_157_1, arg_157_2, arg_157_3, arg_157_4)
					assert(type(arg_157_2) == "string", "invalid require url")
					assert(arg_155_0.EHTTPMethod[arg_157_1], "invalid require method")
					assert(type(arg_157_3) == "function" or type(arg_157_4) == "function", "invalid callback")
					assert(type(arg_157_3) == "table" or type(arg_157_3) == "function", "invalid callback | options")

					local var_157_0 = arg_157_0:GetSteamHttp()

					if var_157_0 == arg_155_0.nullptr then
						return false
					end

					local var_157_1 = 10
					local var_157_2 = 0.5
					local var_157_3 = arg_155_0.EHTTPMethod[arg_157_1]
					local var_157_4 = var_157_0:CreateHTTPRequest(var_157_3, arg_157_2)

					if type(arg_157_3) == "function" then
						arg_157_4 = arg_157_3
					else
						local var_157_5 = "application/text"

						if type(arg_157_3.timeout) == "number" then
							var_157_1 = arg_157_3.timeout

							if var_157_1 ~= math.ceil(var_157_1) then
								var_157_0:SetHTTPRequestAbsoluteTimeoutMS(var_157_4, var_157_1 * 1000)
							else
								var_157_0:SetHTTPRequestNetworkActivityTimeout(var_157_4, var_157_1)
							end
						end

						if type(arg_157_3.process_interval) == "number" then
							var_157_2 = arg_157_3.process_interval
						end

						if type(arg_157_3.user_agent) == "string" then
							var_157_0:SetHTTPRequestUserAgentInfo(var_157_4, arg_157_3.user_agent)
						end

						if type(arg_157_3.verified_certificate) == "boolean" then
							var_157_0:SetHTTPRequestRequiresVerifiedCertificate(var_157_4, arg_157_3.verified_certificate)
						end

						if type(arg_157_3.header) == "table" then
							for iter_157_0, iter_157_1 in pairs(arg_157_3.header) do
								if iter_157_0:lower() == "content-type" and type(iter_157_1) == "string" then
									var_157_5 = iter_157_1
								end

								var_157_0:SetHTTPRequestHeaderValue(var_157_4, iter_157_0, tostring(iter_157_1))
							end
						end

						if type(arg_157_3.params) == "table" then
							for iter_157_2, iter_157_3 in pairs(arg_157_3.params) do
								var_157_0:SetHTTPRequestGetOrPostParameter(var_157_4, iter_157_2, tostring(iter_157_3))
							end
						end

						if type(arg_157_3.body) == "string" then
							var_157_0:SetHTTPRequestRawPostBody(var_157_4, var_157_5, arg_157_3.body)
						end
					end

					if not var_157_0:SendHTTPRequest(var_157_4) then
						var_157_0:ReleaseHTTPRequest(var_157_4)

						return false
					end

					table.insert(arg_155_0.arrHttpRequests, {
						flProcessTime = 0,
						bProcessed = false,
						nHandle = var_157_4,
						pCallBack = arg_157_4,
						flAllowedTimeOut = var_157_1,
						flProcessInterval = var_157_2,
						flCurtime = game.global_vars.cur_time
					})

					return true
				end,
				Get = function(arg_158_0, arg_158_1, arg_158_2, arg_158_3)
					return arg_158_0:Request("get", arg_158_1, arg_158_2, arg_158_3)
				end,
				Post = function(arg_159_0, arg_159_1, arg_159_2, arg_159_3)
					return arg_159_0:Request("post", arg_159_1, arg_159_2, arg_159_3)
				end
			}
		})
	end

	function var_138_2.__index.GenerateInterface(arg_160_0)
		ffi.metatype("struct ISteamHTTP", {
			__index = {
				CreateHTTPRequest = function(arg_161_0, arg_161_1, arg_161_2)
					return arg_160_0:CallVirtual(arg_161_0, 0, "uint32_t(__thiscall*)(void*, uint32_t, const char*)", arg_161_1, arg_161_2)
				end,
				SetHTTPRequestNetworkActivityTimeout = function(arg_162_0, arg_162_1, arg_162_2)
					return arg_160_0:CallVirtual(arg_162_0, 2, "bool(__thiscall*)(void*, uint32_t, uint32_t)", arg_162_1, math.floor(arg_162_2 + 0.5))
				end,
				SetHTTPRequestHeaderValue = function(arg_163_0, arg_163_1, arg_163_2, arg_163_3)
					return arg_160_0:CallVirtual(arg_163_0, 3, "bool(__thiscall*)(void*, uint32_t, const char*, const char*)", arg_163_1, arg_163_2, arg_163_3)
				end,
				SetHTTPRequestGetOrPostParameter = function(arg_164_0, arg_164_1, arg_164_2, arg_164_3)
					return arg_160_0:CallVirtual(arg_164_0, 4, "bool(__thiscall*)(void*, uint32_t, const char*, const char*)", arg_164_1, arg_164_2, arg_164_3)
				end,
				SendHTTPRequest = function(arg_165_0, arg_165_1)
					return arg_160_0:CallVirtual(arg_165_0, 5, "bool(__thiscall*)(void*, uint32_t, void*)", arg_165_1, arg_160_0.nullptr)
				end,
				GetHTTPResponseHeaderSize = function(arg_166_0, arg_166_1, arg_166_2, arg_166_3)
					return arg_160_0:CallVirtual(arg_166_0, 9, "bool(__thiscall*)(void*, uint32_t, const char*, uint32_t*)", arg_166_1, arg_166_2, arg_166_3)
				end,
				GetHTTPResponseHeaderValue = function(arg_167_0, arg_167_1, arg_167_2, arg_167_3, arg_167_4)
					return arg_160_0:CallVirtual(arg_167_0, 10, "bool(__thiscall*)(void*, uint32_t, const char*, uint8_t*, uint32_t)", arg_167_1, arg_167_2, arg_167_3, arg_167_4)
				end,
				GetHTTPResponseBodySize = function(arg_168_0, arg_168_1, arg_168_2)
					return arg_160_0:CallVirtual(arg_168_0, 11, "bool(__thiscall*)(void*, uint32_t, uint32_t*)", arg_168_1, arg_168_2)
				end,
				GetHTTPResponseBodyData = function(arg_169_0, arg_169_1, arg_169_2, arg_169_3)
					return arg_160_0:CallVirtual(arg_169_0, 12, "bool(__thiscall*)(void*, uint32_t, uint8_t*, uint32_t)", arg_169_1, arg_169_2, arg_169_3)
				end,
				ReleaseHTTPRequest = function(arg_170_0, arg_170_1)
					return arg_160_0:CallVirtual(arg_170_0, 14, "bool(__thiscall*)(void*, uint32_t)", arg_170_1)
				end,
				SetHTTPRequestRawPostBody = function(arg_171_0, arg_171_1, arg_171_2, arg_171_3)
					return arg_160_0:CallVirtual(arg_171_0, 16, "bool(__thiscall*)(void*, uint32_t, const char*, const char*, uint32_t)", arg_171_1, arg_171_2, arg_171_3, arg_171_3:len())
				end,
				SetHTTPRequestUserAgentInfo = function(arg_172_0, arg_172_1, arg_172_2)
					return arg_160_0:CallVirtual(arg_172_0, 21, "bool(__thiscall*)(void*, uint32_t, const char*)", arg_172_1, arg_172_2)
				end,
				SetHTTPRequestRequiresVerifiedCertificate = function(arg_173_0, arg_173_1, arg_173_2)
					return arg_160_0:CallVirtual(arg_173_0, 22, "bool(__thiscall*)(void*, uint32_t, bool)", arg_173_1, arg_173_2)
				end,
				SetHTTPRequestAbsoluteTimeoutMS = function(arg_174_0, arg_174_1, arg_174_2)
					return arg_160_0:CallVirtual(arg_174_0, 23, "bool(__thiscall*)(void*, uint32_t, uint32_t)", arg_174_1, math.floor(arg_174_2 + 0.5))
				end
			}
		})
		ffi.metatype("struct ISteamClient", {
			__index = {
				GetISteamHTTP = function(arg_175_0, arg_175_1, arg_175_2, arg_175_3)
					return arg_160_0:CallVirtual(arg_175_0, 24, "ISteamHTTP*(__thiscall*)(void*, void*, void*, const char*)", arg_175_1, arg_175_2, arg_175_3)
				end
			}
		})

		local var_160_0 = arg_160_0:GetModuleProc("steam_api64.dll", "GetHSteamUser"):Get("void*(*)()")
		local var_160_1 = arg_160_0:GetModuleProc("steam_api64.dll", "GetHSteamPipe"):Get("void*(*)()")
		local var_160_2 = arg_160_0:GetModuleProc("steam_api64.dll", "SteamClient"):Get("struct ISteamClient*(*)()")

		arg_160_0.ppGlobalVars = arg_160_0:CBaseAddress(utils.find_pattern("client.dll", "48 8B 05 ?? ?? ?? ?? 8B 48 04 FF C1")):ToAbsolute(3, 0):Get("struct IGlobalVars**")

		if not var_160_0 or not var_160_1 or not var_160_2 then
			return
		end

		arg_160_0.pSteamManager = arg_160_0:ISteamManager(var_160_2(), var_160_0(), var_160_1())
	end

	function var_138_2.__index.Destroy(arg_176_0)
		local var_176_0 = arg_176_0.pSteamManager:GetSteamHttp()

		for iter_176_0, iter_176_1 in pairs(arg_176_0.arrHttpRequests) do
			if not iter_176_1.bProcessed then
				iter_176_1.bProcessed = true

				var_176_0:ReleaseHTTPRequest(iter_176_1.nHandle)
			end
		end
	end

	function var_138_2.__index.ProcessHttpRequest(arg_177_0)
		for iter_177_0, iter_177_1 in pairs(arg_177_0.arrHttpRequests) do
			if not iter_177_1.bProcessed then
				if math.abs(game.global_vars.cur_time - iter_177_1.flCurtime) > iter_177_1.flAllowedTimeOut then
					local var_177_0 = arg_177_0.pSteamManager:GetSteamHttp()

					iter_177_1.bProcessed = true

					iter_177_1.pCallBack({
						status = 408
					})
					var_177_0:ReleaseHTTPRequest(iter_177_1.nHandle)
					table.remove(arg_177_0.arrHttpRequests, iter_177_0)
				elseif math.abs(game.global_vars.cur_time - iter_177_1.flProcessTime) > iter_177_1.flProcessInterval then
					local var_177_1 = arg_177_0.pSteamManager:GetSteamHttp()
					local var_177_2 = ffi.new("uint32_t[1]")

					if var_177_1:GetHTTPResponseBodySize(iter_177_1.nHandle, var_177_2) then
						iter_177_1.bProcessed = true

						if var_177_2[0] == 0 then
							iter_177_1.pCallBack({
								status = 204
							})
						else
							local var_177_3 = ffi.new("char[?]", var_177_2[0])

							if var_177_1:GetHTTPResponseBodyData(iter_177_1.nHandle, var_177_3, var_177_2[0]) then
								iter_177_1.pCallBack(setmetatable({
									status = 200,
									handle = nHandle,
									body = ffi.string(var_177_3)
								}, {
									__index = {
										GetHeader = function(arg_178_0, arg_178_1)
											local var_178_0 = ffi.new("uint32_t[1]")

											if not var_177_1:GetHTTPResponseHeaderSize(arg_178_0.handle, arg_178_1, var_178_0) then
												return nil
											end

											if var_178_0[0] == 0 then
												return "empty header value"
											end

											local var_178_1 = ffi.new("char[?]", var_178_0[0])

											if not var_177_1:GetHTTPResponseHeaderValue(arg_178_0.handle, arg_178_1, var_178_1, var_178_0[0]) then
												return ffi.string(var_178_1)
											end

											return nil
										end
									}
								}))
							end
						end

						var_177_1:ReleaseHTTPRequest(iter_177_1.nHandle)
					end

					iter_177_1.flProcessTime = game.global_vars.cur_time
				end
			end
		end
	end

	function var_138_2.__index.Setup(arg_179_0)
		xpcall(function()
			arg_179_0:GenerateInterface()
			events.present_queue:add(arg_179_0:BindArg(arg_179_0.ProcessHttpRequest, arg_179_0))
		end, function()
			print("[Mercury:HTTP] Error")
		end)

		return arg_179_0.pSteamManager
	end

	function string.count(arg_182_0, arg_182_1)
		local var_182_0 = 0

		for iter_182_0 = 1, #arg_182_0 do
			if string.sub(arg_182_0, iter_182_0, iter_182_0) == arg_182_1 then
				var_182_0 = var_182_0 + 1
			end
		end

		return var_182_0
	end

	local var_138_3 = (function()
		local var_183_0 = (function()
			local function var_184_0(arg_185_0, arg_185_1)
				local var_185_0 = {}
				local var_185_1 = 1

				for iter_185_0 = 1, #arg_185_0 do
					local var_185_2 = string.byte(arg_185_1, iter_185_0 % #arg_185_1 + 1) % #arg_185_0 + 1

					while var_185_0[var_185_2] do
						var_185_2 = var_185_2 % #arg_185_0 + 1
					end

					var_185_0[var_185_2] = arg_185_0:sub(iter_185_0, iter_185_0)
				end

				return table.concat(var_185_0)
			end

			local function var_184_1(arg_186_0, arg_186_1)
				local var_186_0 = {}
				local var_186_1 = {}

				for iter_186_0 = 1, #arg_186_0 do
					local var_186_2 = string.byte(arg_186_1, iter_186_0 % #arg_186_1 + 1) % #arg_186_0 + 1

					while var_186_1[var_186_2] do
						var_186_2 = var_186_2 % #arg_186_0 + 1
					end

					var_186_1[var_186_2] = iter_186_0
				end

				for iter_186_1 = 1, #arg_186_0 do
					var_186_0[var_186_1[iter_186_1]] = arg_186_0:sub(iter_186_1, iter_186_1)
				end

				return table.concat(var_186_0)
			end

			return {
				enc = function(arg_187_0, arg_187_1)
					local var_187_0 = {}

					for iter_187_0 = 1, #arg_187_0 do
						local var_187_1 = string.byte(arg_187_0, iter_187_0)
						local var_187_2 = string.byte(arg_187_1, iter_187_0 % #arg_187_1 + 1)
						local var_187_3 = bit.bxor(var_187_1, var_187_2) + 32

						table.insert(var_187_0, string.char(var_187_3))
					end

					return var_184_0(table.concat(var_187_0), arg_187_1)
				end,
				dec = function(arg_188_0, arg_188_1)
					local var_188_0 = {}

					arg_188_0 = var_184_1(arg_188_0, arg_188_1)

					for iter_188_0 = 1, #arg_188_0 do
						local var_188_1 = string.byte(arg_188_0, iter_188_0)
						local var_188_2 = string.byte(arg_188_1, iter_188_0 % #arg_188_1 + 1)
						local var_188_3 = bit.bxor(var_188_1 - 32, var_188_2)

						table.insert(var_188_0, string.char(var_188_3))
					end

					return table.concat(var_188_0)
				end
			}
		end)()
		local var_183_1 = {
			enc = function(arg_189_0, arg_189_1)
				local var_189_0 = {}
				local var_189_1 = 1

				for iter_189_0 = 1, #arg_189_0 do
					local var_189_2 = string.byte(arg_189_0, iter_189_0)
					local var_189_3 = string.byte(arg_189_1, var_189_1)
					local var_189_4 = bit.bxor(var_189_2, var_189_3)

					table.insert(var_189_0, string.format("\\%02x", var_189_4))

					var_189_1 = var_189_1 + 1

					if var_189_1 > #arg_189_1 then
						var_189_1 = 1
					end
				end

				return table.concat(var_189_0)
			end,
			dec = function(arg_190_0, arg_190_1)
				local var_190_0 = {}
				local var_190_1 = 1
				local var_190_2 = 1

				while var_190_2 <= #arg_190_0 do
					if string.sub(arg_190_0, var_190_2, var_190_2) == "\\" and var_190_2 + 2 <= #arg_190_0 then
						local var_190_3 = tonumber(string.sub(arg_190_0, var_190_2 + 1, var_190_2 + 2), 16)
						local var_190_4 = string.byte(arg_190_1, var_190_1)

						table.insert(var_190_0, string.char(bit.bxor(var_190_3, var_190_4)))

						var_190_1 = var_190_1 + 1

						if var_190_1 > #arg_190_1 then
							var_190_1 = 1
						end

						var_190_2 = var_190_2 + 3
					else
						table.insert(var_190_0, string.sub(arg_190_0, var_190_2, var_190_2))

						var_190_2 = var_190_2 + 1
					end
				end

				return table.concat(var_190_0)
			end
		}

		return {
			gen_key = function(arg_191_0, arg_191_1)
				local var_191_0 = "BC6AlmSTUE0DztuvVWO34xFqrs79abcdGHIJKLghijk12RZXYPQM85wpyefnoN"
				local var_191_1 = {}
				local var_191_2 = (function(arg_192_0)
					local var_192_0 = arg_192_0 % 2147483647

					if var_192_0 <= 0 then
						var_192_0 = var_192_0 + 2147483646
					end

					return function()
						var_192_0 = var_192_0 * 16807 % 2147483647

						return (var_192_0 - 1) / 2147483646
					end
				end)(arg_191_1)

				for iter_191_0 = 1, arg_191_0 do
					local var_191_3 = math.floor(var_191_2() * #var_191_0) + 1

					var_191_1[iter_191_0] = var_191_0:sub(var_191_3, var_191_3)
				end

				return table.concat(var_191_1)
			end,
			unix_key = function()
				local var_194_0 = 600
				local var_194_1 = tostring(utils.get_unix_time())
				local var_194_2 = tonumber(string.sub(var_194_1, 6, #var_194_1))
				local var_194_3 = var_194_2 % var_194_0
				local var_194_4 = var_194_2 - var_194_3

				if var_194_3 >= 10 then
					return var_194_4 / var_194_0 + var_194_4 % 100 * 13 + var_194_4 % 10 * 3
				else
					return var_194_4 / var_194_0 + (var_194_4 % 100)^2 + var_194_4 % 10 * 33
				end
			end,
			enc = function(arg_195_0, arg_195_1)
				local var_195_0 = var_183_0.enc(arg_195_0, arg_195_1)

				return (var_183_1.enc(var_195_0, arg_195_1))
			end,
			dec = function(arg_196_0, arg_196_1)
				local var_196_0 = var_183_1.dec(arg_196_0, arg_196_1)

				return (var_183_0.dec(var_196_0, arg_196_1))
			end
		}
	end)()
	local var_138_4 = var_138_2:Setup()
	local var_138_5 = {}

	var_138_5 = {
		normalize = function(arg_197_0)
			if type(arg_197_0) ~= "string" then
				return "{}"
			end

			local var_197_0 = arg_197_0

			while (var_197_0:find("]") or var_197_0:find("}")) and string.sub(var_197_0, #var_197_0, #var_197_0) ~= "]" and string.sub(var_197_0, #var_197_0, #var_197_0) ~= "}" do
				var_197_0 = string.sub(var_197_0, 0, #var_197_0 - 1)
			end

			while var_197_0:count("{") < var_197_0:count("}") and string.sub(var_197_0, #var_197_0, #var_197_0) == "}" or var_197_0:count("[") < var_197_0:count("]") and string.sub(var_197_0, #var_197_0, #var_197_0) == "]" do
				var_197_0 = string.sub(var_197_0, 0, #var_197_0 - 1)
			end

			return var_197_0
		end,
		Post = function(arg_198_0, arg_198_1, arg_198_2, arg_198_3)
			if var_138_3.connect == false then
				print("[Mercury:Server] Failed get req")
			end

			if arg_198_0 == "/auth/login" then
				var_138_3.connect = false
			end

			arg_198_0 = arg_198_0 or "/manager"
			arg_198_2 = arg_198_2 or {}
			arg_198_2.type = arg_198_1 or ""
			arg_198_2.version = "stable"
			arg_198_2.nick = gui.ctx.user.username
			arg_198_2.time = utils.get_unix_time()

			math.randomseed(arg_198_2.time)

			arg_198_2.id = math.random(1, 1000000000)

			local var_198_0

			xpcall(function()
				if not var_138_3.token then
					var_138_3.token = var_138_3.gen_key(294, var_138_3.unix_key())
				end

				local var_199_0 = var_138_3.enc(slot_0_20_0.encode(arg_198_2), var_138_3.token)

				var_198_0 = slot_0_20_0.encode({
					id = var_138_3.uid,
					info = var_199_0
				})
			end, function(arg_200_0)
				print("[Mercury:ERROR] Failed encode: " .. tostring(arg_200_0))
			end)

			arg_198_3 = arg_198_3 or function()
				return
			end

			if var_198_0 == nil then
				return
			end

			var_138_4:Post(slot_0_1_0 .. arg_198_0, {
				body = var_198_0,
				header = {
					["Content-Type"] = "application/json"
				}
			}, function(arg_202_0)
				if not arg_202_0 then
					return
				end

				if type(arg_202_0.body) ~= "string" then
					return
				end

				if string.find(arg_202_0.body, "Failed ") or not string.find(arg_202_0.body, "{") or not string.find(arg_202_0.body, "}") then
					return arg_198_3("Failed")
				end

				if string.find(arg_202_0.body, "Outdate") and #arg_202_0.body < 50 then
					return arg_198_3("Outdate")
				end

				if string.find(arg_202_0.body, "Invalid ") then
					return arg_198_3("Invalid data")
				end

				xpcall(function()
					local var_203_0 = var_138_5.normalize(arg_202_0.body)

					if tostring(var_203_0):find("success") and #tostring(var_203_0) < 20 then
						return
					end

					local var_203_1 = slot_0_20_0.decode(var_203_0)

					if var_203_1 and type(var_203_1) == "table" then
						arg_198_3(var_203_1)
					end
				end, function(arg_204_0)
					print("[Mercury:ERROR] " .. tostring(arg_204_0))

					if not tostring(arg_202_0.body):find("success") then
						print(tostring(#tostring(arg_202_0.body)))
						print("[Mercury:ERROR] Failed decode response: " .. tostring(arg_202_0.body):sub(1, 230))
					end
				end)
			end)
		end,
		Get = function(arg_205_0, arg_205_1)
			if not var_138_3.connect then
				print("[Mercury:Server] Failed get req")

				return
			end

			local var_205_0 = {
				type = arg_205_0
			}

			var_205_0.version = "stable"
			var_205_0.time = utils.get_unix_time()
			var_205_0.nick = gui.ctx.user.username

			local var_205_1

			xpcall(function()
				var_205_1 = var_138_3.enc(slot_0_20_0.encode(var_205_0), var_138_3.token)
			end, function(arg_207_0)
				print("[Mercury:ERROR] Failed encode: " .. tostring(arg_207_0))
			end)

			arg_205_1 = arg_205_1 or function()
				return
			end

			if var_205_1 == nil then
				return
			end

			var_138_4:Get(slot_0_1_0 .. "/manager", {
				params = {
					id = var_138_3.uid,
					info = var_205_1
				}
			}, function(arg_209_0)
				if not arg_209_0 then
					return
				end

				if type(arg_209_0.body) ~= "string" then
					return
				end

				if string.find(arg_209_0.body, "Failed ") or not string.find(arg_209_0.body, "{") or not string.find(arg_209_0.body, "}") then
					return arg_205_1("Failed")
				end

				if string.find(arg_209_0.body, "Outdate") and #arg_209_0.body < 50 then
					return arg_205_1("Outdate")
				end

				if string.find(arg_209_0.body, "Invalid ") then
					return arg_205_1("Invalid data")
				end

				xpcall(function()
					local var_210_0 = var_138_5.normalize(arg_209_0.body)

					if tostring(var_210_0):find("success") and #tostring(var_210_0) < 20 then
						return
					end

					local var_210_1 = slot_0_20_0.decode(var_210_0)

					if var_210_1 and type(var_210_1) == "table" then
						arg_205_1(var_210_1)
					end
				end, function(arg_211_0)
					if not tostring(arg_209_0.body):find("success") then
						print(tostring(#tostring(arg_209_0.body)))
						print("[Mercury:ERROR] Failed decode response: " .. tostring(arg_209_0.body):sub(1, 230))
					end
				end)
			end)
		end
	}

	return var_138_5, var_138_3
end)()
slot_0_24_0 = (function()
	ffi.cdef(" \n        typedef struct {\n            long x;\n            long y;\n        } POINT;\n    ")

	local var_212_0 = ffi.cast("int(__stdcall*)(int)", utils.find_export("user32.dll", "GetAsyncKeyState"))
	local var_212_1 = ffi.cast("bool(__stdcall*)(POINT*)", utils.find_export("user32.dll", "GetCursorPos"))
	local var_212_2 = ffi.cast("void*(__stdcall*)()", utils.find_export("user32.dll", "GetForegroundWindow"))
	local var_212_3 = ffi.cast("void*(__stdcall*)(const char*, const char*)", utils.find_export("user32.dll", "FindWindowA"))
	local var_212_4 = ffi.cast("int(__stdcall*)(void*, POINT*)", utils.find_export("user32.dll", "ScreenToClient"))
	local var_212_5 = {
		cache = {
			point = ffi.new("POINT[1]")
		},
		main_window = var_212_3(nil, "Counter-Strike 2")
	}
	local var_212_6 = {
		click = {}
	}

	function var_212_5.window_is_active()
		return var_212_2() == var_212_5.main_window
	end

	function var_212_5.key_pressed(arg_214_0)
		local var_214_0 = var_212_0(arg_214_0)

		return bit.band(var_214_0, 32768) ~= 0
	end

	function var_212_5.key_click(arg_215_0)
		local var_215_0 = var_212_5.key_pressed(arg_215_0)
		local var_215_1 = game.global_vars.frame_count

		var_212_6.click[arg_215_0] = var_212_6.click[arg_215_0] or {
			time = 0,
			state = false
		}

		local var_215_2 = var_212_6.click[arg_215_0]

		if var_215_2.state == var_215_0 and var_215_2.time ~= var_215_1 then
			return false
		end

		var_215_2.state = var_215_0
		var_215_2.time = var_215_1
		var_212_6.click[arg_215_0] = var_215_2

		return var_215_0
	end

	function var_212_5.cursor_pos()
		local var_216_0 = var_212_5.cache.point

		var_212_1(var_216_0)

		local var_216_1 = var_212_5.main_window

		var_212_4(var_216_1, var_216_0)

		return slot_0_11_0(var_216_0[0].x, var_216_0[0].y)
	end

	return var_212_5
end)()
slot_0_3_0 = (function()
	slot_0_3_0 = {}
	slot_217_0_0 = draw.Vec2
	slot_217_1_0 = slot_217_0_0(0, 0)
	slot_217_2_0 = slot_217_0_0(0, 0)
	slot_217_3_0 = slot_217_0_0(0, 0)
	slot_217_4_0 = slot_217_0_0(0, 0)
	slot_217_5_0 = 8
	slot_217_6_0 = 8
	slot_217_7_0 = 5
	slot_217_8_0 = {
		warning = {
			icon = slot_0_6_0.icon_by_name.warning or "",
			color = slot_0_12_0(255, 76, 76)
		},
		error = {
			icon = slot_0_6_0.icon_by_name.warning or "",
			color = slot_0_12_0(255, 76, 76)
		},
		cloud = {
			icon = slot_0_6_0.icon_by_name.cloud or "",
			color = slot_0_12_0(145, 164, 255)
		},
		cloud_storm = {
			icon = slot_0_6_0.icon_by_name.cloud_storm or "",
			color = slot_0_12_0(255, 76, 76)
		},
		check = {
			icon = slot_0_6_0.icon_by_name.hit or "",
			color = slot_0_12_0(102, 255, 102)
		}
	}
	notify_cache = notify_cache or {}
	draw.surface.g.anti_alias = true

	ffi.cdef("        typedef struct {\n            uint8_t r;\n            uint8_t g;\n            uint8_t b;\n            uint8_t a;\n        } Color_rgba;\n    ")

	slot_217_9_0 = ffi.cast("void(__cdecl*)(const Color_rgba*, const char*, ...)", utils.find_export("tier0.dll", "?ConColorMsg@@YAXAEBVColor@@PEBDZZ"))
	slot_0_3_0.shaders = {
		blur = draw.shader("   \n            // define constant buffer.\n            cbuffer cb : register(b0) {\n                float4x4 mvp;\n                float2 tex;\n                float time;\n                float alpha;\n            };\n            \n            // define input.\n            struct PS_INPUT {\n                float4 pos : SV_POSITION;\n                float4 col : COLOR0;\n                float2 uv : TEXCOORD0;\n            };\n            \n            // use texture sampler and texture.\n            sampler sampler0;\n            Texture2D texture0;\n            \n            float4 main(PS_INPUT inp) : SV_Target {\n                float radius = 4.0; // blur radius\n                float2 inv_size = 0.5 / tex.xy; // inversed size of the texture\n                float weight = 0.0; // total weight\n                float4 color = 0.0; // total color\n            \n                // perform a gaussian blur\n                for (float x = -radius; x <= radius; x += 1.0)\n                {\n                    for (float y = -radius; y <= radius; y += 1.0)\n                    {\n                        float2 coord = inp.uv + float2(x, y) * inv_size;\n                        color += texture0.Sample(sampler0, coord) * exp(-((x * x + y * y) / (2.0 * radius * radius)));\n                        weight += exp(-((x * x + y * y) / (2.0 * radius * radius)));\n                    }\n                }\n            \n                // average the color\n                color /= weight;\n                color.a *= inp.col.a; // apply alpha modulation\n                return color;\n            }\n        "),
		blur_low = draw.shader("   \n            cbuffer cb : register(b0) {float4x4 mvp;float2 tex;float time;float alpha;}; \n            struct PS_INPUT {float4 pos : SV_POSITION;float4 col : COLOR0;float2 uv : TEXCOORD0;};\n            sampler sampler0;Texture2D texture0;\n            float4 main(PS_INPUT inp) : SV_Target {\n                float radius = 2.0; // blur radius\n                float2 inv_size = 0.5 / tex.xy; // inversed size of the texture\n                float weight = 0.0; // total weight\n                float4 color = 0.0; // total color  \n                for (float x = -radius; x <= radius; x += 1.0)\n                {\n                    for (float y = -radius; y <= radius; y += 1.0)\n                    {\n                        float2 coord = inp.uv + float2(x, y) * inv_size;\n                        color += texture0.Sample(sampler0, coord) * exp(-((x * x + y * y) / (2.0 * radius * radius)));\n                        weight += exp(-((x * x + y * y) / (2.0 * radius * radius)));\n                    }\n                }  \n                color /= weight;\n                color.a *= inp.col.a; // apply alpha modulation\n                return color;\n            }\n        "),
		blur_medium = draw.shader("   \n            cbuffer cb : register(b0) {float4x4 mvp;float2 tex;float time;float alpha;}; \n            struct PS_INPUT {float4 pos : SV_POSITION;float4 col : COLOR0;float2 uv : TEXCOORD0;};\n            sampler sampler0;Texture2D texture0;\n            float4 main(PS_INPUT inp) : SV_Target {\n                float radius = 3.0; // blur radius\n                float2 inv_size = 0.5 / tex.xy; // inversed size of the texture\n                float weight = 0.0; // total weight\n                float4 color = 0.0; // total color  \n                for (float x = -radius; x <= radius; x += 1.0)\n                {\n                    for (float y = -radius; y <= radius; y += 1.0)\n                    {\n                        float2 coord = inp.uv + float2(x, y) * inv_size;\n                        color += texture0.Sample(sampler0, coord) * exp(-((x * x + y * y) / (2.0 * radius * radius)));\n                        weight += exp(-((x * x + y * y) / (2.0 * radius * radius)));\n                    }\n                }  \n                color /= weight;\n                color.a *= inp.col.a; // apply alpha modulation\n                return color;\n            }\n        "),
		fast_blur = draw.shader("            cbuffer cb : register(b0) {\n                float4x4 mvp;\n                float2 tex; // texture size (width, height)\n                float time;\n                float alpha;\n            };\n            \n            struct PS_INPUT {\n                float4 pos : SV_POSITION;\n                float4 col : COLOR0;\n                float2 uv : TEXCOORD0;\n            };\n            \n            sampler sampler0;\n            Texture2D texture0;\n            \n            float4 main(PS_INPUT inp) : SV_Target {\n                float offset_x = 1.0 / tex.x * 2.5;\n                float offset_y = 1.0 / tex.y * 2.5;\n                float4 color = texture0.Sample(sampler0, inp.uv) * 0.227027; // Center\n                \n                color += texture0.Sample(sampler0, inp.uv + float2(offset_x, 0.0)) * 0.1945946;\n                color += texture0.Sample(sampler0, inp.uv + float2(-offset_x, 0.0)) * 0.1945946;\n                color += texture0.Sample(sampler0, inp.uv + float2(0.0, offset_y)) * 0.1945946;\n                color += texture0.Sample(sampler0, inp.uv + float2(0.0, -offset_y)) * 0.1945946;\n                \n                color += texture0.Sample(sampler0, inp.uv + float2(offset_x, offset_y)) * 0.04054;\n                color += texture0.Sample(sampler0, inp.uv + float2(-offset_x, -offset_y)) * 0.04054;\n                color += texture0.Sample(sampler0, inp.uv + float2(-offset_x, offset_y)) * 0.04054;\n                color += texture0.Sample(sampler0, inp.uv + float2(offset_x, -offset_y)) * 0.04054;\n                \n                color.a *= inp.col.a * alpha;\n                return color;\n            }\n        "),
		clean = draw.shader("            cbuffer cb : register(b0) {\n                float4x4 mvp;\n                float2 tex;\n                float time;\n                float alpha;\n            };\n \n            struct PS_INPUT {\n                float4 pos : SV_POSITION;\n                float4 col : COLOR0;\n                float2 uv : TEXCOORD0;\n            };\n\n            // use texture sampler and texture.\n            sampler sampler0;\n            Texture2D texture0;\n\n            float4 main(PS_INPUT inp) : SV_Target { \n                float4 color = texture0.Sample(sampler0, inp.uv);\n                color.a *= inp.col.a; // apply alpha modulation\n                return color;\n            }\n        "),
		fullscreen = draw.shader("            cbuffer cb : register(b0) {\n                float4x4 mvp;\n                float2 tex;\n                float time;\n                float alpha;\n            };\n\n            struct PS_INPUT {\n                float4 pos : SV_POSITION;\n                float4 col : COLOR0;\n                float2 uv : TEXCOORD0;\n            };\n\n            sampler sampler0;\n            Texture2D texture0;\n\n            float4 main(PS_INPUT inp) : SV_Target {\n                float2 uv = inp.uv;\n                \n                float2 distortion = float2(\n                    sin(uv.y * 8.0 + time * 0.3) * 0.02,\n                    cos(uv.x * 8.0 - time * 0.3) * 0.02\n                );\n                uv += distortion;\n                \n                float wave1 = sin(uv.x * 12.0 * 1.3 + time * 0.8 + uv.y * 4.0);\n                float wave2 = sin(uv.y * 16.0 * 1.3 - time * 0.6 + uv.x * 6.0);\n                float wave3 = sin((uv.x + uv.y) * 10.0 + time * 0.5);\n                \n                float pattern1 = sin(uv.x * 20.0 + time);\n                float pattern2 = sin(uv.y * 24.0 - time * 0.8);\n                float pattern3 = sin(length(uv - 0.5) * 30.0 - time * 1.2);\n                \n                float combined = (wave1 + wave2 + wave3 + pattern1 + pattern2 + pattern3) / 6.0;\n                float rawIntensity = combined * 0.5 + 0.5;\n                \n                float intensity = smoothstep(0.6, 0.99, rawIntensity);\n                \n                float glow = smoothstep(0.5, 0.65, rawIntensity) * 0.4;\n                \n                float pulse = sin(time * 0.5) * 0.1 + 0.9;\n                float colorShift = sin(combined * 2.0 + time * 0.4) * 0.15 + 0.85;\n                \n                float brightness = smoothstep(0.68, 0.82, rawIntensity);\n                float3 baseColor = inp.col.rgb * colorShift * pulse;\n                float3 plasmaColor = lerp(baseColor, float3(1.0, 1.0, 1.0), brightness * 0.7);\n                \n                plasmaColor = lerp(plasmaColor, inp.col.rgb * 0.6, glow);\n                \n                float finalAlpha = (intensity + glow * 0.5) * alpha * inp.col.a; \n                return float4(plasmaColor, finalAlpha);\n            }\n\n        ")
	}

	for iter_217_0, iter_217_1 in pairs(slot_0_3_0.shaders) do
		iter_217_1:create()
	end

	function slot_0_3_0.on_screen(arg_218_0, arg_218_1)
		if not arg_218_0 then
			return false
		end

		arg_218_1 = arg_218_1 or 50

		return arg_218_0.x > -arg_218_1 and arg_218_0.x < slot_0_6_0.screen_size.x + arg_218_1 and arg_218_0.y > -arg_218_1 and arg_218_0.y < slot_0_6_0.screen_size.y + arg_218_1
	end

	function slot_0_3_0.off_screen_pos(arg_219_0, arg_219_1)
		if not arg_219_0 then
			return false
		end

		arg_219_1 = arg_219_1 or 50

		return slot_0_11_0(math.clamp(arg_219_0.x, arg_219_1, slot_0_6_0.screen_size.x - arg_219_1), math.clamp(arg_219_0.y, arg_219_1, slot_0_6_0.screen_size.y - arg_219_1))
	end

	function slot_0_3_0.get_shader(arg_220_0, arg_220_1)
		if not slot_0_3_0.shaders[arg_220_0] then
			local var_220_0 = draw.shader(" \n                // define constant buffer.\n                cbuffer cb : register(b0) {\n                    float4x4 mvp;\n                    float2 tex;\n                    float time;\n                    float alpha;\n                };\n\n                // define input.\n                struct PS_INPUT {\n                    float4 pos : SV_POSITION;\n                    float4 col : COLOR0;\n                    float2 uv : TEXCOORD0;\n                };\n\n                // use texture sampler and texture.\n                sampler sampler0;\n                Texture2D texture0;\n\n                float4 main(PS_INPUT inp) : SV_Target {\n                    // Просто возвращаем белый цвет с учетом прозрачности\n                    float4 white = float4(1.0, 1.0, 1.0, 1.0);\n                    white.a *= inp.col.a; // сохраняем исходную прозрачность\n                    return white;\n                }\n            ")

			var_220_0:create()

			slot_0_3_0.shaders[arg_220_0] = var_220_0

			return var_220_0
		end

		return slot_0_3_0.shaders[arg_220_0]
	end

	function slot_0_3_0.set_shader(arg_221_0, arg_221_1, arg_221_2)
		local var_221_0 = slot_0_3_0.get_shader(arg_221_0)

		if not var_221_0 then
			return
		end

		local var_221_1 = draw.surface.g

		var_221_1.texture = draw.adapter:get_back_buffer_downsampled(), var_221_1:set_shader(var_221_0)

		if arg_221_2 and arg_221_2.x then
			local var_221_2 = slot_0_6_0.screen_size.x
			local var_221_3 = slot_0_6_0.screen_size.y

			var_221_1.uv_rect = draw.rect(arg_221_1.x / var_221_2, arg_221_1.y / var_221_3, arg_221_2.x / var_221_2, arg_221_2.y / var_221_3)
		end
	end

	function slot_0_3_0.remove_shader()
		local var_222_0 = draw.surface.g

		var_222_0:set_shader(nil)
		var_222_0:set_texture(nil)
	end

	function slot_0_3_0.get_icon(arg_223_0)
		if slot_0_6_0.icon_by_name[arg_223_0] then
			return slot_0_6_0.icon_by_name[arg_223_0] or ""
		else
			print("[Mercury:Draw] Error get icon by name: " .. tostring(arg_223_0))

			return ""
		end
	end

	function slot_0_3_0.point_in_triangle(arg_224_0, arg_224_1, arg_224_2, arg_224_3)
		local var_224_0 = ((arg_224_1.y - arg_224_2.y) * (arg_224_3.x - arg_224_2.x) + (arg_224_2.x - arg_224_1.x) * (arg_224_3.y - arg_224_2.y)) / ((arg_224_1.y - arg_224_2.y) * (arg_224_0.x - arg_224_2.x) + (arg_224_2.x - arg_224_1.x) * (arg_224_0.y - arg_224_2.y))
		local var_224_1 = ((arg_224_2.y - arg_224_0.y) * (arg_224_3.x - arg_224_2.x) + (arg_224_0.x - arg_224_2.x) * (arg_224_3.y - arg_224_2.y)) / ((arg_224_1.y - arg_224_2.y) * (arg_224_0.x - arg_224_2.x) + (arg_224_2.x - arg_224_1.x) * (arg_224_0.y - arg_224_2.y))
		local var_224_2 = 1 - var_224_0 - var_224_1

		return var_224_0 >= 0 and var_224_1 >= 0 and var_224_2 >= 0
	end

	function slot_0_3_0.is_poly_ear(arg_225_0, arg_225_1, arg_225_2)
		local var_225_0 = arg_225_0[arg_225_1 == 1 and arg_225_2 or arg_225_1 - 1]
		local var_225_1 = arg_225_0[arg_225_1]
		local var_225_2 = arg_225_0[arg_225_1 % arg_225_2 + 1]

		if (var_225_1.x - var_225_0.x) * (var_225_2.y - var_225_1.y) - (var_225_1.y - var_225_0.y) * (var_225_2.x - var_225_1.x) < 0 then
			return false
		end

		for iter_225_0 = 1, arg_225_2 do
			if iter_225_0 ~= arg_225_1 and iter_225_0 ~= arg_225_1 % arg_225_2 + 1 and iter_225_0 ~= (arg_225_1 == 1 and arg_225_2 or arg_225_1 - 1) and slot_0_3_0.point_in_triangle(var_225_0, var_225_1, var_225_2, arg_225_0[iter_225_0]) then
				return false
			end
		end

		return true
	end

	function slot_0_3_0.triangulate_convex(arg_226_0)
		if #arg_226_0 < 3 then
			return {}
		end

		local var_226_0 = {}
		local var_226_1 = arg_226_0[1]

		for iter_226_0 = 2, #arg_226_0 - 1 do
			table.insert(var_226_0, {
				draw.Vec2(var_226_1.x, var_226_1.y),
				draw.Vec2(arg_226_0[iter_226_0].x, arg_226_0[iter_226_0].y),
				draw.Vec2(arg_226_0[iter_226_0 + 1].x, arg_226_0[iter_226_0 + 1].y)
			})
		end

		return var_226_0
	end

	function slot_0_3_0.triangulate(arg_227_0)
		if #arg_227_0 < 3 then
			return {}
		end

		local var_227_0 = true

		for iter_227_0 = 1, #arg_227_0 do
			local var_227_1 = arg_227_0[iter_227_0 == 1 and #arg_227_0 or iter_227_0 - 1]
			local var_227_2 = arg_227_0[iter_227_0]
			local var_227_3 = arg_227_0[iter_227_0 % #arg_227_0 + 1]

			if (var_227_2.x - var_227_1.x) * (var_227_3.y - var_227_2.y) - (var_227_2.y - var_227_1.y) * (var_227_3.x - var_227_2.x) < 0 then
				var_227_0 = false

				break
			end
		end

		if var_227_0 then
			return slot_0_3_0.triangulate_convex(arg_227_0)
		end

		local var_227_4 = {}

		for iter_227_1 = 1, #arg_227_0 do
			var_227_4[iter_227_1] = iter_227_1
		end

		local var_227_5 = 0
		local var_227_6 = {}

		while #var_227_4 > 3 and var_227_5 < #arg_227_0 do
			var_227_5 = var_227_5 + 1

			for iter_227_2 = 1, #var_227_4 do
				if slot_0_3_0.is_poly_ear(arg_227_0, var_227_4[iter_227_2], #var_227_4) then
					local var_227_7 = arg_227_0[var_227_4[iter_227_2 == 1 and #var_227_4 or iter_227_2 - 1]]
					local var_227_8 = arg_227_0[var_227_4[iter_227_2]]
					local var_227_9 = arg_227_0[var_227_4[iter_227_2 % #var_227_4 + 1]]

					table.insert(var_227_6, {
						draw.Vec2(var_227_7.x, var_227_7.y),
						draw.Vec2(var_227_8.x, var_227_8.y),
						draw.Vec2(var_227_9.x, var_227_9.y)
					})
					table.remove(var_227_4, iter_227_2)

					break
				end
			end
		end

		if #var_227_4 == 3 then
			table.insert(var_227_6, {
				draw.Vec2(arg_227_0[var_227_4[1]].x, arg_227_0[var_227_4[1]].y),
				draw.Vec2(arg_227_0[var_227_4[2]].x, arg_227_0[var_227_4[2]].y),
				draw.Vec2(arg_227_0[var_227_4[3]].x, arg_227_0[var_227_4[3]].y)
			})
		end

		return var_227_6
	end

	function slot_0_3_0.polygon(arg_228_0, arg_228_1, ...)
		local var_228_0 = {
			...
		}
		local var_228_1 = draw.surface

		var_228_1.g.anti_alias = true

		local var_228_2 = slot_0_3_0.triangulate(var_228_0)

		for iter_228_0, iter_228_1 in ipairs(var_228_2) do
			if arg_228_1 then
				var_228_1:add_triangle_filled(iter_228_1[1], iter_228_1[2], iter_228_1[3], arg_228_0)
			else
				var_228_1:add_triangle(iter_228_1[1], iter_228_1[2], iter_228_1[3], arg_228_0)
			end
		end
	end

	function slot_0_3_0.text(arg_229_0, arg_229_1, arg_229_2, arg_229_3)
		local var_229_0 = draw.surface

		var_229_0.font = arg_229_1 or draw.fonts.gui_main

		var_229_0:add_text(arg_229_2, arg_229_0, arg_229_3 or slot_0_12_0(), draw.text_params.with_line(draw.text_alignment.center))
	end

	function slot_0_3_0.text_center(arg_230_0, arg_230_1, arg_230_2, arg_230_3)
		local var_230_0 = draw.surface

		var_230_0.font = arg_230_1 or draw.fonts.gui_main

		local var_230_1 = slot_0_3_0.text_size(arg_230_0, arg_230_1)

		var_230_0:add_text(slot_0_11_0(arg_230_2.x - var_230_1.x / 2, arg_230_2.y), arg_230_0, arg_230_3 or slot_0_6_0.white_color, draw.text_params.with_line(draw.text_alignment.center))
	end

	function slot_0_3_0.text_outline(arg_231_0, arg_231_1, arg_231_2, arg_231_3)
		local var_231_0 = draw.surface

		var_231_0.font = arg_231_1 or draw.fonts.gui_main

		var_231_0:add_text(slot_0_11_0(arg_231_2.x + 1, arg_231_2.y + 1), arg_231_0, slot_0_12_0(0, (arg_231_3 or slot_0_12_0()):get_a()))
		var_231_0:add_text(arg_231_2, arg_231_0, arg_231_3 or slot_0_12_0())
	end

	function slot_0_3_0.text_bold_outline(arg_232_0, arg_232_1, arg_232_2, arg_232_3)
		local var_232_0 = draw.surface

		var_232_0.font = arg_232_1 or draw.fonts.gui_main

		local var_232_1 = arg_232_3 or slot_0_12_0()
		local var_232_2 = slot_0_12_0(0, var_232_1:get_a())

		var_232_0:add_text(slot_0_11_0(arg_232_2.x + 1, arg_232_2.y + 1), arg_232_0, var_232_2)
		var_232_0:add_text(slot_0_11_0(arg_232_2.x + 1, arg_232_2.y - 1), arg_232_0, var_232_2)
		var_232_0:add_text(slot_0_11_0(arg_232_2.x - 1, arg_232_2.y - 1), arg_232_0, var_232_2)
		var_232_0:add_text(slot_0_11_0(arg_232_2.x - 1, arg_232_2.y + 1), arg_232_0, var_232_2)
		var_232_0:add_text(slot_0_11_0(arg_232_2.x + 1, arg_232_2.y), arg_232_0, var_232_2)
		var_232_0:add_text(slot_0_11_0(arg_232_2.x - 1, arg_232_2.y), arg_232_0, var_232_2)
		var_232_0:add_text(slot_0_11_0(arg_232_2.x, arg_232_2.y + 1), arg_232_0, var_232_2)
		var_232_0:add_text(slot_0_11_0(arg_232_2.x, arg_232_2.y - 1), arg_232_0, var_232_2)
		var_232_0:add_text(arg_232_2, arg_232_0, var_232_1)
	end

	function slot_0_3_0.text_enchanted(arg_233_0, arg_233_1, arg_233_2, arg_233_3, arg_233_4, arg_233_5, arg_233_6, arg_233_7)
		local var_233_0 = draw.surface

		var_233_0.font = arg_233_1 or draw.fonts.gui_main

		if arg_233_6 then
			var_233_0:add_text(arg_233_2, arg_233_0, slot_0_12_0(0, arg_233_3 and arg_233_3:get_a() / 255 or 1))
		end

		local var_233_1 = 0
		local var_233_2 = #arg_233_0 - 1

		arg_233_5 = arg_233_5 or 1

		for iter_233_0 = 1, var_233_2 + 1 do
			local var_233_3 = string.sub(arg_233_0, iter_233_0, iter_233_0)
			local var_233_4 = slot_0_3_0.text_size(var_233_3, arg_233_1)
			local var_233_5 = math.lerp_color(arg_233_4, arg_233_3, math.abs(math.sin((slot_0_6_0.real_time - iter_233_0 * 0.08) * arg_233_5)))

			var_233_0:add_text(slot_0_11_0(arg_233_2.x + var_233_1, arg_233_2.y), var_233_3, var_233_5)

			var_233_1 = var_233_1 + var_233_4.x
		end
	end

	slot_217_10_0 = ffi.new("Color_rgba", {
		a = 255,
		r = 255,
		g = 255,
		b = 255
	})

	function slot_0_3_0.colored_print(arg_234_0)
		slot_217_10_0.a = 0

		slot_217_9_0(slot_217_10_0, "\n\b")

		for iter_234_0 = 1, #arg_234_0 do
			local var_234_0 = arg_234_0[iter_234_0]

			if type(var_234_0[1]) == "string" and type(var_234_0[2]) == "userdata" then
				var_234_0[2] = var_234_0[2] and var_234_0[2].get_r and var_234_0[2] or slot_0_12_0(255, 0, 0)
				slot_217_10_0.r = var_234_0[2]:get_r()
				slot_217_10_0.g = var_234_0[2]:get_g()
				slot_217_10_0.b = var_234_0[2]:get_b()
				slot_217_10_0.a = var_234_0[2]:get_a()

				slot_217_9_0(slot_217_10_0, (var_234_0[1] or "") .. "\x00")
			end
		end
	end

	function slot_0_3_0.physic_text(arg_235_0, arg_235_1, arg_235_2, arg_235_3, arg_235_4)
		slot_235_5_0 = draw.surface
		slot_235_5_0.font = arg_235_1 or draw.fonts.gui_main
		slot_235_6_0 = slot_0_6_0.frame_time
		slot_235_7_0 = 0
		arg_235_3 = arg_235_3 or slot_0_12_0()

		for iter_235_0 = 1, #arg_235_0 do
			slot_235_12_0 = arg_235_0[iter_235_0]
			slot_235_12_0.rotate = slot_235_12_0.rotate + 45 * (slot_235_12_0.multiply or 0) * slot_235_6_0
			slot_235_12_0.multiply = math.lerp(slot_235_12_0.multiply, 0, slot_235_6_0 / 2)
			slot_235_12_0.offset = slot_0_11_0(slot_235_12_0.offset.x + slot_235_12_0.Vector.x * slot_235_6_0, slot_235_12_0.offset.y + slot_235_12_0.Vector.y * slot_235_6_0)
			slot_235_12_0.Vector = math.lerp_vector(slot_235_12_0.Vector, slot_0_11_0(0, slot_235_12_0.Vector.y + 70), slot_235_6_0 * 2)
			draw.surface.g.rotation = slot_235_12_0.rotate

			if arg_235_4 == 1 then
				slot_235_5_0:add_text(slot_0_11_0(arg_235_2.x + slot_235_12_0.offset.x + slot_235_7_0 + 1, arg_235_2.y + slot_235_12_0.offset.y + 1), slot_235_12_0[1] or "", slot_0_12_0(0, arg_235_3:get_a()))
				slot_235_5_0:add_text(slot_0_11_0(arg_235_2.x + slot_235_12_0.offset.x + slot_235_7_0, arg_235_2.y + slot_235_12_0.offset.y), slot_235_12_0[1] or "", arg_235_3)
			elseif arg_235_4 == 2 then
				slot_0_3_0.text_fatality(slot_235_12_0[1], arg_235_1, slot_0_11_0(arg_235_2.x + slot_235_12_0.offset.x + slot_235_7_0, arg_235_2.y + slot_235_12_0.offset.y), arg_235_3)
			elseif arg_235_4 == 3 then
				slot_235_5_0:add_text(slot_0_11_0(arg_235_2.x + slot_235_12_0.offset.x + slot_235_7_0 - slot_235_12_0.Vector.x * slot_235_6_0 * 6, arg_235_2.y + slot_235_12_0.offset.y - slot_235_12_0.Vector.y * slot_235_6_0 * 6), slot_235_12_0[1] or "", slot_0_12_0(255, 70, 66, arg_235_3:get_a()))
				slot_235_5_0:add_text(slot_0_11_0(arg_235_2.x + slot_235_12_0.offset.x + slot_235_7_0 - slot_235_12_0.Vector.x * slot_235_6_0 * 3, arg_235_2.y + slot_235_12_0.offset.y - slot_235_12_0.Vector.y * slot_235_6_0 * 3), slot_235_12_0[1] or "", slot_0_12_0(50, 70, 255, arg_235_3:get_a()))
				slot_235_5_0:add_text(slot_0_11_0(arg_235_2.x + slot_235_12_0.offset.x + slot_235_7_0, arg_235_2.y + slot_235_12_0.offset.y), slot_235_12_0[1] or "", arg_235_3)
			else
				slot_235_5_0:add_text(slot_0_11_0(arg_235_2.x + slot_235_12_0.offset.x + slot_235_7_0, arg_235_2.y + slot_235_12_0.offset.y), slot_235_12_0[1] or "", arg_235_3)
			end

			slot_235_7_0 = slot_235_7_0 + slot_0_3_0.text_size(slot_235_12_0[1], arg_235_1).x + 5
		end

		draw.surface.g.rotation = 0
	end

	function slot_0_3_0.text_fatality(arg_236_0, arg_236_1, arg_236_2, arg_236_3, arg_236_4)
		local var_236_0 = draw.surface

		var_236_0.font = arg_236_1 or draw.fonts.gui_main
		arg_236_4 = arg_236_4 or 2

		local var_236_1 = slot_0_6_0.real_time * 10
		local var_236_2 = slot_0_11_0(arg_236_4 * math.cos(var_236_1), arg_236_4 * math.sin(var_236_1))
		local var_236_3 = slot_0_11_0(arg_236_4 * math.cos(var_236_1 + 180), arg_236_4 * math.sin(var_236_1 + 180))

		var_236_0:add_text(slot_0_11_0(arg_236_2.x + var_236_3.x, arg_236_2.y + var_236_3.y + 1), arg_236_0, slot_0_12_0(30, 30, 255, (arg_236_3 or slot_0_12_0()):get_a()))
		var_236_0:add_text(slot_0_11_0(arg_236_2.x + var_236_2.x, arg_236_2.y + var_236_2.y), arg_236_0, slot_0_12_0(255, 30, 30, (arg_236_3 or slot_0_12_0()):get_a() * 0.8))
		var_236_0:add_text(arg_236_2, arg_236_0, arg_236_3 or slot_0_12_0())
	end

	slot_217_11_0 = {}

	function slot_0_3_0.text_size(arg_237_0, arg_237_1)
		if slot_217_11_0[arg_237_1] and slot_217_11_0[arg_237_1][arg_237_0] then
			return slot_217_11_0[arg_237_1][arg_237_0]
		end

		if not arg_237_1 then
			return slot_0_11_0(-1, -1)
		end

		slot_217_11_0[arg_237_1] = slot_217_11_0[arg_237_1] or {}
		slot_217_11_0[arg_237_1][arg_237_0] = arg_237_1:get_text_size(arg_237_0, true)

		return slot_217_11_0[arg_237_1][arg_237_0]
	end

	slot_0_7_0.cycle(60, function()
		slot_217_11_0 = {}
	end)

	function slot_0_3_0.multi_text(arg_239_0, arg_239_1, arg_239_2, arg_239_3, arg_239_4)
		arg_239_4 = arg_239_4 or 1

		local var_239_0 = slot_0_11_0(arg_239_2.x, arg_239_2.y)

		for iter_239_0 = 1, #arg_239_0 do
			local var_239_1 = arg_239_0[iter_239_0]
			local var_239_2 = var_239_1[1] or ""
			local var_239_3 = var_239_1.effect
			local var_239_4 = var_239_1.add_y or var_239_1.icon and 2 or 0
			local var_239_5 = var_239_1.icon and var_239_1.icon_font and var_239_1.icon_font or var_239_1.icon and (arg_239_3 or slot_0_18_0.icons.mercury) or arg_239_1 or slot_0_18_0.verdana or draw.fonts.gui_main
			local var_239_6 = slot_0_3_0.text_size(var_239_2, var_239_5)
			local var_239_7 = var_239_1[2] or slot_0_12_0()
			local var_239_8 = var_239_7:a(var_239_7:get_a() * arg_239_4 / 255)
			local var_239_9 = var_239_1.second or slot_0_12_0(255, 0, 0)
			local var_239_10 = var_239_9:a(var_239_9:get_a() * arg_239_4 / 255)

			if var_239_3 then
				if var_239_3 == "fade" then
					-- block empty
				elseif var_239_3 == "enchanted" then
					slot_0_3_0.text_enchanted(var_239_2, var_239_5, slot_0_11_0(var_239_0.x, var_239_0.y + var_239_4), var_239_8, var_239_10, var_239_1.speed or 1, var_239_1.outline or false)
				else
					slot_0_3_0.text(var_239_2, var_239_5, slot_0_11_0(var_239_0.x, var_239_0.y + var_239_4), var_239_8)
				end
			else
				slot_0_3_0.text(var_239_2, var_239_5, slot_0_11_0(var_239_0.x, var_239_0.y + var_239_4), var_239_8)
			end

			var_239_0.x = var_239_0.x + var_239_6.x
		end
	end

	function slot_0_3_0.get_multi_text_size(arg_240_0, arg_240_1, arg_240_2)
		local var_240_0 = 0

		for iter_240_0 = 1, #arg_240_0 do
			local var_240_1 = arg_240_0[iter_240_0]
			local var_240_2 = var_240_1.icon and var_240_1.icon_font and var_240_1.icon_font or var_240_1.icon and (arg_240_2 or slot_0_18_0.icons.mercury) or arg_240_1 or slot_0_18_0.verdana or draw.fonts.gui_main

			var_240_0 = var_240_0 + slot_0_3_0.text_size(var_240_1[1] or "", var_240_2).x
		end

		return var_240_0
	end

	function slot_0_3_0.rect_outline(arg_241_0, arg_241_1, arg_241_2, arg_241_3, arg_241_4)
		local var_241_0 = {}

		arg_241_2 = arg_241_2 > 0 and arg_241_2 or 1
		arg_241_3 = arg_241_3 or slot_0_12_0(255, 255, 255, 255)
		arg_241_2 = math.min(arg_241_1.y - arg_241_0.y, arg_241_1.x - arg_241_0.x, arg_241_2 * 2) / 2

		local var_241_1 = {
			slot_0_11_0(arg_241_1.x - arg_241_2, arg_241_1.y - arg_241_2),
			slot_0_11_0(arg_241_0.x + arg_241_2, arg_241_1.y - arg_241_2),
			slot_0_11_0(arg_241_0.x + arg_241_2, arg_241_0.y + arg_241_2),
			slot_0_11_0(arg_241_1.x - arg_241_2, arg_241_0.y + arg_241_2)
		}
		local var_241_2 = 90 / arg_241_2

		for iter_241_0 = 1, #var_241_1 do
			for iter_241_1 = (iter_241_0 - 1) * 90 + var_241_2 / 2, iter_241_0 * 90, var_241_2 do
				local var_241_3 = var_241_1[iter_241_0].x + arg_241_2 * math.cos(iter_241_1 * 0.01745)
				local var_241_4 = var_241_1[iter_241_0].y + arg_241_2 * math.sin(iter_241_1 * 0.01745)

				table.insert(var_241_0, slot_0_11_0(var_241_3, var_241_4))
			end
		end

		local var_241_5 = draw.surface

		for iter_241_2 = 1, #var_241_0 - 1 do
			slot_0_3_0.line(var_241_5, var_241_0[iter_241_2], var_241_0[iter_241_2 + 1], arg_241_3, nil, arg_241_4)
		end

		slot_0_3_0.line(var_241_5, var_241_0[1], var_241_0[#var_241_0], arg_241_3, nil, arg_241_4)
	end

	function slot_0_3_0.rect(arg_242_0, arg_242_1, arg_242_2, arg_242_3, arg_242_4, arg_242_5)
		local var_242_0 = draw.surface

		if arg_242_4 then
			slot_0_3_0.rect_outline(arg_242_0, arg_242_1, arg_242_3, arg_242_2, arg_242_5)
		else
			var_242_0:add_rect_filled_rounded(draw.rect(arg_242_0.x, arg_242_0.y, arg_242_1.x, arg_242_1.y), arg_242_2 or slot_0_12_0(), arg_242_3 or 10, draw.rounding.all)
		end
	end

	function slot_0_3_0.line(arg_243_0, arg_243_1, arg_243_2, arg_243_3, arg_243_4, arg_243_5)
		arg_243_0 = arg_243_0 or draw.surface

		if arg_243_4 then
			arg_243_0:add_line_multicolor(arg_243_1, arg_243_2, arg_243_3, arg_243_4, arg_243_5 or 1)
		else
			arg_243_0:add_line(arg_243_1, arg_243_2, arg_243_3, arg_243_5 or 1)
		end
	end

	function slot_0_3_0.line_glow(arg_244_0, arg_244_1, arg_244_2, arg_244_3, arg_244_4, arg_244_5)
		arg_244_0 = arg_244_0 or draw.surface

		if arg_244_4 then
			arg_244_0:add_line_multicolor(arg_244_1, arg_244_2, arg_244_3, arg_244_4, arg_244_5 or 1)
		else
			local var_244_0 = 2
			local var_244_1 = 8

			for iter_244_0 = 1, var_244_1, var_244_0 do
				local var_244_2 = var_244_0 * iter_244_0
				local var_244_3 = arg_244_3:a((1 - iter_244_0 / var_244_1)^1.5 * arg_244_3:get_a() / 255)

				arg_244_0:add_line(arg_244_1, arg_244_2, var_244_3, (arg_244_5 or 12) + var_244_2)
			end
		end
	end

	function slot_0_3_0.glow(arg_245_0, arg_245_1, arg_245_2, arg_245_3)
		draw.surface:add_glow(draw.rect(arg_245_0.x, arg_245_0.y, arg_245_1.x, arg_245_1.y), arg_245_3 or 1, arg_245_2 or slot_0_12_0())
	end

	function slot_0_3_0.push_clip_rect(arg_246_0, arg_246_1)
		draw.surface.g.clip_rect = draw.rect(arg_246_0.x, arg_246_0.y, arg_246_1.x, arg_246_1.y)

		do return end

		draw.surface.override_clip_rect = draw.rect(arg_246_0.x, arg_246_0.y, arg_246_1.x, arg_246_1.y)
	end

	function slot_0_3_0.pop_clip_rect()
		draw.surface.g.clip_rect = nil

		do return end

		draw.surface.override_clip_rect = nil
	end

	function slot_0_3_0.shadow(arg_248_0, arg_248_1, arg_248_2, arg_248_3, arg_248_4, arg_248_5)
		if arg_248_2:get_a() == 0 then
			return
		end

		arg_248_5 = arg_248_5 or 2

		for iter_248_0 = 1, arg_248_3 do
			local var_248_0 = arg_248_5 * iter_248_0

			slot_0_3_0.rect(slot_0_11_0(arg_248_0.x - var_248_0, arg_248_0.y - var_248_0), slot_0_11_0(arg_248_1.x + var_248_0, arg_248_1.y + var_248_0), arg_248_2:a((1 - iter_248_0 / arg_248_3)^1.5 * arg_248_2:get_a() / 255), arg_248_4 + var_248_0)
		end
	end

	function slot_0_3_0.blur(arg_249_0, arg_249_1, arg_249_2)
		arg_249_2 = arg_249_2 or 0

		if arg_249_2 == 0 then
			return
		end

		local var_249_0 = draw.surface.g
		local var_249_1, var_249_2 = game.engine:get_screen_size()

		var_249_0.texture = draw.adapter:get_back_buffer(), var_249_0:set_shader(slot_0_3_0.shaders.blur)
		var_249_0.uv_rect = draw.rect(arg_249_0.x / var_249_1, arg_249_0.y / var_249_2, arg_249_1.x / var_249_1, arg_249_1.y / var_249_2)

		draw.surface:add_rect_filled_rounded(draw.rect(arg_249_0.x, arg_249_0.y, arg_249_1.x, arg_249_1.y), draw.color(0, 0, 0, 255 * arg_249_2), 0, draw.rounding.all)
		var_249_0:set_shader(nil)
		var_249_0:set_texture(nil)
	end

	function slot_0_3_0.shader_rounded(arg_250_0, arg_250_1, arg_250_2, arg_250_3, arg_250_4, arg_250_5, arg_250_6)
		arg_250_4 = arg_250_4 or 0

		if arg_250_4 == 0 then
			return
		end

		local var_250_0 = draw.surface.g

		slot_0_3_0.set_shader(arg_250_0)

		var_250_0.anti_alias = true

		local var_250_1, var_250_2 = game.engine:get_screen_size()

		var_250_0.uv_rect = draw.rect(arg_250_1.x / var_250_1, arg_250_1.y / var_250_2, arg_250_2.x / var_250_1, arg_250_2.y / var_250_2)
		draw.surface.tex_sz = slot_0_11_0(var_250_1, var_250_2)

		local var_250_3 = arg_250_5 and arg_250_5:a(arg_250_4) or slot_0_12_0(0, 255 * arg_250_4)

		draw.surface:add_rect_filled_rounded(draw.rect(arg_250_1.x, arg_250_1.y, arg_250_2.x, arg_250_2.y), var_250_3, arg_250_3, draw.rounding.all)
		slot_0_3_0.remove_shader()

		draw.surface.tex_sz = nil
	end

	function slot_0_3_0.shader_rounded_sz(arg_251_0, arg_251_1, arg_251_2, arg_251_3, arg_251_4, arg_251_5)
		arg_251_5 = arg_251_5 or slot_0_6_0.white_color

		if not arg_251_5.get_a or arg_251_5:get_a() == 0 then
			return
		end

		local var_251_0 = arg_251_2.x - arg_251_1.x
		local var_251_1 = arg_251_2.y - arg_251_1.y

		slot_0_3_0.set_shader(arg_251_0, arg_251_1, arg_251_2)

		draw.surface.g.anti_alias = true
		draw.surface.tex_sz = arg_251_3 or slot_0_11_0(arg_251_2.x - arg_251_1.x, arg_251_2.y - arg_251_1.y)

		slot_0_3_0.rect(arg_251_1, arg_251_2, arg_251_5, arg_251_4)
		slot_0_3_0.remove_shader()
	end

	function slot_0_3_0.get_multi_text_size_array(arg_252_0, arg_252_1, arg_252_2, arg_252_3)
		local var_252_0 = {}
		local var_252_1 = 0

		for iter_252_0 = 1, #arg_252_0 do
			local var_252_2 = arg_252_0[iter_252_0]
			local var_252_3 = var_252_2.icon and var_252_2.icon_font and var_252_2.icon_font or var_252_2.icon and (arg_252_2 or slot_0_18_0.icons.mercury) or arg_252_1 or slot_0_18_0.verdana or draw.fonts.gui_main
			local var_252_4 = slot_0_3_0.text_size(var_252_2[1] or "", var_252_3).x

			if arg_252_3 then
				var_252_0[iter_252_0] = var_252_1
				var_252_1 = var_252_1 + var_252_4
			else
				var_252_0[iter_252_0] = var_252_4
			end
		end

		return var_252_0
	end

	function slot_0_3_0.make_notify_style(arg_253_0, arg_253_1, arg_253_2, arg_253_3)
		arg_253_1 = arg_253_1 or slot_0_12_0(255, 80, 80)

		return {
			round = 8,
			icon = arg_253_0 and {
				text = arg_253_0,
				color = arg_253_1
			} or nil,
			outline = arg_253_1:a(0.6),
			background = slot_0_12_0(31, arg_253_2 and 90 or 200),
			shader = arg_253_2,
			shader_screen = arg_253_3,
			shader_color = arg_253_1
		}
	end

	function slot_0_3_0.notify(arg_254_0, arg_254_1, arg_254_2, arg_254_3)
		if type(arg_254_0) == "string" then
			arg_254_0 = {
				{
					arg_254_0
				}
			}
		end

		local var_254_0 = false

		arg_254_1 = arg_254_1 or {}

		if arg_254_1.id then
			for iter_254_0 = 1, #notify_cache do
				local var_254_1 = notify_cache[iter_254_0]

				if var_254_1.id == arg_254_1.id and arg_254_1.id ~= -1 then
					var_254_0 = true
					var_254_1.time = slot_0_6_0.real_time + (arg_254_1.bonus_time or 0)
					var_254_1.text = arg_254_0 or var_254_1.text
					var_254_1.text_size = slot_0_11_0(slot_0_3_0.get_multi_text_size(arg_254_0, var_254_1.font, var_254_1.icon_font), slot_0_3_0.text_size(arg_254_0[1][1] or "", var_254_1.font).y) or slot_0_3_0.text_size("undefined", var_254_1.font) + (var_254_1.style.icon and var_254_1.style.icon.size.x or 0)
					var_254_1.text_widths = slot_0_3_0.get_multi_text_size_array(arg_254_0, var_254_1.font, var_254_1.icon_font, true)
					var_254_1.width = var_254_1.text_size.x + slot_217_5_0 * 2
					var_254_1.height = var_254_1.text_size.y + slot_217_5_0 * 2

					return
				end
			end
		end

		if not arg_254_2 and arg_254_3 then
			local var_254_2 = slot_217_8_0[arg_254_3] or {}

			arg_254_2 = slot_0_3_0.make_notify_style(var_254_2.icon or "", var_254_2.color or slot_0_6_0.white_color, "fast_blur", true)
		end

		if not var_254_0 then
			arg_254_2 = arg_254_2 or {}

			local var_254_3 = arg_254_1.font or slot_0_18_0.verdana
			local var_254_4 = arg_254_1.icon_font or slot_0_18_0.icon_default

			if arg_254_2.icon then
				local var_254_5 = arg_254_2.icon.font or slot_0_18_0.icons.mercury

				arg_254_2.icon.size = slot_0_3_0.text_size(arg_254_2.icon.text, var_254_5)
			end

			notify_cache[#notify_cache + 1] = {
				alpha = 0,
				h_offset = 0,
				text = arg_254_0,
				id = arg_254_1.id or -1,
				font = var_254_3,
				icon_font = var_254_4,
				text_size = slot_0_11_0(slot_0_3_0.get_multi_text_size(arg_254_0, var_254_3, var_254_4), slot_0_3_0.text_size(arg_254_0[1][1] or "", var_254_3).y) or slot_0_3_0.text_size("undefined", var_254_3) + (arg_254_2.icon and arg_254_2.icon.size.x or 0),
				text_widths = slot_0_3_0.get_multi_text_size_array(arg_254_0, var_254_3, var_254_4, true),
				style = arg_254_2,
				time = slot_0_6_0.real_time + (arg_254_1.bonus_time or 0)
			}

			local var_254_6 = notify_cache[#notify_cache]

			var_254_6.width = var_254_6.text_size.x + slot_217_5_0 * 2
			var_254_6.height = var_254_6.text_size.y + slot_217_5_0 * 2
		end
	end

	function slot_0_3_0.notify_handler()
		slot_255_0_0 = #notify_cache

		if slot_255_0_0 == 0 then
			return
		end

		slot_255_1_0 = draw.surface
		slot_255_1_0.g.anti_alias = true
		slot_255_2_0 = -1
		slot_255_3_0 = draw.Vec2(10, 10)
		slot_255_4_0 = draw.Vec2(0, 0)
		slot_255_5_0 = draw.Vec2(0, 0)
		slot_255_6_0 = draw.Vec2(0, 0)
		slot_255_7_0 = draw.adapter:get_back_buffer_downsampled()

		for iter_255_0 = 1, slot_255_0_0 do
			slot_255_12_0 = notify_cache[iter_255_0]
			slot_255_13_0 = slot_255_12_0.style

			if not slot_255_12_0.icon_font then
				slot_255_14_0 = slot_0_18_0.icons.mercury
			end

			slot_255_15_0 = slot_255_12_0.time + 3 > slot_0_6_0.real_time

			if slot_255_0_0 - iter_255_0 > 3 then
				slot_255_12_0.time = slot_255_12_0.time - slot_0_6_0.frame_time * 2.5
			end

			slot_255_16_0 = slot_255_12_0.text_size
			slot_255_12_0.pos = slot_255_12_0.pos or draw.Vec2(-slot_255_3_0.x - slot_255_16_0.x - slot_217_5_0, slot_255_3_0.y + slot_217_6_0)
			slot_255_12_0.pos.x = math.bounded_lerp(slot_255_12_0.pos.x, slot_255_3_0.x - slot_255_16_0.x * 1.5 - slot_217_5_0, slot_255_3_0.x, 4, slot_255_15_0)
			slot_255_12_0.pos.y = math.lerp(slot_255_12_0.pos.y, slot_255_3_0.y + slot_217_6_0, slot_0_6_0.frame_time * 6)

			slot_255_4_0:set(slot_255_12_0.pos.x, slot_255_12_0.pos.y)
			slot_255_5_0:set(slot_255_12_0.pos.x + slot_255_12_0.width, slot_255_12_0.pos.y + slot_255_12_0.height + slot_255_12_0.h_offset)

			if slot_255_13_0.icon then
				slot_255_5_0.x = slot_255_5_0.x + slot_217_5_0 + slot_217_6_0 + slot_255_13_0.icon.size.x
			end

			if slot_255_13_0.shader then
				if slot_255_13_0.shader_screen then
					slot_255_6_0:set(slot_0_6_0.screen_size.x, slot_0_6_0.screen_size.y)

					slot_255_17_2 = slot_0_6_0.screen_size.x
					slot_255_18_2 = slot_0_6_0.screen_size.y
					slot_255_1_0.g.uv_rect = draw.rect(slot_255_4_0.x / slot_255_17_2, slot_255_4_0.y / slot_255_18_2, slot_255_5_0.x / slot_255_17_2, slot_255_5_0.y / slot_255_18_2)
				else
					slot_255_6_0:set(slot_255_12_0.width, slot_255_12_0.width)
				end

				slot_255_17_1 = slot_0_3_0.get_shader(slot_255_13_0.shader)

				slot_255_1_0.g:set_shader(slot_255_17_1)

				slot_255_1_0.g.texture = slot_255_7_0
				slot_255_1_0.tex_sz = slot_255_6_0

				slot_255_1_0:add_rect_filled_rounded(draw.rect(slot_255_4_0.x, slot_255_4_0.y, slot_255_5_0.x, slot_255_5_0.y), (slot_255_13_0.shader_color or slot_0_6_0.white_color):self_a(slot_255_12_0.alpha), slot_255_13_0.round)
				slot_255_1_0.g:set_shader(nil)
				slot_255_1_0.g:set_texture(nil)
			end

			if slot_255_13_0.background then
				slot_255_1_0:add_rect_filled_rounded(draw.rect(slot_255_4_0.x, slot_255_4_0.y, slot_255_5_0.x, slot_255_5_0.y), slot_255_13_0.background or slot_0_6_0.white_color, slot_255_13_0.round)
			end

			if slot_255_13_0.outline then
				slot_255_1_0:add_rect_rounded(draw.rect(slot_255_4_0.x, slot_255_4_0.y, slot_255_5_0.x, slot_255_5_0.y), slot_255_13_0.outline or slot_0_6_0.white_color, slot_255_13_0.round, nil, 1, draw.outline_mode.outset)
			end

			slot_255_17_0 = 0

			if slot_255_13_0.icon then
				slot_255_18_1 = slot_255_13_0.icon
				slot_255_1_0.font = slot_255_18_1.font or slot_0_18_0.icons.mercury

				slot_255_1_0:add_text(slot_217_2_0:set(slot_255_12_0.pos.x + slot_217_5_0, slot_255_12_0.pos.y + slot_217_5_0 + (slot_255_18_1.add_y or 0) + 3 + slot_255_12_0.h_offset / 2), slot_255_18_1.text, slot_255_18_1.color or slot_0_6_0.white_color)

				slot_255_17_0 = slot_217_5_0 + slot_217_6_0 + slot_255_18_1.size.x
				slot_255_19_0 = draw.rect(slot_255_4_0.x + slot_255_17_0, slot_255_4_0.y + slot_217_7_0, slot_255_4_0.x + slot_255_17_0 + 1, slot_255_5_0.y - slot_217_7_0)

				slot_255_1_0:add_rect_filled(slot_255_19_0, slot_255_18_1.color or slot_255_18_1.split_color or slot_0_6_0.white_color)
			end

			slot_255_1_0.font = slot_255_12_0.font or slot_0_18_0.verdana
			slot_255_18_0 = false

			for iter_255_1 = 1, #slot_255_12_0.text do
				slot_255_23_1 = slot_255_12_0.text[iter_255_1]
				slot_255_24_0 = slot_255_12_0.text_widths[iter_255_1]

				if slot_255_23_1.icon_font then
					slot_255_1_0.font = slot_255_23_1.icon_font
					slot_255_18_0 = true
				elseif slot_255_18_0 then
					slot_255_18_0 = false
					slot_255_1_0.font = slot_255_12_0.font or slot_0_18_0.verdana
				end

				slot_255_1_0:add_text(slot_217_2_0:set(slot_255_4_0.x + slot_255_24_0 + slot_255_17_0 + slot_217_5_0, slot_255_12_0.pos.y + 2 + slot_217_5_0 + (slot_255_23_1.add_y or 0)), slot_255_23_1[1] or "", slot_255_23_1[2] or slot_0_6_0.white_color)
			end

			if slot_255_12_0.text.lines then
				slot_255_12_0.h_offset = 1
				slot_255_1_0.font = slot_255_12_0.font or slot_0_18_0.verdana

				for iter_255_2 = 1, #slot_255_12_0.text.lines do
					slot_255_23_0 = slot_255_12_0.text.lines[iter_255_2]
					slot_255_12_0.h_offset = slot_255_12_0.h_offset + slot_255_16_0.y + 2

					slot_255_1_0:add_text(slot_217_2_0:set(slot_255_12_0.pos.x + slot_255_17_0 + slot_217_5_0, slot_255_12_0.pos.y + slot_255_16_0.y + slot_255_12_0.h_offset), slot_255_23_0 or "", slot_0_6_0.white_color)
				end
			end

			slot_255_12_0.alpha = math.bounded_lerp(slot_255_12_0.alpha, 0, 1, 3, slot_255_15_0)

			if slot_255_12_0.alpha <= 0.05 and not slot_255_15_0 then
				slot_255_2_0 = iter_255_0
			end

			slot_255_3_0.y = slot_255_3_0.y + slot_255_16_0.y + slot_217_5_0 + slot_217_6_0 * 2 + slot_255_12_0.h_offset
		end

		if slot_255_2_0 ~= -1 then
			table.remove(notify_cache, slot_255_2_0)
		end
	end

	function slot_0_3_0.circle_filled(arg_256_0, arg_256_1, arg_256_2, arg_256_3)
		local var_256_0 = draw.surface

		if arg_256_3 then
			local var_256_1 = 4

			for iter_256_0 = 1, var_256_1 do
				var_256_0:add_circle_filled(arg_256_0, arg_256_1 + iter_256_0 * 2, arg_256_3:a((1 - iter_256_0 / var_256_1)^1.5 * arg_256_3:get_a() / 255))
			end
		end

		var_256_0:add_circle_filled(arg_256_0, arg_256_1, arg_256_2)
	end

	function slot_0_3_0.pos_2d(arg_257_0, arg_257_1)
		arg_257_1 = arg_257_1 or slot_0_12_0()

		if arg_257_0.x then
			arg_257_0 = slot_0_11_0(arg_257_0.x, arg_257_0.y, arg_257_0.z)

			local var_257_0 = math.world_to_screen(arg_257_0)

			if slot_0_3_0.on_screen(var_257_0) then
				draw.surface:add_circle_filled(var_257_0, 6, arg_257_1)
			end
		end
	end

	function slot_0_3_0.arrow(arg_258_0, arg_258_1, arg_258_2, arg_258_3, arg_258_4)
		local var_258_0 = draw.surface

		arg_258_2 = arg_258_2 or 16
		arg_258_3 = arg_258_3 or 6
		arg_258_4 = arg_258_4 or 4

		var_258_0:add_triangle_filled(slot_0_11_0(arg_258_0.x + arg_258_2, arg_258_0.y), slot_0_11_0(arg_258_0.x - arg_258_4, arg_258_0.y + arg_258_3), slot_0_11_0(arg_258_0.x, arg_258_0.y), arg_258_1)
		var_258_0:add_triangle_filled(slot_0_11_0(arg_258_0.x + arg_258_2, arg_258_0.y), slot_0_11_0(arg_258_0.x, arg_258_0.y), slot_0_11_0(arg_258_0.x - arg_258_4, arg_258_0.y - arg_258_3), arg_258_1)
	end

	function slot_0_3_0.circle_3d(arg_259_0, arg_259_1, arg_259_2, arg_259_3, arg_259_4, arg_259_5, arg_259_6, arg_259_7)
		local var_259_0 = draw.surface
		local var_259_1

		arg_259_4 = arg_259_4 or 2
		arg_259_2 = arg_259_2 or 10

		local var_259_2 = 2 * math.pi
		local var_259_3 = var_259_2 / arg_259_2
		local var_259_4 = 0

		for iter_259_0 = 0, arg_259_2 do
			local var_259_5 = iter_259_0 * var_259_3
			local var_259_6 = math.world_to_screen(slot_0_11_0(arg_259_0.x + math.cos(var_259_5) * arg_259_1, arg_259_0.y + math.sin(var_259_5) * arg_259_1, arg_259_0.z))

			if slot_0_3_0.on_screen(var_259_6) then
				if var_259_1 then
					local var_259_7 = arg_259_3

					if arg_259_6 == 1 then
						var_259_7 = arg_259_3:hsv((iter_259_0 / arg_259_2 + slot_0_6_0.real_time * 0.4) * 360 % 360, 0.5, 1)
					elseif arg_259_6 == 2 then
						local var_259_8 = slot_0_6_0.real_time * 2 % var_259_2
						local var_259_9 = iter_259_0 / arg_259_2 * var_259_2

						var_259_7 = math.lerp_color(arg_259_3, arg_259_5, 0.5 + 0.5 * math.sin(var_259_8 + var_259_9))
					end

					if arg_259_7 then
						slot_0_3_0.line_glow(var_259_0, var_259_1, var_259_6, var_259_7:a(var_259_7:get_a() / 255 * 0.43), nil, arg_259_4)
					end

					slot_0_3_0.line(var_259_0, var_259_1, var_259_6, var_259_7, nil, arg_259_4)
				end

				var_259_1 = var_259_6
			end
		end
	end

	function slot_0_3_0.circle_3d_filled(arg_260_0, arg_260_1, arg_260_2, arg_260_3)
		if not arg_260_0 then
			return
		end

		local var_260_0 = math.world_to_screen(arg_260_0)

		if not slot_0_3_0.on_screen(var_260_0) then
			return
		end

		local var_260_1 = draw.surface
		local var_260_2 = 2 * math.pi / arg_260_2
		local var_260_3 = 0
		local var_260_4 = {
			var_260_0
		}

		for iter_260_0 = 0, arg_260_2 do
			local var_260_5 = arg_260_2 * var_260_2 - iter_260_0 * var_260_2
			local var_260_6 = math.world_to_screen(slot_0_11_0(arg_260_0.x + math.cos(var_260_5) * arg_260_1, arg_260_0.y + math.sin(var_260_5) * arg_260_1, arg_260_0.z))

			if var_260_6 then
				var_260_4[#var_260_4 + 1] = var_260_6
			end
		end

		if #var_260_4 > 2 then
			slot_0_3_0.polygon(arg_260_3, true, unpack(var_260_4))
		end
	end

	function slot_0_3_0.china_hat(arg_261_0, arg_261_1, arg_261_2, arg_261_3, arg_261_4, arg_261_5, arg_261_6, arg_261_7)
		if arg_261_4:get_a() < 0.02 then
			return
		end

		local var_261_0 = math.world_to_screen(slot_0_11_0(arg_261_0.x, arg_261_0.y, arg_261_0.z + arg_261_3))

		if not slot_0_3_0.on_screen(var_261_0) then
			return
		end

		local var_261_1 = draw.surface
		local var_261_2
		local var_261_3 = 2 * math.pi
		local var_261_4 = var_261_3 / arg_261_2
		local var_261_5 = 0

		for iter_261_0 = 0, arg_261_2 do
			local var_261_6 = iter_261_0 * var_261_4
			local var_261_7 = math.world_to_screen(slot_0_11_0(arg_261_0.x + math.cos(var_261_6) * arg_261_1, arg_261_0.y + math.sin(var_261_6) * arg_261_1, arg_261_0.z))

			if slot_0_3_0.on_screen(var_261_7) then
				if var_261_2 then
					local var_261_8 = arg_261_4

					if arg_261_7 == 1 then
						var_261_8 = arg_261_4:hsv((iter_261_0 / arg_261_2 + slot_0_6_0.real_time * 0.4) * 360 % 360, 0.5, 1)
					elseif arg_261_7 == 2 then
						local var_261_9 = slot_0_6_0.real_time * 2 % var_261_3
						local var_261_10 = iter_261_0 / arg_261_2 * var_261_3

						var_261_8 = math.lerp_color(arg_261_4, arg_261_5, 0.5 + 0.5 * math.sin(var_261_9 + var_261_10))
					end

					var_261_1:add_triangle_filled(var_261_2, var_261_0, var_261_7, var_261_8)

					if arg_261_6 then
						slot_0_3_0.line(var_261_1, var_261_2, var_261_7, var_261_8, nil, 2)
					end
				end

				var_261_2 = var_261_7
			end
		end
	end

	slot_217_12_0 = {
		{
			0,
			1,
			1,
			0,
			1,
			1,
			0
		},
		{
			1,
			1,
			1,
			1,
			1,
			1,
			1
		},
		{
			1,
			1,
			1,
			1,
			1,
			1,
			1
		},
		{
			1,
			1,
			1,
			1,
			1,
			1,
			1
		},
		{
			0,
			1,
			1,
			1,
			1,
			1,
			0
		},
		{
			0,
			0,
			1,
			1,
			1,
			0,
			0
		},
		{
			0,
			0,
			0,
			1,
			0,
			0,
			0
		}
	}

	function slot_0_3_0.pixel_heart(arg_262_0, arg_262_1, arg_262_2)
		local var_262_0 = arg_262_0.x
		local var_262_1 = arg_262_0.y
		local var_262_2 = arg_262_1

		arg_262_2 = arg_262_2 or slot_0_12_0(255, 0, 0, 255)

		for iter_262_0, iter_262_1 in ipairs(slot_217_12_0) do
			for iter_262_2, iter_262_3 in ipairs(iter_262_1) do
				if iter_262_3 == 1 then
					local var_262_3 = var_262_0 + (iter_262_2 - 1) * var_262_2
					local var_262_4 = var_262_1 + (iter_262_0 - 1) * var_262_2

					slot_0_3_0.rect(slot_0_11_0(var_262_3, var_262_4), slot_0_11_0(var_262_3 + var_262_2, var_262_4 + var_262_2), arg_262_2, 0)
				end
			end
		end
	end

	return slot_0_3_0
end)()
slot_0_26_0 = (function()
	local var_263_0 = {
		alpha = 0,
		pulse = 0,
		dragged_name = "none",
		dragged = false,
		menu_alpha = 0,
		list = {}
	}

	function var_263_0.create(arg_264_0, arg_264_1, arg_264_2)
		var_263_0.list[arg_264_0] = {
			x = gui.slider(gui.control_id(string.format("MercuryDragX:%s", arg_264_0)), 0, slot_0_6_0.screen_size.x, {
				"%.0f"
			}),
			y = gui.slider(gui.control_id(string.format("MercuryDragY:%s", arg_264_0)), 0, slot_0_6_0.screen_size.y, {
				"%.0f"
			}),
			i = {
				0,
				0,
				0,
				0
			},
			title = arg_264_2
		}

		local var_264_0 = var_263_0.list[arg_264_0].x:get_value():get()
		local var_264_1 = var_263_0.list[arg_264_0].y:get_value():get()

		if arg_264_1 and (var_264_0 < -20 or var_264_1 < -20) then
			var_263_0.list[arg_264_0].x:get_value():set(arg_264_1.x)
			var_263_0.list[arg_264_0].y:get_value():set(arg_264_1.y)
		elseif arg_264_1 and var_264_0 == 0 and var_264_1 == 0 then
			var_263_0.list[arg_264_0].x:get_value():set(arg_264_1.x)
			var_263_0.list[arg_264_0].y:get_value():set(arg_264_1.y)
		elseif arg_264_1 and var_264_0 > slot_0_6_0.screen_size.x or var_264_1 > slot_0_6_0.screen_size.y then
			var_263_0.list[arg_264_0].x:get_value():set(arg_264_1.x)
			var_263_0.list[arg_264_0].y:get_value():set(arg_264_1.y)
		end
	end

	function var_263_0.get(arg_265_0)
		local var_265_0 = var_263_0.list[arg_265_0]

		return var_265_0 and slot_0_11_0(var_265_0.x:get_value():get(), var_265_0.y:get_value():get()) or slot_0_11_0(10, 10)
	end

	function var_263_0.move(arg_266_0, arg_266_1, arg_266_2, arg_266_3, arg_266_4)
		if not slot_0_6_0.menu_visible and not (var_263_0.menu_alpha > 0) then
			return
		end

		if not slot_0_24_0.window_is_active() then
			return
		end

		slot_266_5_0 = var_263_0.list[arg_266_0]

		if not slot_266_5_0 then
			return
		end

		arg_266_3 = arg_266_3 or slot_0_11_0(0, 0)
		arg_266_4 = arg_266_4 or 0
		slot_266_6_0 = slot_266_5_0.x:get_value()
		slot_266_7_0 = slot_266_5_0.y:get_value()
		slot_266_8_0 = slot_266_6_0:get() + arg_266_3.x - arg_266_4
		slot_266_9_0 = slot_266_7_0:get() + arg_266_3.y - arg_266_4
		slot_266_10_0 = arg_266_1 + arg_266_4 * 2
		slot_266_11_0 = arg_266_2 + arg_266_4 * 2
		slot_266_12_0 = slot_0_24_0.cursor_pos()
		slot_266_13_0 = slot_0_24_0.key_click(1)

		if slot_266_8_0 <= slot_266_12_0.x and slot_266_12_0.x <= slot_266_8_0 + slot_266_10_0 and slot_266_9_0 <= slot_266_12_0.y and slot_266_12_0.y <= slot_266_9_0 + slot_266_11_0 then
			if slot_266_13_0 and not var_263_0.dragged then
				slot_266_5_0.i[4] = 1
			end

			if slot_0_24_0.key_pressed(1) and slot_266_5_0.i[1] == 0 then
				slot_266_5_0.i[1] = 1
				slot_266_5_0.i[2] = slot_266_8_0 - slot_266_12_0.x + arg_266_4
				slot_266_5_0.i[3] = slot_266_9_0 - slot_266_12_0.y + arg_266_4
			end
		end

		if not slot_0_24_0.key_pressed(1) then
			slot_266_5_0.i[1] = 0
			slot_266_5_0.i[4] = 0
		end

		if slot_266_5_0.i[1] == 1 and slot_266_5_0.i[4] == 1 then
			var_263_0.dragged = true
			var_263_0.dragged_name = arg_266_0

			slot_266_6_0:set(slot_266_12_0.x + slot_266_5_0.i[2] - arg_266_3.x)
			slot_266_7_0:set(slot_266_12_0.y + slot_266_5_0.i[3] - arg_266_3.y)

			slot_266_14_1 = slot_266_6_0:get()
			slot_266_15_0 = slot_266_7_0:get()
			slot_266_16_0 = (arg_266_3.x == 0 and 1 or -1) * slot_266_10_0 / 2 - (arg_266_3.x == 0 and 1 or -1) * arg_266_4

			if math.abs(slot_0_6_0.screen_size.x / 2 - slot_266_14_1 + arg_266_3.x - slot_266_16_0) < 10 then
				slot_266_6_0:set(slot_0_6_0.screen_size.x / 2 + arg_266_3.x - slot_266_16_0)
			end

			if math.abs(slot_0_6_0.screen_size.y / 2 - slot_266_15_0 + arg_266_3.y - slot_266_11_0 / 2 + arg_266_4) < 10 then
				slot_266_7_0:set(slot_0_6_0.screen_size.y / 2 - arg_266_3.y - slot_266_11_0 / 2 + arg_266_4)
			end
		end

		slot_266_14_0 = 125 * (var_263_0.dragged_name == arg_266_0 and var_263_0.alpha or 0) + 120 * var_263_0.pulse

		if slot_266_14_0 > 0 then
			if slot_266_5_0.title then
				slot_0_3_0.text_outline(slot_266_5_0.title, slot_0_18_0.alata_main, slot_0_11_0(slot_266_8_0 + slot_266_10_0 / 2 - slot_0_3_0.text_size(slot_266_5_0.title, slot_0_18_0.alata_main).x / 2, slot_266_9_0 - slot_0_18_0.offset.alata_main - 6), slot_0_12_0(255, var_263_0.menu_alpha * 100 + 120 * var_263_0.pulse))
			end

			slot_0_3_0.rect(slot_0_11_0(slot_266_8_0, slot_266_9_0), slot_0_11_0(slot_266_8_0 + slot_266_10_0, slot_266_9_0 + slot_266_11_0), slot_0_12_0(255, slot_266_14_0), 3, true)
		end
	end

	function var_263_0.visual_handler(arg_267_0)
		arg_267_0 = arg_267_0 or var_263_0
		arg_267_0.alpha = math.bounded_lerp(arg_267_0.alpha, 0, 1, 4, arg_267_0.dragged)
		arg_267_0.pulse = math.abs(math.cos(slot_0_6_0.real_time)) * arg_267_0.menu_alpha
		arg_267_0.menu_alpha = math.bounded_lerp(arg_267_0.menu_alpha, 0, 1, 4, slot_0_6_0.menu_visible and slot_0_24_0.window_is_active() and not slot_0_13_0.misc.global:get("Hide draggable zone"))

		if arg_267_0.alpha > 0 then
			local var_267_0 = slot_0_6_0.screen_size

			slot_0_3_0.line(nil, slot_0_11_0(var_267_0.x / 2, var_267_0.y / 2 - var_267_0.y / 2 * arg_267_0.alpha), slot_0_11_0(var_267_0.x / 2, var_267_0.y / 2 + var_267_0.y / 2 * arg_267_0.alpha), slot_0_12_0(255, 200 * arg_267_0.alpha))
			slot_0_3_0.line(nil, slot_0_11_0(var_267_0.x / 2 - var_267_0.x / 2 * arg_267_0.alpha, var_267_0.y / 2), slot_0_11_0(var_267_0.x / 2 + var_267_0.x / 2 * arg_267_0.alpha, var_267_0.y / 2), slot_0_12_0(255, 200 * arg_267_0.alpha))
		end

		if arg_267_0.dragged then
			arg_267_0.dragged = false
		end
	end

	return var_263_0
end)()

function slot_0_27_0()
	local var_268_0 = engine or {}

	ffi.cdef("  \n        typedef struct\n        {\n            char pad[0x2C];\n        } Ray_t;\n    \n        typedef struct\n        {\n            void* m_pSurface;\n            void* m_pHitEntity;\n            void* m_pHitboxData;\n            char pad[0x38];\n            uint32_t m_uContents;\n            char pad2[0x24];\n            Vector m_vecStartPos;\n            Vector m_vecEndPos;\n            Vector m_vecNormal;\n            Vector m_vecPosition;\n            char pad3[0x4];\n            float m_flFraction;\n            char pad4[0x6];\n            bool m_bAllSolid;\n            char pad5[0x4D];\n        } GameTrace_t;\n    \n        typedef struct\n        {\n            char pad[0x8];\n            int64_t m_uTraceMask;\n            int64_t m_v1[2];\n            int32_t m_arrSkipHandles[4];\n            int16_t m_arrCollisions[2];\n            int16_t m_v2;\n            uint8_t m_v3;\n            uint8_t m_v4;\n            uint8_t m_v5;\n    \n        } TraceFilter_t;\n    \n    ")

	local function var_268_1(arg_269_0, arg_269_1, arg_269_2)
		return ffi.cast(arg_269_0, arg_269_1 + ffi.cast("uint32_t*", arg_269_1 + arg_269_2)[0] + arg_269_2 + 4)
	end

	local var_268_2 = {
		init = function(arg_270_0)
			do return false end

			local var_270_0 = utils.find_pattern("client.dll", slot_0_16_0.TraceManager)
			local var_270_1 = utils.find_pattern("client.dll", slot_0_16_0.TraceShape)
			local var_270_2 = utils.find_pattern("client.dll", slot_0_16_0.TraceFilter)

			if not var_270_0 or var_270_0 == 0 then
				return false
			end

			if not var_270_1 or var_270_1 == 0 then
				return false
			end

			if not var_270_2 or var_270_2 == 0 then
				return false
			end

			arg_270_0.trace_manager = var_268_1("void**", var_270_0, 5)[0]
			arg_270_0.trace_shape_fn = ffi.cast("bool(__fastcall*)(void*, Ray_t*, Vector*, Vector*, TraceFilter_t*, GameTrace_t*)", var_270_1)
			arg_270_0.trace_filter_init_fn = var_268_1("void*(__fastcall*)(void* this, void* skip, uintptr_t mask, int layer, int16_t)", var_270_2, 1)

			return true
		end,
		ray = ffi.new("Ray_t[1]"),
		filter = ffi.new("TraceFilter_t[1]"),
		game_trace = ffi.new("GameTrace_t[1]"),
		start_vec = ffi.new("Vector[1]"),
		end_vec = ffi.new("Vector[1]")
	}

	function var_268_0.trace_line(arg_271_0, arg_271_1, arg_271_2)
		if not var_268_2.trace_manager then
			return 0
		end

		if not var_268_2.trace_shape_fn then
			return 0
		end

		for iter_271_0 = 0, 43 do
			var_268_2.ray[0].pad[iter_271_0] = 0
		end

		var_268_2.start_vec[0].x = arg_271_0.x
		var_268_2.start_vec[0].y = arg_271_0.y
		var_268_2.start_vec[0].z = arg_271_0.z
		var_268_2.end_vec[0].x = arg_271_1.x
		var_268_2.end_vec[0].y = arg_271_1.y
		var_268_2.end_vec[0].z = arg_271_1.z

		var_268_2.trace_filter_init_fn(var_268_2.filter, arg_271_2 and ffi.cast("void**", arg_271_2)[0] or null, 1060873, 5, 7)

		local var_271_0 = var_268_2.trace_shape_fn(var_268_2.trace_manager, var_268_2.ray, var_268_2.start_vec, var_268_2.end_vec, var_268_2.filter, var_268_2.game_trace)

		return {
			end_pos = slot_0_11_0(var_268_2.game_trace[0].m_vecEndPos.x, var_268_2.game_trace[0].m_vecEndPos.y, var_268_2.game_trace[0].m_vecEndPos.z),
			fraction = var_268_2.game_trace[0].m_flFraction
		}
	end

	if not var_268_2:init() then
		print("[Mercury:Error] Trace line lib")

		function var_268_0.trace_line(arg_272_0, arg_272_1)
			local var_272_0 = ray_t()
			local var_272_1 = game.physics_query_interface:trace_ray(var_272_0, arg_272_0, arg_272_1)

			if not var_272_1 then
				return
			end

			return {
				end_pos = var_272_1.endpos,
				fraction = var_272_1.fraction
			}
		end
	end

	return var_268_0
end

slot_0_28_0 = (function()
	return {
		get_condition = function(arg_274_0)
			if not arg_274_0 or not arg_274_0:is_alive() then
				return "dead"
			end

			local var_274_0 = arg_274_0.m_fFlags:get() % 10
			local var_274_1 = arg_274_0.m_bIsWalking:get()
			local var_274_2 = arg_274_0:get_abs_velocity()
			local var_274_3

			var_274_3 = var_274_2 and var_274_2:length() or 0

			if var_274_0 == 5 and var_274_1 then
				return "walk"
			elseif var_274_0 == 4 then
				return "air"
			elseif var_274_0 == 6 then
				return "crouch_air"
			elseif var_274_0 == 7 then
				return "crouch"
			elseif var_274_3 > 5 then
				return "run"
			end

			return "stand"
		end,
		get_weapon_name = function(arg_275_0)
			if not arg_275_0 then
				return false
			end

			local var_275_0 = arg_275_0:get_active_weapon()

			if not var_275_0 then
				return false
			end

			local var_275_1 = var_275_0:get_id()

			return slot_0_6_0.weapon_by_index[var_275_1] or "undefined"
		end,
		get_weapon_group = function(arg_276_0)
			if not arg_276_0 then
				return false
			end

			local var_276_0 = arg_276_0:get_active_weapon()

			if not var_276_0 then
				return false
			end

			local var_276_1 = var_276_0:get_id()

			return slot_0_6_0.weapon_group_by_index[var_276_1] or "undefined"
		end,
		get_hitbox_pos = function(arg_277_0, arg_277_1)
			if not arg_277_0 then
				return
			end

			arg_277_1 = arg_277_1 or 6

			local var_277_0 = ffi.cast("uintptr_t*", arg_277_0)[0]
			local var_277_1 = ffi.cast("uintptr_t*", ffi.cast("uintptr_t", var_277_0 + slot_0_16_0.m_pGameSceneNode))[0]
			local var_277_2 = ffi.cast("uintptr_t*", ffi.cast("uintptr_t", var_277_1) + (slot_0_16_0.m_modelState + 128))[0]
			local var_277_3 = ffi.cast("struct Vector_xyz*", ffi.cast("uintptr_t", var_277_2) + arg_277_1 * 32)[0]

			return slot_0_11_0(var_277_3.x, var_277_3.y, var_277_3.z)
		end,
		on_ladder = function(arg_278_0)
			if not arg_278_0 then
				return
			end

			local var_278_0 = ffi.cast("uintptr_t*", arg_278_0)[0]
			local var_278_1 = ffi.cast("uintptr_t*", ffi.cast("uintptr_t", var_278_0 + slot_0_16_0.m_nActualMoveType))[0]

			return tonumber(var_278_1) == 9
		end,
		get_steam_id = function(arg_279_0)
			if not arg_279_0 then
				return
			end

			local var_279_0 = ffi.cast("uintptr_t*", arg_279_0)[0]

			return ffi.cast("uint64_t*", ffi.cast("uintptr_t", var_279_0 + slot_0_16_0.m_steamID))[0]
		end,
		get_move_type = function(arg_280_0)
			if not arg_280_0 then
				return -1
			end

			local var_280_0 = arg_280_0.m_nActualMoveType

			if not var_280_0 then
				return -1
			end

			local var_280_1 = ffi.cast("uintptr_t*", var_280_0)[0]
			local var_280_2 = ffi.cast("uint8_t*", ffi.cast("uintptr_t", var_280_1))[0]
			local var_280_3 = ffi.cast("uintptr_t*", arg_280_0)[0]
			local var_280_4 = ffi.cast("uint8_t*", ffi.cast("uintptr_t", var_280_3 + slot_0_16_0.m_nActualMoveType))[0]
		end,
		get_health = function(arg_281_0)
			if not arg_281_0 or not arg_281_0:is_alive() or not arg_281_0.m_iHealth then
				return -1
			end

			return arg_281_0.m_iHealth:get() or -1
		end,
		get_armor = function(arg_282_0)
			if not arg_282_0 or not arg_282_0:is_alive() or not arg_282_0.m_ArmorValue then
				return -1
			end

			return arg_282_0.m_ArmorValue:get() or -1
		end,
		get_next_primary_attack = function(arg_283_0)
			if not arg_283_0 then
				return false
			end

			local var_283_0 = arg_283_0:get_active_weapon()

			if not var_283_0 then
				return false
			end

			local var_283_1 = ffi.cast("uintptr_t*", var_283_0)

			if var_283_1 == nil or ffi.cast("uintptr_t", var_283_1) == 0 then
				return 0
			end

			local var_283_2 = var_283_1[0]

			if var_283_2 == 0 then
				return 0
			end

			local var_283_3 = ffi.cast("int*", ffi.cast("uintptr_t", var_283_2 + slot_0_16_0.m_nNextPrimaryAttackTick))[0]

			return tonumber(var_283_3) - slot_0_6_0.tick_count < 0
		end
	}
end)()

function slot_0_14_0.register(arg_284_0, arg_284_1, arg_284_2, arg_284_3)
	if type(arg_284_2) ~= "function" then
		print("player_info failed: " .. tostring(arg_284_1))

		return false
	end

	arg_284_0.funcs[arg_284_1] = arg_284_2
	arg_284_0.delays[arg_284_1] = arg_284_3 or 0
	arg_284_0.update_times[arg_284_1] = 0
	arg_284_0.cache[arg_284_1] = nil

	return true
end

function slot_0_14_0.get(arg_285_0, arg_285_1, ...)
	local var_285_0 = game.global_vars.tick_count

	if math.abs(var_285_0 - (arg_285_0.update_times[arg_285_1] or 0)) > arg_285_0.delays[arg_285_1] or arg_285_0.cache[arg_285_1] == nil then
		arg_285_0.update_times[arg_285_1] = var_285_0
		arg_285_0.cache[arg_285_1] = arg_285_0.funcs[arg_285_1](...)
	end

	return arg_285_0.cache[arg_285_1]
end

function slot_0_14_0.set_delay(arg_286_0, arg_286_1, arg_286_2)
	if arg_286_0.funcs[arg_286_1] then
		arg_286_0.delays[arg_286_1] = arg_286_2 or 0

		return true
	end

	return false
end

slot_0_14_0:register("get_weapon_name", function(arg_287_0)
	arg_287_0 = arg_287_0 or entities.get_local_pawn()

	if not arg_287_0 then
		return false
	end

	return slot_0_28_0.get_weapon_name(arg_287_0)
end)
slot_0_14_0:register("get_condition", function(arg_288_0)
	arg_288_0 = arg_288_0 or entities.get_local_pawn()

	if not arg_288_0 then
		return
	end

	return slot_0_28_0.get_condition(arg_288_0)
end, 5.5)
slot_0_14_0:register("get_origin", function(arg_289_0)
	arg_289_0 = arg_289_0 or entities.get_local_pawn()

	if not arg_289_0 then
		return
	end

	return arg_289_0:get_abs_origin()
end, 4)
slot_0_14_0:register("get_eye_pos", function(arg_290_0)
	arg_290_0 = arg_290_0 or entities.get_local_pawn()

	if not arg_290_0 then
		return
	end

	return arg_290_0:get_eye_pos()
end, 6)
slot_0_14_0:register("get_weapon_id", function(arg_291_0)
	arg_291_0 = arg_291_0 or entities.get_local_pawn()

	if not arg_291_0 then
		return false
	end

	local var_291_0 = arg_291_0:get_active_weapon()

	if not var_291_0 then
		return false
	end

	return (var_291_0:get_id())
end, 12)
slot_0_14_0:register("get_weapon_group", function()
	local var_292_0 = slot_0_14_0:get("get_weapon_id")

	if not var_292_0 then
		return false
	end

	return slot_0_6_0.weapon_group_by_index[var_292_0]
end, 11)
slot_0_14_0:register("get_target", function(arg_293_0)
	arg_293_0 = arg_293_0 or entities.get_local_pawn()

	if not arg_293_0 or not arg_293_0:is_alive() then
		return false
	end

	local var_293_0 = game.input:get_view_angles()
	local var_293_1 = slot_0_14_0:get("get_eye_pos")
	local var_293_2 = slot_0_14_0.target or {}
	local var_293_3 = 99999

	var_293_2.is_valid = false

	entities.players:for_each(function(arg_294_0)
		local var_294_0 = arg_294_0.entity

		if var_294_0 and var_294_0:is_alive() and var_294_0:is_enemy() then
			local var_294_1 = var_294_0:get_abs_origin()

			var_294_1.z = var_294_1.z + 30

			local var_294_2 = math.calc_angle(var_293_1, var_294_1)
			local var_294_3 = math.calc_dist(var_293_0, var_294_2)

			if var_294_3 < var_293_3 then
				var_293_3 = var_294_3
				var_293_2.entity = var_294_0
				var_293_2.is_valid = true
				var_293_2.handle = arg_294_0.handle
			end
		end
	end)

	if var_293_2.is_valid then
		var_293_2.origin = var_293_2.entity:get_abs_origin()
		var_293_2.eye_pos = var_293_2.entity:get_eye_pos()
		var_293_2.angle = math.calc_angle(var_293_1, var_293_2.origin)

		return var_293_2
	end

	return false
end, 7)

slot_0_14_0.nearest = {}

slot_0_14_0:register("get_nearest", function(arg_295_0)
	arg_295_0 = arg_295_0 or entities.get_local_pawn()

	if not arg_295_0 or not arg_295_0:is_alive() then
		return false
	end

	local var_295_0 = slot_0_14_0:get("get_origin")
	local var_295_1 = slot_0_14_0.nearest or {}
	local var_295_2 = 99999

	var_295_1.is_valid = false

	entities.players:for_each(function(arg_296_0)
		local var_296_0 = arg_296_0.entity

		if var_296_0 and var_296_0:is_alive() and var_296_0:is_enemy() then
			local var_296_1 = var_296_0:get_abs_origin()
			local var_296_2 = math.calc_dist(var_296_1, var_295_0)

			if var_296_2 < var_295_2 then
				var_295_2 = var_296_2
				var_295_1.entity = var_296_0
				var_295_1.is_valid = true
				var_295_1.handle = arg_296_0.handle
			end
		end
	end)

	if var_295_1.is_valid then
		var_295_1.origin = var_295_1.entity:get_abs_origin()
		var_295_1.dist = var_295_2
		var_295_1.weapon = slot_0_28_0.get_weapon_group(var_295_1.entity)
		var_295_1.angle = math.calc_angle(var_295_0, var_295_1.origin)

		return var_295_1
	end

	return false
end, 6)
slot_0_14_0:register("active_hotkeys", function()
	slot_0_14_0.cache.hotkeys = {}

	for iter_297_0, iter_297_1 in pairs(slot_0_6_0.hotkeys_list) do
		if iter_297_0 ~= "legit" or iter_297_0 == "legit" and slot_0_4_0.vars.keybinds.legit_enabled then
			for iter_297_2 = 1, #iter_297_1 do
				local var_297_0 = iter_297_1[iter_297_2]
				local var_297_1 = type(var_297_0.active)

				var_297_0.alpha = var_297_0.alpha or 0
				var_297_0.is_active = var_297_0.active and (var_297_1 == "userdata" and var_297_0.active.get_hotkey_state and var_297_0.active:get_hotkey_state() or var_297_1 == "function" and var_297_0:active())

				if var_297_0.is_active or (var_297_0.alpha or 0) > 0 then
					table.insert(slot_0_14_0.cache.hotkeys, var_297_0)
				end
			end
		end
	end

	return slot_0_14_0.cache.hotkeys
end, 15)
slot_0_14_0:get("get_target")

slot_0_29_0 = {}
slot_0_29_0 = {
	vars = {
		fps = {
			min = 999,
			summ = 0,
			delay = 0,
			count = 0
		},
		tick = {
			count = 0,
			old_time = 0,
			summ = 0,
			old_tick = 0
		}
	},
	always = {
		avg_fps = function()
			local var_298_0 = slot_0_29_0.vars.fps
			local var_298_1 = 1 / slot_0_6_0.frame_time

			var_298_0.count = var_298_0.count + 1
			var_298_0.min = math.min(var_298_0.min, var_298_1)

			if var_298_0.delay < slot_0_6_0.real_time then
				slot_0_6_0.avg_fps = math.floor(var_298_0.count / (0.7 + slot_0_6_0.real_time - var_298_0.delay))
				slot_0_6_0.min_fps = math.floor(var_298_0.min)
				var_298_0.min = 999
				var_298_0.delay = slot_0_6_0.real_time + 0.7
				var_298_0.count = 1
			end
		end,
		avg_tick_interval = function()
			do return end

			local var_299_0 = slot_0_29_0.vars.tick

			if var_299_0.old_tick ~= game.global_vars.tick_count then
				var_299_0.summ = var_299_0.summ + slot_0_6_0.real_time - var_299_0.old_time
				var_299_0.count = var_299_0.count + 1
				var_299_0.old_tick = game.global_vars.tick_count
				var_299_0.old_time = slot_0_6_0.real_time
			end

			if var_299_0.count > 64 then
				slot_0_6_0.tick_interval = var_299_0.summ / var_299_0.count
				var_299_0.count = 0
				var_299_0.summ = 0
			end
		end
	}
}
slot_0_30_0 = {}
slot_0_30_0 = {
	vars = {
		dist_cam_to_head = 0,
		free_cam = {
			alpha = 0,
			is_started = false,
			start_origin = slot_0_11_0(0, 0, 0),
			view_origin = slot_0_11_0(0, 0, 0)
		},
		head_hat = {
			slot_0_13_0.visuals.head_hat.settings:element():add_callback(function()
				local var_300_0 = slot_0_30_0.vars.head_hat
				local var_300_1 = slot_0_13_0.visuals.head_hat

				var_300_0.enabled = var_300_1.settings:get("Nimbus") or var_300_1.settings:get("Chinese")
				var_300_0.nimb = var_300_1.settings:get("Nimbus")
				var_300_0.nimb_glow = var_300_1.settings:get(" > Nimbus: Glow")
				var_300_0.china = var_300_1.settings:get("Chinese")
				var_300_0.china_outline = var_300_1.settings:get(" > Chinese: outline")
				var_300_0.style_id = var_300_1.settings:get("Global: Rainbow") and 1 or var_300_1.settings:get("Global: Fade") and 2
				var_300_0.segments = var_300_1.params.segments:get()
				var_300_0.color_main = var_300_1.params.color.main:get()
				var_300_0.color_fade = var_300_1.params.color.fade:get()
			end),
			slot_0_13_0.visuals.head_hat.params.color.main:element():add_callback(function()
				slot_0_30_0.vars.head_hat.color_main = slot_0_13_0.visuals.head_hat.params.color.main:get()
			end),
			slot_0_13_0.visuals.head_hat.params.color.fade:element():add_callback(function()
				slot_0_30_0.vars.head_hat.color_fade = slot_0_13_0.visuals.head_hat.params.color.fade:get()
			end),
			slot_0_13_0.visuals.head_hat.params.segments:element():add_callback(function()
				slot_0_30_0.vars.head_hat.segments = slot_0_13_0.visuals.head_hat.params.segments:get()
			end)
		},
		target_cam = {
			is_started = false,
			origin = slot_0_11_0(0, 0, 0),
			angle = slot_0_11_0(0, 0, 0)
		},
		trails = {
			slot_0_13_0.visuals.trails.settings:element():add_callback(function()
				local var_304_0 = slot_0_30_0.vars.trails
				local var_304_1 = slot_0_13_0.visuals.trails

				var_304_0.enabled = var_304_1.settings:get("Line") or var_304_1.settings:get("3D Circle")

				if not var_304_0.enabled then
					var_304_0.list = {}
				end

				var_304_0.line = var_304_1.settings:get("Line")
				var_304_0.line_glow = var_304_1.settings:get(" > Line: glow [Fps]")
				var_304_0.line_afk = var_304_1.settings:get(" > Line: afk animation")
				var_304_0.line_rainbow = var_304_1.settings:get(" > Line: rainbow")
				var_304_0.life_time = var_304_1.params.lifetime:get()
				var_304_0.accent = var_304_1.params.colors.first:get()
				var_304_0.fade = var_304_1.params.colors.second:get()
			end),
			slot_0_13_0.visuals.trails.params.lifetime:element():add_callback(function()
				slot_0_30_0.vars.trails.life_time = slot_0_13_0.visuals.trails.params.lifetime:get()
			end),
			slot_0_13_0.visuals.trails.params.lifetime:element():add_callback(function()
				slot_0_30_0.vars.trails.accent = slot_0_13_0.visuals.trails.params.colors.first:get()
			end),
			slot_0_13_0.visuals.trails.params.lifetime:element():add_callback(function()
				slot_0_30_0.vars.trails.fade = slot_0_13_0.visuals.trails.params.colors.second:get()
			end),
			delay = 0,
			afk_time = 0,
			list = {},
			add_trails = function(arg_308_0, arg_308_1)
				if arg_308_0.delay + slot_0_6_0.frame_time * 3.5 < slot_0_6_0.real_time then
					arg_308_0.delay = slot_0_6_0.real_time

					table.insert(arg_308_0.list, {
						alpha = 0,
						pos = arg_308_1,
						time = slot_0_6_0.real_time
					})
				end
			end
		}
	},
	in_game = {
		free_cam = function(arg_309_0)
			if not arg_309_0 then
				return
			end

			local var_309_0 = slot_0_30_0.vars.free_cam
			local var_309_1 = slot_0_13_0.visuals.free_cam

			if not var_309_1.marker:get() or not var_309_1.parrent:get() then
				return
			end

			local var_309_2 = arg_309_0:get_eye_pos()

			if var_309_2 and var_309_2.z then
				var_309_2.z = var_309_2.z + 5

				local var_309_3 = math.world_to_screen(var_309_2)

				if slot_0_3_0.on_screen(var_309_3) then
					local var_309_4 = slot_0_3_0.text_size("Player", slot_0_18_0.verdana)

					slot_0_3_0.text("Player", slot_0_18_0.verdana, slot_0_11_0(var_309_3.x - var_309_4.x / 2, var_309_3.y - var_309_4.y - 4), slot_0_12_0())
					draw.surface:add_triangle_filled(slot_0_11_0(var_309_3.x - 9, var_309_3.y), slot_0_11_0(var_309_3.x + 9, var_309_3.y), slot_0_11_0(var_309_3.x, var_309_3.y + 18), slot_0_12_0(180, 150, 255))
				end
			end
		end,
		trails = function(arg_310_0)
			local var_310_0 = slot_0_30_0.vars.trails

			if not var_310_0.enabled or not arg_310_0 or not arg_310_0:is_alive() then
				return
			end

			local var_310_1 = var_310_0.life_time
			local var_310_2 = var_310_0.accent
			local var_310_3 = var_310_0.fade
			local var_310_4 = var_310_0.line_glow
			local var_310_5 = arg_310_0:get_abs_velocity():length() < 6

			if not var_310_5 and var_310_0.afk_time == 0 then
				var_310_0:add_trails(arg_310_0:get_abs_origin())
			elseif (var_310_5 or var_310_0.afk_time > 0) and var_310_0.line_afk then
				var_310_0.afk_time = var_310_0.afk_time + slot_0_6_0.frame_time * (var_310_5 and 1 or -1)
				var_310_0.afk_time = math.clamp(var_310_0.afk_time, 0, 1)
				var_310_1 = 1.5 + math.cos(slot_0_6_0.real_time)

				if var_310_0.afk_time > 0 then
					local var_310_6 = arg_310_0:get_abs_origin()

					var_310_6.x = var_310_6.x + 15 * math.cos(slot_0_6_0.real_time * 1.6) * var_310_0.afk_time
					var_310_6.y = var_310_6.y + 15 * math.sin(slot_0_6_0.real_time * 1.6) * var_310_0.afk_time

					var_310_0:add_trails(var_310_6)
				end
			elseif not var_310_0.line_afk then
				var_310_0.afk_time = 0
			end

			local var_310_7 = -1
			local var_310_8 = draw.surface

			for iter_310_0 = 1, #var_310_0.list - 1 do
				local var_310_9 = var_310_0.list[iter_310_0]
				local var_310_10 = var_310_0.list[iter_310_0 + 1]
				local var_310_11 = var_310_9.time + var_310_1 > slot_0_6_0.real_time
				local var_310_12 = math.lerp_color(var_310_3, var_310_2, iter_310_0 / #var_310_0.list)

				if var_310_0.line then
					local var_310_13 = math.world_to_screen(var_310_9.pos)
					local var_310_14 = math.world_to_screen(var_310_10.pos)

					var_310_9.alpha = math.bounded_lerp(var_310_9.alpha, 0, 1, 3, var_310_11)

					if slot_0_3_0.on_screen(var_310_13) and slot_0_3_0.on_screen(var_310_14) then
						if var_310_0.line_rainbow then
							var_310_12 = var_310_12:hsv((iter_310_0 / #var_310_0.list + slot_0_6_0.real_time * 0.4) * 360 % 360, 0.5, 1)
						end

						local var_310_15 = var_310_12:a(var_310_12:get_a() / 255 * var_310_10.alpha)

						if var_310_4 then
							slot_0_3_0.line_glow(var_310_8, var_310_13, var_310_14, var_310_15:a(var_310_15:get_a() / 255 * 0.14), nil, 1)
						end

						slot_0_3_0.line(var_310_8, var_310_13, var_310_14, var_310_15)
					end
				end

				if var_310_9.alpha == 0 and not var_310_11 then
					var_310_7 = iter_310_0
				end
			end

			if var_310_7 ~= -1 then
				while var_310_7 > 0 do
					table.remove(var_310_0.list, var_310_7)

					var_310_7 = var_310_7 - 1
				end
			end
		end,
		head_hat = function(arg_311_0)
			local var_311_0 = slot_0_30_0.vars.head_hat

			if not var_311_0.enabled or not arg_311_0 or not arg_311_0:is_alive() then
				return
			end

			local var_311_1 = slot_0_28_0.get_hitbox_pos(arg_311_0, 6)

			if not var_311_1 or not var_311_1.x then
				return
			end

			var_311_1.z = var_311_1.z + 2

			local var_311_2 = math.clamp((slot_0_30_0.vars.dist_cam_to_head - 20) / 40, 0, 1)
			local var_311_3 = var_311_0.color_main:a(math.max(0.001, var_311_0.color_main:get_a() / 255) * var_311_2)
			local var_311_4 = var_311_0.color_fade:a(math.max(0.001, var_311_0.color_fade:get_a() / 255) * var_311_2)

			if var_311_0.china then
				slot_0_3_0.china_hat(var_311_1, 10, var_311_0.segments, 7, var_311_3, var_311_4, var_311_0.china_outline, var_311_0.style_id)
			end

			if var_311_0.nimb then
				var_311_1.z = var_311_1.z + 4

				slot_0_3_0.circle_3d(var_311_1, 6, var_311_0.segments, var_311_3, 2, var_311_4, var_311_0.style_id, var_311_0.nimb_glow)
			end
		end
	},
	override_view = {
		free_cam = function(arg_312_0)
			local var_312_0 = slot_0_30_0.vars.free_cam
			local var_312_1 = slot_0_13_0.visuals.free_cam

			if var_312_1.parrent:get() then
				if not var_312_0.is_started then
					var_312_0.cmd_angle = nil
					var_312_0.start_origin = slot_0_11_0(arg_312_0.origin.x, arg_312_0.origin.y, arg_312_0.origin.z)
					var_312_0.start_angles = slot_0_11_0(arg_312_0.view.x, arg_312_0.view.y, arg_312_0.view.z)
					var_312_0.is_started = true
					var_312_0.view_origin = slot_0_11_0(arg_312_0.origin.x, arg_312_0.origin.y, arg_312_0.origin.z)
					var_312_0.view_angles = arg_312_0.view
				end

				arg_312_0.origin = var_312_0.view_origin

				local var_312_2 = entities.get_local_pawn()

				if var_312_2 and not var_312_2:is_alive() then
					local var_312_3 = var_312_1.multiplier:get() * ((slot_0_24_0.key_pressed(16) or slot_0_24_0.key_pressed(160)) and 0.4 or 1)
					local var_312_4 = math.angle_to_vector(var_312_0.view_angles)
					local var_312_5 = slot_0_24_0.key_pressed(87) and 1 or slot_0_24_0.key_pressed(83) and -1 or 0

					var_312_0.view_origin = var_312_0.view_origin + math.multiply_vector(var_312_4, var_312_3 * var_312_5)

					local var_312_6 = math.angle_to_vector(slot_0_11_0(var_312_0.view_angles.x, var_312_0.view_angles.y + 90, 0))

					var_312_6.z = 0

					local var_312_7 = slot_0_24_0.key_pressed(65) and 1 or slot_0_24_0.key_pressed(68) and -1 or 0

					var_312_0.view_origin = var_312_0.view_origin + math.multiply_vector(var_312_6, var_312_3 * var_312_7)
				end
			elseif var_312_0.is_started then
				var_312_0.is_started = false
				arg_312_0.origin = var_312_0.start_origin
			end
		end,
		target_cam = function(arg_313_0)
			local var_313_0 = entities.get_local_pawn()

			if not var_313_0 then
				slot_0_30_0.vars.target_cam.is_started = false

				return
			end

			local var_313_1 = slot_0_30_0.vars.target_cam

			if slot_0_13_0.visuals.target_cam.enable:get() then
				local var_313_2 = var_313_0:get_abs_origin()
				local var_313_3 = slot_0_27_0.trace_line

				if not var_313_1.is_started then
					local var_313_4 = slot_0_14_0:get("get_target", var_313_0)

					if not var_313_4 then
						return
					end

					var_313_1.cmd_angle = nil
					var_313_1.target = var_313_4.handle and var_313_4.handle:get()

					if not var_313_1.target then
						return
					end

					var_313_1.is_started = true

					local var_313_5 = var_313_1.target:get_eye_pos() + slot_0_11_0(0, 0, 10)

					var_313_1.origin = var_313_5
					var_313_1.angle = math.calc_angle(var_313_5, var_313_2) - arg_313_0.view
				end

				local var_313_6 = var_313_1.target:get_eye_pos()

				var_313_6.z = var_313_6.z + 20

				local var_313_7 = math.calc_angle(var_313_6, var_313_2)
				local var_313_8 = math.angle_to_vector(arg_313_0.view + var_313_1.angle)
				local var_313_9 = var_313_3(var_313_6, var_313_6 - math.multiply_vector(var_313_8, 140), var_313_0)

				var_313_1.origin = slot_0_11_0(var_313_9.end_pos.x, var_313_9.end_pos.y, var_313_9.end_pos.z)
				arg_313_0.origin = var_313_1.origin
				arg_313_0.view = arg_313_0.view + var_313_1.angle
			elseif var_313_1.is_started then
				var_313_1.is_started = false
			end
		end,
		cam_dist_calc = function(arg_314_0)
			local var_314_0 = entities.get_local_pawn()

			if not var_314_0 then
				return
			end

			local var_314_1 = var_314_0:get_eye_pos()

			if not var_314_1 then
				return
			end

			slot_0_30_0.vars.dist_cam_to_head = math.calc_dist(var_314_1, arg_314_0.origin)
		end
	},
	create_move = {
		free_cam = function(arg_315_0)
			local var_315_0 = slot_0_30_0.vars.free_cam
			local var_315_1 = slot_0_13_0.visuals.free_cam

			if not var_315_1.parrent:get() or not var_315_0.is_started then
				return
			end

			local var_315_2 = var_315_1.multiplier:get() * (arg_315_0:get_button(input_bit_mask.in_speed) and 0.4 or 1)
			local var_315_3 = math.angle_to_vector(var_315_0.view_angles)
			local var_315_4 = slot_0_24_0.key_pressed(87) and 1 or slot_0_24_0.key_pressed(83) and -1 or arg_315_0:get_forwardmove()

			var_315_0.view_origin = var_315_0.view_origin + math.multiply_vector(var_315_3, var_315_2 * var_315_4)

			local var_315_5 = math.angle_to_vector(slot_0_11_0(var_315_0.view_angles.x, var_315_0.view_angles.y + 90, 0))

			var_315_5.z = 0

			local var_315_6 = slot_0_24_0.key_pressed(65) and 1 or slot_0_24_0.key_pressed(68) and -1 or arg_315_0:get_leftmove()

			var_315_0.view_origin = var_315_0.view_origin + math.multiply_vector(var_315_5, var_315_2 * var_315_6)

			if arg_315_0:get_button(input_bit_mask.in_jump) then
				var_315_0.view_origin.z = var_315_0.view_origin.z + var_315_2 * 0.8
			end

			if arg_315_0:get_button(input_bit_mask.in_duck) then
				var_315_0.view_origin.z = var_315_0.view_origin.z - var_315_2 * 0.8
			end

			arg_315_0:set_forwardmove(0)
			arg_315_0:set_leftmove(0)
			arg_315_0:remove_button(input_bit_mask.in_jump)
			arg_315_0:remove_button(input_bit_mask.in_duck)

			if not var_315_0.cmd_angle then
				var_315_0.cmd_angle = arg_315_0:get_viewangles()
			end

			arg_315_0:set_viewangles(var_315_0.cmd_angle)
		end,
		target_cam = function(arg_316_0)
			if slot_0_30_0.vars.target_cam.is_started then
				if not slot_0_30_0.vars.target_cam.cmd_angle then
					slot_0_30_0.vars.target_cam.cmd_angle = arg_316_0:get_viewangles()
				end

				arg_316_0:set_forwardmove(0)
				arg_316_0:set_leftmove(0)
				arg_316_0:remove_button(input_bit_mask.in_jump)
				arg_316_0:set_viewangles(slot_0_30_0.vars.target_cam.cmd_angle)
			end
		end
	}
}
slot_0_4_0 = {
	vars = {
		widgets = {
			static_color = slot_0_12_0(),
			background = slot_0_13_0.ui.widgets.visual.background:get() or slot_0_12_0(21),
			accent = slot_0_13_0.ui.widgets.visual.accent:get() or slot_0_12_0(),
			slot_0_13_0.ui.widgets.visual.background:element():add_callback(function()
				slot_0_4_0.vars.widgets.background = slot_0_13_0.ui.widgets.visual.background:get()
			end),
			slot_0_13_0.ui.widgets.visual.accent:element():add_callback(function()
				slot_0_4_0.vars.widgets.accent = slot_0_13_0.ui.widgets.visual.accent:get()
			end)
		},
		watermark = {
			show_tab = {},
			text = {
				{
					t = "nick",
					i = slot_0_3_0.get_icon("user") or "",
					f = function()
						return tostring(gui.ctx.user.username)
					end
				},
				{
					t = "fps",
					i = slot_0_3_0.get_icon("chart") or "",
					f = function()
						return tostring(math.floor(slot_0_6_0.avg_fps or 0))
					end
				},
				{
					t = "0.1%",
					i = slot_0_3_0.get_icon("miss") or "",
					f = function()
						return tostring(math.floor(slot_0_6_0.min_fps or 0))
					end
				},
				{
					t = "time",
					i_add_y = -1,
					i = slot_0_3_0.get_icon("clock") or "",
					f = function()
						return slot_0_6_0.get_local_time()
					end
				},
				{
					t = "latency",
					i_add_y = 0,
					i = slot_0_3_0.get_icon("cloud") or "",
					f = function()
						return tostring(slot_0_14_0:get("get_latency"))
					end
				}
			},
			slot_0_26_0.create("watermark", slot_0_11_0(slot_0_6_0.screen_size.x * 0.2, slot_0_6_0.screen_size.y * 0.2)),
			alpha = 0,
			width = 100,
			padding = 6,
			slot_0_14_0:register("get_watermark_text", function(arg_324_0, arg_324_1)
				if not arg_324_0 then
					return
				end

				arg_324_0.show_tab = {
					{
						"Mercury",
						arg_324_0.static_color,
						add_y = -slot_0_18_0.offset.alata_main / 2 + 1
					}
				}

				local var_324_0 = arg_324_0.show_tab
				local var_324_1 = slot_0_4_0.vars.watermark.text
				local var_324_2 = arg_324_0.use_icons
				local var_324_3 = arg_324_0.use_title

				for iter_324_0 = 1, #var_324_1 do
					local var_324_4 = var_324_1[iter_324_0]

					if var_324_4.enabled then
						if var_324_2 then
							table.insert(var_324_0, {
								"  " .. (var_324_4.i or ""),
								arg_324_1.static_color,
								icon = true,
								add_y = slot_0_18_0.offset.icons.mercury / 2 - 2 + (var_324_4.i_add_y or 0)
							})
						end

						if var_324_3 then
							table.insert(var_324_0, {
								(var_324_2 and " " or " · ") .. (var_324_4.t or ""),
								arg_324_1.static_color,
								add_y = -slot_0_18_0.offset.alata_main / 2 + 1
							})
						end

						if type(var_324_4.f) == "function" then
							table.insert(var_324_0, {
								((var_324_2 or var_324_3) and " " or "  ") .. tostring(var_324_4.f()),
								arg_324_1.accent:a(1),
								add_y = -slot_0_18_0.offset.alata_main / 2 + 1
							})
						end
					end
				end

				local var_324_5 = slot_0_3_0.get_multi_text_size(var_324_0, slot_0_18_0.alata_main, slot_0_18_0.icons.mercury)

				return {
					text = var_324_0,
					t_size = var_324_5
				}
			end, 32)
		},
		keybinds = {
			title = {
				{
					slot_0_3_0.get_icon("light") or "",
					slot_0_13_0.ui.widgets.visual.accent:get():a(1),
					icon = true,
					add_y = slot_0_18_0.offset.icons.mercury_bold / 2 - 4
				},
				{
					" Hotkeys",
					slot_0_12_0(),
					add_y = -slot_0_18_0.offset.verdana / 2 + 2
				}
			},
			slot_0_13_0.ui.widgets.visual.accent:element():add_callback(function()
				slot_0_4_0.vars.keybinds.title[1][2] = slot_0_13_0.ui.widgets.visual.accent:get():a(1)
			end),
			alpha = 0,
			width = 100,
			height = 0,
			solid_style = false,
			padding = 6,
			active = false,
			slot_0_26_0.create("keybinds", slot_0_11_0(slot_0_6_0.screen_size.x * 0.2, slot_0_6_0.screen_size.y * 0.3))
		},
		crosshair_indicator = {
			title_size = slot_0_3_0.text_size("mercury", slot_0_18_0.verdanab),
			condition = {
				current = "cond",
				progress = 1
			},
			slot_0_26_0.create("crosshair_indicator", slot_0_11_0(slot_0_6_0.screen_size.x * 0.5, slot_0_6_0.screen_size.y * 0.5 + 10)),
			accent = slot_0_13_0.ui.widgets.crosshair_indicator.visual.accent:get(),
			background = slot_0_13_0.ui.widgets.crosshair_indicator.visual.background:get(),
			slot_0_13_0.ui.widgets.crosshair_indicator.visual.background:element():add_callback(function()
				slot_0_4_0.vars.crosshair_indicator.background = slot_0_13_0.ui.widgets.crosshair_indicator.visual.background:get()
			end),
			alpha = 0,
			slot_0_13_0.ui.widgets.crosshair_indicator.visual.accent:element():add_callback(function()
				slot_0_4_0.vars.crosshair_indicator.accent = slot_0_13_0.ui.widgets.crosshair_indicator.visual.accent:get()
			end)
		},
		buy_logs = {},
		rage_logs = {
			list = {},
			display = {},
			slot_0_26_0.create("rage_logs", slot_0_11_0(slot_0_6_0.screen_size.x / 2, slot_0_6_0.screen_size.y * 0.6), "rage logs zone"),
			padding = 6,
			offset = 8,
			updater = function()
				if not slot_0_6_0.is_loaded then
					return
				end

				local var_328_0 = slot_0_13_0.ui.widgets.rage_logs.display

				slot_0_4_0.vars.rage_logs.display = {
					background = var_328_0:get("Background"),
					blur = var_328_0:get("Blur"),
					glow = var_328_0:get("Glow"),
					outline = var_328_0:get("Outline")
				}

				local var_328_1 = slot_0_4_0.vars.rage_logs.display

				slot_0_4_0.vars.rage_logs.offset = var_328_1.glow and (var_328_1.blur or var_328_1.background or var_328_1.outline) and 10 or (var_328_1.background or var_328_1.blur or var_328_1.outline) and 5 or 0

				local var_328_2 = math.random(0, 2)
				local var_328_3 = slot_0_13_0.ui.widgets.rage_logs.visual.buy:get()

				table.insert(slot_0_4_0.vars.rage_logs.list, {
					alpha = 0,
					text = {
						{
							slot_0_3_0.get_icon("coins"),
							var_328_3,
							icon = true,
							add_y = slot_0_18_0.offset.icons.mercury / 2 - 3
						},
						{
							string.format(" %s bought: ", "Player"),
							add_y = slot_0_18_0.offset.global
						},
						{
							tostring("asdf"),
							var_328_3,
							icon = true,
							icon_font = slot_0_18_0.icons.cs_go14,
							add_y = slot_0_18_0.offset.icons.cs_go14 / 2
						}
					},
					time = slot_0_6_0.real_time,
					accent = var_328_3
				})
				slot_0_4_0.add_rage_log("hit", {
					name = "player",
					hitgroup = "head",
					damage = tostring(math.random(0, 100)),
					health = tostring(math.random(0, 99)),
					weapon = var_328_2 == 0 and "knife" or var_328_2 == 1 and "hegrenade" or var_328_2 == 2 and "molotov" or "weapon"
				})
				slot_0_4_0.add_rage_log("hurt", {
					name = "player",
					hitgroup = "head",
					damage = tostring(math.random(0, 100)),
					health = tostring(math.random(0, 99)),
					weapon = var_328_2 == 0 and "knife" or var_328_2 == 1 and "hegrenade" or var_328_2 == 2 and "molotov" or "weapon"
				})
			end
		},
		velocity_modifier = {
			alpha = 0,
			value = 1,
			modifier = 0.4,
			render_round2 = function(arg_329_0, arg_329_1, arg_329_2)
				slot_0_3_0.rect(slot_0_11_0(arg_329_0.x + 0, arg_329_0.y + 1), slot_0_11_0(arg_329_1.x - 0, arg_329_1.y - 1), arg_329_2, 0)
				slot_0_3_0.rect(slot_0_11_0(arg_329_0.x + 1, arg_329_0.y + 0), slot_0_11_0(arg_329_1.x - 1, arg_329_1.y - 0), arg_329_2, 0)
			end,
			slot_0_26_0.create("velocity_modifier", slot_0_11_0(slot_0_6_0.screen_size.x * 0.5, slot_0_6_0.screen_size.y * 0.2))
		},
		world_marker = {
			list = {},
			last_pos = slot_0_11_0(0, 0, 0),
			color_first = slot_0_12_0(),
			color_second = slot_0_12_0(),
			slot_0_13_0.visuals.world_marker.impact.lifetime:element():add_callback(function()
				slot_0_4_0.vars.world_marker.life_time = slot_0_13_0.visuals.world_marker.impact.lifetime:get()
			end),
			slot_0_13_0.visuals.world_marker.impact.offset:element():add_callback(function()
				slot_0_4_0.vars.world_marker.offset = slot_0_13_0.visuals.world_marker.impact.offset:get()
			end),
			slot_0_13_0.visuals.world_marker.impact.length:element():add_callback(function()
				slot_0_4_0.vars.world_marker.length = slot_0_13_0.visuals.world_marker.impact.length:get()
			end),
			slot_0_13_0.visuals.world_marker.impact.colors.first:element():add_callback(function()
				slot_0_4_0.vars.world_marker.color_first = slot_0_13_0.visuals.world_marker.impact.colors.first:get()
			end),
			last_counter = 0,
			last_time = 0,
			length = 0,
			offset = 0,
			life_time = 0,
			slot_0_13_0.visuals.world_marker.impact.colors.second:element():add_callback(function()
				slot_0_4_0.vars.world_marker.color_second = slot_0_13_0.visuals.world_marker.impact.colors.second:get()
			end)
		},
		damage_markers = {},
		slot_0_13_0.visuals.world_marker.settings:element():add_callback(function()
			local var_335_0 = slot_0_4_0.vars.world_marker

			var_335_0.enabled = slot_0_13_0.visuals.world_marker.settings:get("Impact")
			var_335_0.horizontal = slot_0_13_0.visuals.world_marker.settings:get(" > Impact: horizontal")
			var_335_0.life_time = slot_0_13_0.visuals.world_marker.impact.lifetime:get()
			var_335_0.offset = slot_0_13_0.visuals.world_marker.impact.offset:get()
			var_335_0.length = slot_0_13_0.visuals.world_marker.impact.length:get()
			var_335_0.color_first = slot_0_13_0.visuals.world_marker.impact.colors.first:get()
			var_335_0.color_second = slot_0_13_0.visuals.world_marker.impact.colors.second:get()
		end),
		manuals_ind = {
			alpha = 0,
			offset = 0,
			left = slot_0_15_0.manual_left,
			right = slot_0_15_0.manual_right
		},
		physic_text = {},
		physic_text_params = {
			domination_stats = {},
			slot_0_13_0.visuals.physic_text.params.accent:element():add_callback(function()
				slot_0_4_0.vars.physic_text_params.accent = slot_0_13_0.visuals.physic_text.params.accent:get()
			end),
			slot_0_13_0.visuals.physic_text.params.style:element():add_callback(function()
				slot_0_4_0.vars.physic_text_params.style = slot_0_13_0.visuals.physic_text.params.style:get("Outline") and 1 or slot_0_13_0.visuals.physic_text.params.style:get("Fatality") and 2 or slot_0_13_0.visuals.physic_text.params.style:get("Ghosting") and 3 or 0
			end),
			last = 0,
			side = 0,
			killstreak_counter = 0,
			slot_0_13_0.visuals.physic_text.settings:element():add_callback(function()
				slot_0_4_0.vars.physic_text_params.enabled = slot_0_13_0.visuals.physic_text.settings:get() ~= 0
				slot_0_4_0.vars.physic_text_params.damage = slot_0_13_0.visuals.physic_text.settings:get("Damage")
				slot_0_4_0.vars.physic_text_params.killstreak = slot_0_13_0.visuals.physic_text.settings:get("Killstreak: announcer")
				slot_0_4_0.vars.physic_text_params.domination = slot_0_13_0.visuals.physic_text.settings:get("Domination: counter")
				slot_0_4_0.vars.physic_text_params.head_shot = slot_0_13_0.visuals.physic_text.settings:get("Headshot")
				slot_0_4_0.vars.physic_text_params.accent = slot_0_13_0.visuals.physic_text.params.accent:get()
				slot_0_4_0.vars.physic_text_params.style = slot_0_13_0.visuals.physic_text.params.style:get("Outline") and 1 or slot_0_13_0.visuals.physic_text.params.style:get("Fatality") and 2 or slot_0_13_0.visuals.physic_text.params.style:get("Ghosting") and 3 or 0
			end)
		}
	},
	add_notify_rage_log = function(arg_339_0, arg_339_1)
		if not slot_0_13_0.ui.widgets.settings:get("Notify: Rage logs") then
			return
		end

		slot_339_3_0 = slot_0_13_0.ui.widgets.rage_logs

		if arg_339_0 == "hit" then
			slot_339_4_1 = slot_0_4_0.vars.watermark
			slot_339_5_1 = arg_339_1.weapon == "taser" and slot_0_12_0(120, 120, 255) or slot_339_3_0.visual.hit:get()
			slot_339_6_1 = slot_0_12_0()
			slot_339_7_1 = slot_0_6_0.custom_icon_from_weapon[arg_339_1.weapon] or slot_0_3_0.get_icon("hit") or ""
			slot_339_8_1 = nil

			if slot_0_6_0.weapon_name_to_font[arg_339_1.weapon] then
				slot_339_8_1 = slot_0_6_0.weapon_name_to_font[arg_339_1.weapon]
			end

			slot_339_9_1 = slot_0_18_0.offset.global
			slot_339_10_0 = {}
			slot_339_11_0 = {}

			if arg_339_1.weapon == "knife" then
				slot_339_11_0 = {
					"Knifed ",
					tostring(arg_339_1.name),
					": [ damage ",
					tostring(arg_339_1.damage),
					" | health ",
					tostring(arg_339_1.health),
					" ]"
				}
			elseif arg_339_1.weapon == "molotov" or arg_339_1.weapon == "inferno" then
				slot_339_11_0 = {
					"Burned ",
					tostring(arg_339_1.name),
					": [ damage ",
					tostring(arg_339_1.damage),
					" | health ",
					tostring(arg_339_1.health),
					" ]"
				}
			elseif arg_339_1.weapon == "hegrenade" then
				slot_339_11_0 = {
					"Exploded ",
					tostring(arg_339_1.name),
					": [ damage ",
					tostring(arg_339_1.damage),
					" | health ",
					tostring(arg_339_1.health),
					" ]"
				}
			elseif arg_339_1.weapon == "taser" then
				slot_339_11_0 = {
					"Тased ",
					tostring(arg_339_1.name)
				}
			else
				slot_339_11_0 = {
					"Hit in ",
					tostring(arg_339_1.name),
					": [ hitgroup ",
					tostring(slot_0_6_0.player_hitbox[arg_339_1.hitgroup]),
					" | damage  ",
					tostring(arg_339_1.damage),
					" | health ",
					tostring(arg_339_1.health),
					" | ",
					"",
					" ]"
				}
			end

			for iter_339_0 = 1, #slot_339_11_0 do
				table.insert(slot_339_10_0, {
					slot_339_11_0[iter_339_0],
					iter_339_0 % 2 == 1 and slot_339_6_1 or slot_339_5_1
				})
			end

			if slot_339_10_0[1][1] == "Hit in " then
				table.insert(slot_339_10_0, #slot_339_11_0, {
					slot_339_8_1 or arg_339_1.weapon,
					slot_339_5_1,
					icon = slot_339_8_1 ~= nil,
					icon_font = slot_339_8_1 ~= nil and slot_0_18_0.icons.cs_go14,
					add_y = slot_0_18_0.offset.icons.cs_go14 / 2 - 1
				})
			end

			slot_0_3_0.notify(slot_339_10_0, {
				id = (arg_339_1.weapon == "molotov" or arg_339_1.weapon == "inferno") and string.format("%s%s", arg_339_1.name, slot_339_10_0[1][1]),
				icon_font = slot_339_8_1 ~= nil and slot_0_18_0.icons.cs_go14
			}, slot_0_3_0.make_notify_style(slot_339_7_1, slot_339_5_1, "fast_blur", true))
		elseif arg_339_0 == "hurt" then
			slot_339_4_0 = arg_339_1.weapon == "taser" and slot_0_12_0(120, 120, 255) or slot_339_3_0.visual.hurt:get()
			slot_339_5_0 = slot_0_12_0()
			slot_339_6_0 = slot_0_6_0.custom_icon_from_weapon[arg_339_1.weapon] or slot_0_3_0.get_icon("hit") or ""
			slot_339_7_0 = nil

			if slot_0_6_0.weapon_name_to_font[arg_339_1.weapon] then
				slot_339_7_0 = slot_0_6_0.weapon_name_to_font[arg_339_1.weapon]
			end

			slot_339_8_0 = {}
			slot_339_9_0 = {}

			if arg_339_1.weapon == "knife" then
				slot_339_9_0 = {
					"Knifed by ",
					tostring(arg_339_1.name),
					": [ damage ",
					tostring(arg_339_1.damage),
					" | health ",
					tostring(arg_339_1.health),
					" ]"
				}
			elseif arg_339_1.weapon == "molotov" or arg_339_1.weapon == "inferno" then
				slot_339_9_0 = {
					"Burned ",
					tostring(arg_339_1.name),
					": [ damage ",
					tostring(arg_339_1.damage),
					" | health ",
					tostring(arg_339_1.health),
					" ]"
				}
			elseif arg_339_1.weapon == "hegrenade" then
				slot_339_9_0 = {
					"Exploded by ",
					tostring(arg_339_1.name),
					": [ damage ",
					tostring(arg_339_1.damage),
					" | health ",
					tostring(arg_339_1.health),
					" ]"
				}
			elseif arg_339_1.weapon == "taser" then
				slot_339_9_0 = {
					"Тased by ",
					tostring(arg_339_1.name)
				}
			else
				slot_339_9_0 = {
					"Hurt by ",
					tostring(arg_339_1.name),
					": [ hitgroup ",
					tostring(slot_0_6_0.player_hitbox[arg_339_1.hitgroup]),
					" | damage ",
					tostring(arg_339_1.damage),
					" | health ",
					tostring(arg_339_1.health),
					" | ",
					"",
					" ]"
				}
			end

			for iter_339_1 = 1, #slot_339_9_0 do
				table.insert(slot_339_8_0, {
					slot_339_9_0[iter_339_1],
					iter_339_1 % 2 == 1 and slot_339_5_0 or slot_339_4_0
				})
			end

			if slot_339_8_0[1][1] == "Hurt by " then
				table.insert(slot_339_8_0, #slot_339_9_0, {
					slot_339_7_0 or arg_339_1.weapon,
					slot_339_4_0,
					icon = slot_339_7_0 ~= nil,
					icon_font = slot_339_7_0 ~= nil and slot_0_18_0.icons.cs_go14,
					add_y = slot_0_18_0.offset.icons.cs_go14 / 2 - 1
				})
			end

			slot_0_3_0.notify(slot_339_8_0, {
				id = (arg_339_1.weapon == "molotov" or arg_339_1.weapon == "inferno") and string.format("%s%s", arg_339_1.name, slot_339_8_0[1][1]),
				icon_font = slot_339_7_0 ~= nil and slot_0_18_0.icons.cs_go14
			}, slot_0_3_0.make_notify_style(slot_339_6_0, slot_339_4_0, "fast_blur", true))
		end
	end,
	add_console_rage_log = function(arg_340_0, arg_340_1)
		if not (slot_0_13_0.ui.widgets.settings:get("Notify: Rage logs") or slot_0_13_0.ui.widgets.settings:get("Rage logs")) then
			return
		end

		local var_340_0 = slot_0_13_0.ui.widgets.rage_logs
		local var_340_1 = arg_340_0 == "hit" and var_340_0.visual.hit:get() or var_340_0.visual.hurt:get()
		local var_340_2 = slot_0_12_0()

		slot_0_3_0.colored_print({
			{
				arg_340_0 == "hit" and "Hit in " or "Hurt by ",
				var_340_2
			},
			{
				tostring(arg_340_1.name),
				var_340_1
			},
			{
				": [ hitgroup ",
				var_340_2
			},
			{
				tostring(slot_0_6_0.player_hitbox[arg_340_1.hitgroup] or "undefined"),
				var_340_1
			},
			{
				" | damage ",
				var_340_2
			},
			{
				tostring(arg_340_1.damage),
				var_340_1
			},
			{
				" | health ",
				var_340_2
			},
			{
				tostring(arg_340_1.health),
				var_340_1
			},
			arg_340_1.backtrack and {
				" | backtrack ",
				var_340_2
			} or {},
			arg_340_1.backtrack and {
				tostring(math.floor(arg_340_1.backtrack or 0)),
				var_340_1
			} or {},
			{
				" ]",
				var_340_2
			}
		})
	end,
	add_physic_text = function(arg_341_0, arg_341_1, arg_341_2)
		local var_341_0 = slot_0_4_0.vars.physic_text_params

		var_341_0.side = var_341_0.side + 1

		if var_341_0.side > 1 then
			var_341_0.side = -1
		end

		var_341_0.last = slot_0_6_0.real_time

		local var_341_1 = {}
		local var_341_2 = #arg_341_0 / 2
		local var_341_3 = slot_0_11_0(math.random(120, 240) * (var_341_0.side == 0 and 0.2 or var_341_0.side), math.random(-50, -180))

		for iter_341_0 = 1, #arg_341_0 do
			local var_341_4 = string.sub(arg_341_0, iter_341_0, iter_341_0)
			local var_341_5 = iter_341_0 < var_341_2 and -1 or 1

			var_341_1[#var_341_1 + 1] = {
				var_341_4,
				rotate = 0,
				multiply = math.random() * var_341_5 * (arg_341_2 and 0.5 or 1),
				Vector = slot_0_11_0(var_341_3.x + iter_341_0, var_341_3.y + (arg_341_2 and 0 or math.random(15, -15))),
				offset = slot_0_11_0(0, 0)
			}
		end

		table.insert(slot_0_4_0.vars.physic_text, {
			alpha = 0,
			info = var_341_1,
			pos = arg_341_1,
			time = slot_0_6_0.real_time
		})

		if #slot_0_4_0.vars.physic_text > 4 then
			for iter_341_1 = 1, #slot_0_4_0.vars.physic_text - 4 do
				slot_0_4_0.vars.physic_text[iter_341_1].time = 0
			end
		end
	end,
	add_rage_log = function(arg_342_0, arg_342_1)
		arg_342_1.name = arg_342_1.name and string.gsub(arg_342_1.name, "T", "Т") or "unknown"

		slot_0_4_0.add_notify_rage_log(arg_342_0, arg_342_1)
		slot_0_4_0.add_console_rage_log(arg_342_0, arg_342_1)

		if not slot_0_13_0.ui.widgets.settings:get("Rage logs") then
			return
		end

		slot_342_3_0 = slot_0_13_0.ui.widgets.rage_logs

		if arg_342_0 == "hit" then
			slot_342_4_1 = slot_0_4_0.vars.watermark
			slot_342_5_1 = arg_342_1.weapon == "taser" and slot_0_12_0(120, 120, 255) or slot_342_3_0.visual.hit:get()
			slot_342_6_1 = slot_0_12_0()
			slot_342_7_1 = slot_0_6_0.custom_icon_from_weapon[arg_342_1.weapon] or slot_0_3_0.get_icon("hit") or ""
			slot_342_8_1 = slot_0_18_0.offset.global
			slot_342_9_1 = {
				{
					tostring(slot_342_7_1),
					slot_342_5_1,
					icon = true,
					add_y = slot_0_18_0.offset.icons.mercury / 2 - 3
				}
			}
			slot_342_10_0 = {}

			if arg_342_1.weapon == "knife" then
				slot_342_10_0 = {
					" Knifed ",
					tostring(arg_342_1.name),
					" for ",
					tostring(arg_342_1.damage),
					" (",
					tostring(arg_342_1.health),
					") damage"
				}
			elseif arg_342_1.weapon == "molotov" or arg_342_1.weapon == "inferno" then
				slot_342_10_0 = {
					" Burned ",
					tostring(arg_342_1.name),
					" for ",
					tostring(arg_342_1.damage),
					" (",
					tostring(arg_342_1.health),
					") damage"
				}
			elseif arg_342_1.weapon == "hegrenade" then
				slot_342_10_0 = {
					" Exploded ",
					tostring(arg_342_1.name),
					" for ",
					tostring(arg_342_1.damage),
					" (",
					tostring(arg_342_1.health),
					") damage"
				}
			elseif arg_342_1.weapon == "taser" then
				slot_342_10_0 = {
					" Тased ",
					tostring(arg_342_1.name)
				}
			else
				slot_342_10_0 = {
					" Hit ",
					tostring(arg_342_1.name),
					" in ",
					tostring(slot_0_6_0.player_hitbox[arg_342_1.hitgroup]),
					" for ",
					tostring(arg_342_1.damage),
					" (",
					tostring(arg_342_1.health),
					") damage"
				}
			end

			for iter_342_0 = 1, #slot_342_10_0 do
				table.insert(slot_342_9_1, {
					slot_342_10_0[iter_342_0],
					iter_342_0 % 2 == 1 and slot_342_6_1 or slot_342_5_1,
					add_y = slot_342_8_1
				})
			end

			table.insert(slot_0_4_0.vars.rage_logs.list, {
				alpha = 0,
				text = slot_342_9_1,
				time = slot_0_6_0.real_time,
				accent = slot_342_5_1
			})
		elseif arg_342_0 == "hurt" then
			slot_342_4_0 = arg_342_1.weapon == "taser" and slot_0_12_0(120, 120, 255) or slot_342_3_0.visual.hurt:get()
			slot_342_5_0 = slot_0_12_0()
			slot_342_6_0 = slot_0_6_0.custom_icon_from_weapon[arg_342_1.weapon] or slot_0_3_0.get_icon("hit") or ""
			slot_342_7_0 = slot_0_18_0.offset.global
			slot_342_8_0 = {
				{
					tostring(slot_342_6_0),
					slot_342_4_0,
					icon = true
				},
				add_y = slot_0_18_0.offset.icons.mercury / 2 - 3
			}
			slot_342_9_0 = {}

			if arg_342_1.weapon == "knife" then
				slot_342_9_0 = {
					" Knifed by ",
					tostring(arg_342_1.name),
					" for ",
					tostring(arg_342_1.damage),
					" (",
					tostring(arg_342_1.health),
					") damage"
				}
			elseif arg_342_1.weapon == "molotov" or arg_342_1.weapon == "inferno" then
				slot_342_9_0 = {
					" Burned ",
					tostring(arg_342_1.name),
					" for ",
					tostring(arg_342_1.damage),
					" (",
					tostring(arg_342_1.health),
					") damage"
				}
			elseif arg_342_1.weapon == "hegrenade" then
				slot_342_9_0 = {
					" Exploded by ",
					tostring(arg_342_1.name),
					" for ",
					tostring(arg_342_1.damage),
					" (",
					tostring(arg_342_1.health),
					") damage"
				}
			elseif arg_342_1.weapon == "taser" then
				slot_342_9_0 = {
					" Тased by ",
					tostring(arg_342_1.name)
				}
			else
				slot_342_9_0 = {
					" Hurt by ",
					tostring(arg_342_1.name),
					" in ",
					tostring(slot_0_6_0.player_hitbox[arg_342_1.hitgroup]),
					" for ",
					tostring(arg_342_1.damage),
					" (",
					tostring(arg_342_1.health),
					") damage"
				}
			end

			for iter_342_1 = 1, #slot_342_9_0 do
				table.insert(slot_342_8_0, {
					slot_342_9_0[iter_342_1],
					iter_342_1 % 2 == 1 and slot_342_5_0 or slot_342_4_0,
					add_y = slot_342_7_0
				})
			end

			table.insert(slot_0_4_0.vars.rage_logs.list, {
				alpha = 0,
				text = slot_342_8_0,
				time = slot_0_6_0.real_time,
				accent = slot_342_4_0
			})
		end
	end,
	add_world_marker = function(arg_343_0)
		local var_343_0 = slot_0_4_0.vars.world_marker

		if var_343_0.last_time ~= slot_0_6_0.real_time then
			var_343_0.last_time = slot_0_6_0.real_time
			var_343_0.last_counter = 0
		else
			var_343_0.last_counter = var_343_0.last_counter + 1
		end

		table.insert(var_343_0.list, {
			alpha = 0,
			pos = arg_343_0,
			time = slot_0_6_0.real_time
		})

		if #var_343_0.list > 4 then
			for iter_343_0 = 1, #var_343_0.list - 4 do
				var_343_0.list[iter_343_0].time = 0
			end
		end
	end,
	add_damage_marker = function(arg_344_0, arg_344_1)
		if not slot_0_13_0.visuals.world_marker.settings:get("Damage") then
			return
		end

		local var_344_0 = slot_0_4_0.vars.damage_markers

		arg_344_0 = slot_0_11_0(arg_344_0.x + (math.random(0, 1) == 0 and -1 or 1) * math.random(5, 26), arg_344_0.y + (math.random(0, 1) == 0 and -1 or 1) * math.random(5, 26), arg_344_0.z + math.random(-12, 55))

		table.insert(var_344_0, {
			alpha = 0,
			pos = arg_344_0,
			time = slot_0_6_0.real_time,
			damage = arg_344_1 or -1,
			offset = slot_0_11_0(0, 0)
		})

		if #var_344_0 > 4 then
			for iter_344_0 = 1, #var_344_0 - 4 do
				var_344_0[iter_344_0].time = 0
			end
		end
	end,
	add_buy_log = function(arg_345_0, arg_345_1)
		if not (slot_0_13_0.ui.widgets.settings:get("Notify: Buy logs") or slot_0_13_0.ui.widgets.settings:get("Rage logs: Buy logs")) then
			return
		end

		local var_345_0 = slot_0_4_0.vars.buy_logs
		local var_345_1

		if slot_0_6_0.weapon_name_to_font[arg_345_1] then
			var_345_1 = slot_0_6_0.weapon_name_to_font[arg_345_1]
		end

		if var_345_0[arg_345_0] and var_345_0[arg_345_0].time + 8 < slot_0_6_0.real_time then
			var_345_0[arg_345_0] = {}
		end

		var_345_0[arg_345_0] = var_345_0[arg_345_0] or {}
		var_345_0[arg_345_0].time = slot_0_6_0.real_time
		var_345_0[arg_345_0].items = var_345_0[arg_345_0].items or {
			text = "",
			icons = ""
		}

		if not string.find(var_345_0[arg_345_0].items.text, arg_345_1) then
			var_345_0[arg_345_0].items.text = var_345_0[arg_345_0].items.text .. arg_345_1 .. " "
			var_345_0[arg_345_0].items.icons = var_345_0[arg_345_0].items.icons .. (var_345_1 or slot_0_3_0.get_icon("coins"))
		end

		if slot_0_13_0.ui.widgets.settings:get("Notify: Buy logs") then
			local var_345_2 = slot_0_13_0.ui.widgets.rage_logs.visual.buy:get()

			slot_0_3_0.notify({
				{
					string.format("%s bought: ", arg_345_0)
				},
				{
					tostring(var_345_0[arg_345_0].items.icons),
					var_345_2,
					icon = true,
					icon_font = slot_0_18_0.icons.cs_go14,
					add_y = slot_0_18_0.offset.icons.cs_go14 / 2
				}
			}, {
				id = string.format("purchase:%s", arg_345_0)
			}, slot_0_3_0.make_notify_style(slot_0_3_0.get_icon("coins"), var_345_2, "fast_blur", true))
		end
	end,
	global = {
		physic_text = function()
			local var_346_0 = slot_0_4_0.vars.physic_text_params

			if not var_346_0.enabled then
				return
			end

			local var_346_1 = -1
			local var_346_2 = var_346_0.accent or slot_0_12_0()

			for iter_346_0 = 1, #slot_0_4_0.vars.physic_text do
				local var_346_3 = slot_0_4_0.vars.physic_text[iter_346_0]
				local var_346_4 = math.world_to_screen(var_346_3.pos)
				local var_346_5 = var_346_3.time + 1 > slot_0_6_0.real_time

				var_346_3.alpha = math.bounded_lerp(var_346_3.alpha, 0, 1, var_346_5 and 5 or 1, var_346_5)

				if slot_0_3_0.on_screen(var_346_4) then
					slot_0_3_0.physic_text(var_346_3.info, slot_0_18_0.verdanab, var_346_4, var_346_2:a(var_346_2:get_a() / 255 * var_346_3.alpha), var_346_0.style)
				end

				if not var_346_5 and var_346_3.alpha <= 0.02 then
					var_346_1 = iter_346_0
				end
			end

			if var_346_1 ~= -1 then
				table.remove(slot_0_4_0.vars.physic_text, var_346_1)
			end
		end,
		watermark = function(arg_347_0)
			local var_347_0 = slot_0_4_0.vars.watermark
			local var_347_1 = slot_0_13_0.ui.widgets.watermark.settings

			if not var_347_0.enabled and var_347_0.alpha == 0 then
				return
			end

			local var_347_2 = slot_0_13_0.ui.widgets
			local var_347_3 = slot_0_4_0.vars.widgets
			local var_347_4 = var_347_3.background
			local var_347_5 = var_347_3.accent

			if not var_347_4.a or not var_347_5.a then
				return
			end

			local var_347_6 = slot_0_14_0:get("get_watermark_text", var_347_0, var_347_3)

			if not var_347_6 then
				return
			end

			local var_347_7 = var_347_6.text
			local var_347_8 = var_347_6.t_size

			if not var_347_7 or not var_347_8 then
				return
			end

			local var_347_9 = var_347_8 + var_347_0.padding * 2

			var_347_0.width = math.lerp(var_347_0.width, var_347_9, slot_0_6_0.frame_time * 6)

			if math.abs(var_347_9 - var_347_0.width) < 1 then
				var_347_0.width = var_347_9
			end

			local var_347_10 = slot_0_26_0.get("watermark")
			local var_347_11 = var_347_0.width
			local var_347_12 = slot_0_18_0.offset.alata_main + var_347_0.padding * 2
			local var_347_13 = slot_0_11_0(var_347_10.x + var_347_11, var_347_10.y + var_347_12)
			local var_347_14 = math.abs(slot_0_6_0.screen_size.x / 2 - var_347_10.x) <= 300 and var_347_0.width / 2 or var_347_10.x < slot_0_6_0.screen_size.x / 2 and 0 or var_347_0.width

			var_347_10.x = var_347_10.x - var_347_14
			var_347_13.x = var_347_13.x - var_347_14

			slot_0_3_0.shadow(var_347_10, var_347_13, var_347_5:a(var_347_5:get_a() * 0.3 / 255), 6, 5, 2)
			slot_0_3_0.shader_rounded("blur_low", var_347_10, var_347_13, 5, 1)
			slot_0_3_0.rect(var_347_10, var_347_13, var_347_4, 5)
			slot_0_3_0.push_clip_rect(var_347_10, var_347_13)
			slot_0_3_0.multi_text(var_347_7, slot_0_18_0.alata_main, slot_0_11_0(var_347_10.x + var_347_0.padding, var_347_10.y + var_347_0.padding), slot_0_18_0.icons.mercury, 1)
			slot_0_3_0.pop_clip_rect()

			var_347_10.x = var_347_10.x + var_347_14
			var_347_13.x = var_347_13.x + var_347_14

			slot_0_26_0.move("watermark", var_347_11, var_347_12, slot_0_11_0(-var_347_14, 0), 5)
		end,
		key_binds = function(arg_348_0)
			slot_348_1_0 = slot_0_4_0.vars.keybinds

			if not slot_348_1_0.enabled and slot_348_1_0.alpha == 0 then
				return
			end

			slot_348_2_0 = slot_0_13_0.ui.widgets
			slot_348_3_1 = slot_0_4_0.vars.widgets.background
			slot_348_4_0 = slot_0_4_0.vars.widgets.accent

			if not slot_348_3_1.a or not slot_348_4_0.a then
				return
			end

			slot_348_5_0 = slot_0_26_0.get("keybinds")
			slot_348_6_0 = slot_0_11_0(slot_348_5_0.x + slot_348_1_0.width, slot_348_5_0.y + slot_0_18_0.offset.alata_main + slot_348_1_0.padding * 2 - 2)
			slot_348_1_0.alpha = math.bounded_lerp(slot_348_1_0.alpha, 0, 1, 4, slot_348_1_0.enabled and (slot_348_1_0.height ~= 0 or slot_0_6_0.menu_visible))
			slot_348_7_0 = slot_348_1_0.alpha
			slot_348_8_1 = 30

			if slot_348_7_0 > 0 then
				slot_0_3_0.shadow(slot_348_5_0, slot_0_11_0(slot_348_6_0.x, slot_348_6_0.y + slot_348_1_0.height + slot_348_1_0.padding), slot_348_4_0:a(slot_348_4_0:get_a() * 0.3 / 255 * math.min(1, slot_348_7_0^2)), 6, 5, 2)
				slot_0_3_0.shader_rounded("blur_medium", slot_348_5_0, slot_0_11_0(slot_348_6_0.x, slot_348_6_0.y + slot_348_1_0.height + slot_348_1_0.padding), 5, slot_348_7_0)

				slot_348_3_0 = slot_348_3_1:a(slot_348_3_1:get_a() / 255 * slot_348_7_0)

				if slot_348_1_0.solid_style then
					slot_0_3_0.rect(slot_348_5_0, slot_0_11_0(slot_348_6_0.x + 1, slot_348_6_0.y + slot_348_1_0.height + slot_348_1_0.padding), slot_348_3_0, 5)
					slot_0_3_0.line(nil, slot_0_11_0(slot_348_5_0.x + slot_348_1_0.padding, slot_348_6_0.y), slot_0_11_0(slot_348_6_0.x - slot_348_1_0.padding, slot_348_6_0.y), slot_348_4_0:a(0.8 * slot_348_7_0))
				else
					slot_0_3_0.rect(slot_348_5_0, slot_0_11_0(slot_348_6_0.x + 1, slot_348_6_0.y), slot_348_3_0, 5)
				end

				slot_348_8_1 = slot_0_3_0.get_multi_text_size(slot_348_1_0.title, slot_0_18_0.alata_main, slot_0_18_0.icons.mercury_bold)

				slot_0_3_0.multi_text(slot_348_1_0.title, slot_0_18_0.alata_main, slot_0_11_0(slot_348_5_0.x + (slot_348_1_0.width / 2 - slot_348_8_1 / 2), slot_348_5_0.y + slot_348_1_0.padding - 1), slot_0_18_0.icons.mercury_bold, slot_348_7_0)
				slot_0_26_0.move("keybinds", slot_348_1_0.width, slot_0_18_0.offset.alata_main + slot_348_1_0.padding * 3 + slot_348_1_0.height, nil, 10)
			end

			slot_348_8_0 = slot_348_8_1 + 45
			slot_348_5_0.y = slot_348_5_0.y + slot_0_18_0.offset.alata_main + slot_348_1_0.padding * 2

			slot_0_3_0.push_clip_rect(slot_348_5_0, slot_0_11_0(slot_348_6_0.x, slot_348_5_0.y + slot_348_1_0.height))

			slot_348_1_0.height = slot_348_5_0.y
			slot_348_9_0 = slot_0_14_0:get("active_hotkeys")

			if slot_348_9_0 then
				for iter_348_0 = 1, #slot_348_9_0 do
					slot_348_14_0 = slot_348_9_0[iter_348_0]
					slot_348_14_0.alpha = math.bounded_lerp(slot_348_14_0.alpha or 0, 0, 1, 6, slot_348_14_0.is_active)

					if slot_348_14_0.alpha > 0 then
						slot_0_3_0.text(math.text_by_alpha(slot_348_14_0.title or "", slot_348_14_0.alpha), slot_0_18_0.keybinds, slot_0_11_0(slot_348_5_0.x + slot_348_1_0.padding * slot_348_14_0.alpha, slot_348_5_0.y), slot_0_12_0(255, 255 * slot_348_14_0.alpha * slot_348_7_0))

						slot_348_15_0 = math.text_by_alpha(slot_348_14_0.state or "", slot_348_14_0.alpha, true)

						slot_0_3_0.text(slot_348_15_0, slot_0_18_0.keybinds, slot_0_11_0(slot_348_5_0.x + slot_348_1_0.width - slot_348_1_0.padding * slot_348_14_0.alpha - slot_0_3_0.text_size(slot_348_15_0, slot_0_18_0.keybinds).x, slot_348_5_0.y), slot_0_12_0(255, 180 * slot_348_14_0.alpha * slot_348_7_0))

						if slot_348_14_0.is_active then
							slot_348_8_0 = math.max(slot_348_8_0, slot_0_3_0.text_size(slot_348_15_0 .. " " .. slot_348_14_0.title, slot_0_18_0.keybinds).x + slot_348_1_0.padding * 2 + 10)
						end

						slot_348_5_0.y = slot_348_5_0.y + (slot_0_18_0.offset.keybinds + slot_0_18_0.offset.global + 4) * slot_348_14_0.alpha
					end
				end
			end

			slot_348_1_0.height = slot_348_5_0.y - slot_348_1_0.height

			slot_0_3_0.pop_clip_rect(slot_348_5_0, slot_348_6_0)

			slot_348_1_0.width = math.lerp(slot_348_1_0.width, slot_348_8_0, slot_0_6_0.frame_time * 6)
		end,
		crosshair_indicator = function()
			slot_349_0_0 = slot_0_4_0.vars.crosshair_indicator

			if not slot_349_0_0.enabled and slot_349_0_0.alpha == 0 then
				return
			end

			slot_349_1_0 = entities.get_local_pawn()
			slot_349_2_0 = slot_0_26_0.get("crosshair_indicator")
			slot_349_3_0 = slot_349_0_0.title_size
			slot_349_0_0.alpha = math.bounded_lerp(slot_349_0_0.alpha, 0, 1, 4, game.engine:in_game() and slot_349_0_0.enabled or slot_349_0_0.enabled and slot_0_6_0.menu_visible)
			slot_349_4_0 = slot_349_0_0.alpha
			slot_349_5_0 = slot_349_0_0.accent or slot_0_12_0(170, 159, 255)
			slot_349_6_0 = slot_349_0_0.background or slot_0_12_0(60, 255)

			slot_0_3_0.shadow(slot_0_11_0(slot_349_2_0.x + 2, slot_349_2_0.y + slot_349_3_0.y / 2 - 3), slot_0_11_0(slot_349_2_0.x + slot_349_3_0.x - 2, slot_349_2_0.y + slot_349_3_0.y / 2), slot_349_5_0:a(0.2 * slot_349_4_0), 7, 3, 2)
			slot_0_3_0.text_bold_outline("mercury", slot_0_18_0.verdanab, slot_349_2_0, slot_0_12_0(0, slot_349_6_0:get_a() * slot_349_4_0))
			slot_0_3_0.text_enchanted("mercury", slot_0_18_0.verdanab, slot_349_2_0, slot_349_6_0:a(slot_349_4_0), slot_349_5_0:a(slot_349_4_0), 1.3, true)

			slot_349_2_0.y = slot_349_2_0.y + slot_349_3_0.y - 1
			slot_349_7_0 = slot_0_14_0:get("get_condition", slot_349_1_0) or "dead"
			slot_349_7_0 = slot_349_7_0 == "crouch_air" and "air" or slot_349_7_0
			slot_349_8_0 = "~" .. math.text_by_alpha(slot_349_0_0.condition.current or "", slot_349_0_0.condition.progress or 1) .. "~"
			slot_349_9_0 = slot_0_3_0.text_size(slot_349_8_0, slot_0_18_0.veradnab_mini)
			slot_349_0_0.condition.progress = math.bounded_lerp(slot_349_0_0.condition.progress, 0, 1, 10, slot_349_7_0 == slot_349_0_0.condition.current)

			if slot_349_0_0.condition.progress == 0 then
				slot_349_0_0.condition.current = slot_349_7_0
			end

			slot_0_3_0.text_outline(slot_349_8_0, slot_0_18_0.veradnab_mini, slot_0_11_0(slot_349_2_0.x + slot_349_3_0.x / 2 - slot_349_9_0.x / 2, slot_349_2_0.y), math.lerp_color(slot_349_6_0, slot_349_5_0, math.abs(math.sin(slot_0_6_0.real_time)) * 0.8):a(slot_349_4_0))

			slot_349_2_0.y = slot_349_2_0.y + slot_349_9_0.y
			slot_349_10_0 = slot_0_14_0:get("active_hotkeys")
			slot_349_11_0 = slot_0_4_0.vars.keybinds.enabled

			if slot_349_10_0 then
				for iter_349_0 = 1, #slot_349_10_0 do
					slot_349_16_0 = slot_349_10_0[iter_349_0]

					if slot_349_16_0.crosshair ~= false then
						if not slot_349_11_0 then
							slot_349_16_0.alpha = math.bounded_lerp(slot_349_16_0.alpha or 0, 0, 1, 6, slot_349_16_0.is_active)
						end

						slot_349_17_0 = slot_349_16_0.crosshair_title and slot_349_16_0.crosshair_desc and slot_349_16_0.crosshair_title .. slot_349_16_0.crosshair_desc or slot_349_16_0.title or ""
						slot_349_18_0 = slot_0_3_0.text_size(slot_349_17_0, slot_0_18_0.veradnab_mini)

						if slot_349_16_0.crosshair_desc then
							slot_349_19_0 = slot_0_3_0.text_size(slot_349_16_0.crosshair_desc, slot_0_18_0.veradnab_mini).x

							slot_0_3_0.text_outline(slot_349_16_0.crosshair_title, slot_0_18_0.veradnab_mini, slot_0_11_0(slot_349_2_0.x + slot_349_3_0.x / 2 - slot_349_18_0.x / 2, slot_349_2_0.y), slot_0_12_0(225, 255 * slot_349_4_0 * slot_349_16_0.alpha))
							slot_0_3_0.text_outline(slot_349_16_0.crosshair_desc, slot_0_18_0.veradnab_mini, slot_0_11_0(slot_349_2_0.x + slot_349_3_0.x / 2 + slot_349_18_0.x / 2 - slot_349_19_0, slot_349_2_0.y), slot_349_5_0:a(slot_349_4_0 * slot_349_16_0.alpha))
						else
							slot_0_3_0.text_outline(slot_349_17_0, slot_0_18_0.veradnab_mini, slot_0_11_0(slot_349_2_0.x + slot_349_3_0.x / 2 - slot_349_18_0.x / 2, slot_349_2_0.y), slot_0_12_0(255, 255 * slot_349_4_0 * slot_349_16_0.alpha))
						end

						slot_349_2_0.y = slot_349_2_0.y + slot_349_18_0.y * slot_349_16_0.alpha
					end
				end
			end

			slot_0_26_0.move("crosshair_indicator", slot_349_3_0.x, slot_349_3_0.y + slot_349_9_0.y, nil, 10)
		end,
		rage_logs = function(arg_350_0)
			slot_350_1_0 = slot_0_4_0.vars.rage_logs

			if not slot_350_1_0.enabled and not (#slot_350_1_0.list > 0) then
				return
			end

			slot_350_2_0 = -1
			slot_350_3_0 = slot_0_26_0.get("rage_logs")
			slot_350_4_0 = slot_0_13_0.ui.widgets.rage_logs
			slot_350_5_0 = slot_350_4_0.visual.background:get()
			slot_350_6_0 = slot_350_4_0.lifetime:get()
			slot_350_7_0 = slot_350_1_0.padding
			slot_350_8_0 = #slot_350_1_0.list

			slot_0_26_0.move("rage_logs", 140, (slot_350_1_0.offset + slot_0_18_0.offset.rage_logs + slot_350_7_0 * 2) * 5, slot_0_11_0(-70, 0), 10)

			slot_350_3_0.y = slot_350_3_0.y + 8
			slot_350_9_0 = math.abs(slot_0_6_0.screen_size.x / 2 - slot_350_3_0.x) <= 300 and 0 or slot_350_3_0.x < slot_0_6_0.screen_size.x / 2 and -1 or 1

			for iter_350_0 = slot_350_8_0, 1, -1 do
				slot_350_14_0 = slot_0_4_0.vars.rage_logs.list[iter_350_0]
				slot_350_15_0 = slot_350_14_0.time + slot_350_6_0 > slot_0_6_0.real_time and slot_350_8_0 - iter_350_0 < 5
				slot_350_14_0.alpha = math.bounded_lerp(slot_350_14_0.alpha, 0, 1, 3, slot_350_15_0)

				if slot_350_14_0.alpha > 0 then
					slot_350_16_0 = slot_0_3_0.get_multi_text_size(slot_350_14_0.text, slot_0_18_0.rage_logs, slot_0_18_0.icons.mercury)
					slot_350_17_0 = slot_350_9_0 ~= 0 and slot_350_9_0 * -(slot_350_16_0 - 140) or 0
					slot_350_18_0 = slot_0_11_0(slot_350_3_0.x - (slot_350_16_0 - slot_350_17_0) / 2 - slot_350_7_0, slot_350_3_0.y - slot_350_7_0)
					slot_350_19_0 = slot_0_11_0(slot_350_3_0.x + (slot_350_16_0 + slot_350_17_0) / 2 + slot_350_7_0, slot_350_3_0.y + slot_0_18_0.offset.rage_logs + slot_350_7_0)

					if slot_350_1_0.display.glow and not slot_350_1_0.display.blur and not slot_350_1_0.display.background and not slot_350_1_0.display.outline then
						slot_0_3_0.glow(slot_0_11_0(slot_350_3_0.x - (slot_350_16_0 - slot_350_17_0) / 2 + 4, slot_350_3_0.y + 5), slot_0_11_0(slot_350_3_0.x + (slot_350_16_0 + slot_350_17_0) / 2 - 4, slot_350_3_0.y + 5), slot_350_14_0.accent:a(0.33 * slot_350_14_0.alpha), 10)
					elseif slot_350_1_0.display.glow then
						slot_0_3_0.shadow(slot_350_18_0, slot_350_19_0, slot_350_14_0.accent:a(0.08 * slot_350_14_0.alpha), 7, 5, 2)
					end

					if slot_350_1_0.display.blur then
						slot_0_3_0.shader_rounded("blur_low", slot_350_18_0, slot_350_19_0, 5, slot_350_14_0.alpha)

						if slot_350_1_0.display.background then
							slot_0_3_0.rect(slot_350_18_0, slot_350_19_0, slot_350_5_0:a(slot_350_5_0:get_a() / 255 * slot_350_14_0.alpha), 5)
						end
					elseif slot_350_1_0.display.background then
						slot_0_3_0.rect(slot_350_18_0, slot_350_19_0, slot_350_5_0:a(slot_350_5_0:get_a() / 255 * slot_350_14_0.alpha), 5)
					end

					if slot_350_1_0.display.outline then
						slot_0_3_0.rect(slot_350_18_0, slot_350_19_0, slot_350_14_0.accent:a(0.5 * slot_350_14_0.alpha), 5, true)
					end

					slot_0_3_0.multi_text(slot_350_14_0.text, slot_0_18_0.rage_logs, slot_0_11_0(slot_350_3_0.x - (slot_350_16_0 - slot_350_17_0) / 2, slot_350_3_0.y + 1), slot_0_18_0.icons.mercury, slot_350_14_0.alpha)

					slot_350_3_0.y = slot_350_3_0.y + (slot_350_1_0.offset + slot_0_18_0.offset.rage_logs + slot_350_7_0 * 2) * slot_350_14_0.alpha
				else
					slot_350_2_0 = iter_350_0
				end
			end

			if slot_350_2_0 ~= -1 then
				table.remove(slot_350_1_0.list, slot_350_2_0)
			end
		end,
		buy_log_handler = function()
			if not slot_0_13_0.ui.widgets.settings:get("Rage logs: Buy logs") then
				return
			end

			local var_351_0 = slot_0_4_0.vars.buy_logs

			for iter_351_0, iter_351_1 in pairs(var_351_0) do
				if iter_351_1.time + 2 < slot_0_6_0.real_time then
					local var_351_1 = slot_0_13_0.ui.widgets.rage_logs.visual.buy:get()

					table.insert(slot_0_4_0.vars.rage_logs.list, {
						alpha = 0,
						text = {
							{
								slot_0_3_0.get_icon("coins"),
								var_351_1,
								icon = true,
								add_y = slot_0_18_0.offset.icons.mercury / 2 - 3
							},
							{
								string.format(" %s bought: ", iter_351_0),
								add_y = slot_0_18_0.offset.global
							},
							{
								tostring(iter_351_1.items.icons),
								var_351_1,
								icon = true,
								icon_font = slot_0_18_0.icons.cs_go14,
								add_y = slot_0_18_0.offset.icons.cs_go14 / 2
							}
						},
						time = slot_0_6_0.real_time,
						accent = var_351_1
					})
					slot_0_3_0.colored_print({
						{
							"[Buy] ",
							var_351_1
						},
						{
							string.format("%s bought: [ ", iter_351_0),
							slot_0_12_0()
						},
						{
							tostring(iter_351_1.items.text),
							var_351_1
						},
						{
							"]",
							slot_0_12_0()
						}
					})

					var_351_0[iter_351_0] = nil
				end
			end
		end,
		world_marker = function()
			slot_352_0_0 = slot_0_4_0.vars.world_marker

			if slot_352_0_0.enabled and slot_352_0_0.life_time and #slot_352_0_0.list == 0 then
				return
			end

			slot_352_1_0 = draw.surface
			slot_352_2_0 = -1
			slot_352_3_0 = slot_352_0_0.life_time
			slot_352_4_0 = slot_352_0_0.offset
			slot_352_5_0 = slot_352_0_0.length
			slot_352_6_0 = slot_352_0_0.color_first
			slot_352_7_0 = slot_352_0_0.color_second
			slot_352_8_0 = slot_352_0_0.horizontal

			for iter_352_0 = 1, #slot_352_0_0.list do
				slot_352_13_0 = slot_352_0_0.list[iter_352_0]

				if slot_352_13_0.pos then
					slot_352_14_0 = slot_352_3_0 + slot_352_13_0.time > slot_0_6_0.real_time
					slot_352_13_0.alpha = math.bounded_lerp(slot_352_13_0.alpha or 0, 0, 1, 3, slot_352_14_0)
					slot_352_15_0 = math.world_to_screen(slot_352_13_0.pos)

					if slot_0_3_0.on_screen(slot_352_15_0, slot_352_4_0) then
						slot_352_16_0 = slot_352_13_0.alpha
						slot_352_17_0 = slot_352_6_0:a(math.min(1, slot_352_6_0:get_a() / 255 * slot_352_16_0 + 0.05))
						slot_352_18_0 = slot_352_7_0:a(math.min(1, slot_352_7_0:get_a() / 255 * slot_352_16_0 + 0.05))
						slot_352_19_0 = slot_352_4_0 * slot_352_16_0 + slot_352_5_0 * (1 - slot_352_16_0)
						slot_352_20_0 = slot_352_5_0

						if slot_352_8_0 then
							slot_0_3_0.line(slot_352_1_0, slot_0_11_0(slot_352_15_0.x + slot_352_19_0, slot_352_15_0.y), slot_0_11_0(slot_352_15_0.x + slot_352_20_0, slot_352_15_0.y), slot_352_17_0, slot_352_18_0)
							slot_0_3_0.line(slot_352_1_0, slot_0_11_0(slot_352_15_0.x, slot_352_15_0.y + slot_352_19_0), slot_0_11_0(slot_352_15_0.x, slot_352_15_0.y + slot_352_20_0), slot_352_17_0, slot_352_18_0)
							slot_0_3_0.line(slot_352_1_0, slot_0_11_0(slot_352_15_0.x - slot_352_19_0, slot_352_15_0.y), slot_0_11_0(slot_352_15_0.x - slot_352_20_0, slot_352_15_0.y), slot_352_17_0, slot_352_18_0)
							slot_0_3_0.line(slot_352_1_0, slot_0_11_0(slot_352_15_0.x, slot_352_15_0.y - slot_352_19_0), slot_0_11_0(slot_352_15_0.x, slot_352_15_0.y - slot_352_20_0), slot_352_17_0, slot_352_18_0)
						else
							slot_0_3_0.line(slot_352_1_0, slot_0_11_0(slot_352_15_0.x + slot_352_19_0, slot_352_15_0.y + slot_352_19_0), slot_0_11_0(slot_352_15_0.x + slot_352_20_0, slot_352_15_0.y + slot_352_20_0), slot_352_17_0, slot_352_18_0)
							slot_0_3_0.line(slot_352_1_0, slot_0_11_0(slot_352_15_0.x - slot_352_19_0, slot_352_15_0.y - slot_352_19_0), slot_0_11_0(slot_352_15_0.x - slot_352_20_0, slot_352_15_0.y - slot_352_20_0), slot_352_17_0, slot_352_18_0)
							slot_0_3_0.line(slot_352_1_0, slot_0_11_0(slot_352_15_0.x + slot_352_19_0, slot_352_15_0.y - slot_352_19_0), slot_0_11_0(slot_352_15_0.x + slot_352_20_0, slot_352_15_0.y - slot_352_20_0), slot_352_17_0, slot_352_18_0)
							slot_0_3_0.line(slot_352_1_0, slot_0_11_0(slot_352_15_0.x - slot_352_19_0, slot_352_15_0.y + slot_352_19_0), slot_0_11_0(slot_352_15_0.x - slot_352_20_0, slot_352_15_0.y + slot_352_20_0), slot_352_17_0, slot_352_18_0)
						end

						if slot_352_16_0 == 0 then
							slot_352_2_0 = iter_352_0
						end
					end
				end
			end

			if slot_352_2_0 ~= -1 then
				table.remove(slot_352_0_0.list, slot_352_2_0)
			end
		end,
		damage_marker = function()
			if slot_0_13_0.visuals.world_marker.settings:get("Damage") and #slot_0_4_0.vars.damage_markers == 0 then
				return
			end

			local var_353_0 = -1
			local var_353_1 = slot_0_13_0.visuals.world_marker.damage
			local var_353_2 = var_353_1.params.color:get()
			local var_353_3 = var_353_1.params.lifetime:get()
			local var_353_4 = slot_0_13_0.visuals.world_marker.settings:get(" > Damage: simple style")

			for iter_353_0 = 1, #slot_0_4_0.vars.damage_markers do
				local var_353_5 = slot_0_4_0.vars.damage_markers[iter_353_0]

				if var_353_5.pos then
					local var_353_6 = math.world_to_screen(var_353_5.pos)
					local var_353_7 = var_353_3 + var_353_5.time > slot_0_6_0.real_time

					var_353_5.alpha = math.bounded_lerp(var_353_5.alpha or 0, 0, 1, 1.5, var_353_7)

					if slot_0_3_0.on_screen(var_353_6) then
						local var_353_8 = var_353_5.alpha

						if var_353_4 then
							slot_0_3_0.text_outline(tostring(var_353_5.damage or 0), slot_0_18_0.rage_logs, slot_0_11_0(var_353_6.x + var_353_5.offset.x, var_353_6.y - var_353_5.offset.y), var_353_2:a(var_353_8))
						else
							slot_0_3_0.text_fatality(tostring(var_353_5.damage or 0), slot_0_18_0.rage_logs, slot_0_11_0(var_353_6.x + var_353_5.offset.x, var_353_6.y - var_353_5.offset.y), var_353_2:a(var_353_8), 1)
						end

						if var_353_8 == 0 then
							var_353_0 = iter_353_0
						end
					end
				end
			end

			if var_353_0 ~= -1 then
				table.remove(slot_0_4_0.vars.damage_markers, var_353_0)
			end
		end,
		velocity_modifier = function()
			slot_354_0_0 = slot_0_13_0.ui.widgets
			slot_354_1_0 = slot_354_0_0.settings:get("Velocity modifier")
			slot_354_2_0 = entities.get_local_pawn()
			slot_354_3_0 = slot_0_4_0.vars.velocity_modifier

			if slot_354_3_0.alpha == 0 and not slot_354_1_0 then
				return
			end

			slot_354_4_0 = slot_354_3_0.modifier

			if slot_354_2_0 then
				slot_354_5_1 = slot_354_2_0.m_flVelocityModifier:get() or 1

				if not slot_354_5_1 or slot_354_5_1 == 1 then
					if slot_0_6_0.menu_visible then
						slot_354_3_0.modifier = slot_354_3_0.modifier + slot_0_6_0.frame_time * 0.1

						if slot_354_3_0.modifier > 0.95 then
							slot_354_3_0.modifier = 0
						end
					else
						slot_354_3_0.modifier = slot_354_5_1 or 1
					end
				else
					slot_354_3_0.modifier = slot_354_5_1 or 1
				end
			elseif slot_0_6_0.menu_visible then
				slot_354_3_0.modifier = slot_354_3_0.modifier + slot_0_6_0.frame_time

				if slot_354_3_0.modifier > 0.95 then
					slot_354_3_0.modifier = 0
				end
			end

			slot_354_3_0.value = math.lerp(slot_354_3_0.value, slot_354_1_0 and slot_354_4_0 or 1, slot_0_6_0.frame_time * 5)
			slot_354_3_0.value = math.clamp(slot_354_3_0.value, 0.05, 1)
			slot_354_3_0.alpha = math.bounded_lerp(slot_354_3_0.alpha, 0, 1, 5, slot_354_3_0.value <= 0.98)
			slot_354_5_0 = slot_354_3_0.alpha

			if slot_354_5_0 > 0 then
				slot_354_6_1 = 140
				slot_354_7_0 = 4
				slot_354_8_0 = slot_0_26_0.get("velocity_modifier")

				slot_0_26_0.move("velocity_modifier", slot_354_6_1, slot_354_7_0 + slot_0_18_0.offset.verdana, nil, 5)

				slot_354_9_0 = slot_0_11_0(slot_354_8_0.x + slot_354_6_1, slot_354_8_0.y + slot_354_7_0 + 11)
				slot_354_10_0 = slot_0_11_0(slot_354_8_0.x + slot_354_6_1 / 2, slot_354_8_0.y + slot_354_7_0 / 2 + 10 * slot_354_5_0)
				slot_354_6_0 = slot_354_6_1 * slot_354_5_0
				slot_354_11_0 = slot_354_0_0.velocity_modifier.visual.first:get()
				slot_354_12_0 = slot_354_0_0.velocity_modifier.visual.second:get()
				slot_354_13_0 = math.lerp_color(slot_354_11_0, slot_354_12_0, slot_354_3_0.value)
				slot_354_14_0 = math.text_by_alpha("Velocity modifier", slot_354_5_0)
				slot_354_15_0 = slot_0_3_0.text_size(slot_354_14_0, slot_0_18_0.static.alata_11)

				slot_0_3_0.text_outline(slot_354_14_0, slot_0_18_0.static.alata_11, slot_0_11_0(slot_354_10_0.x - slot_354_15_0.x / 2, slot_354_10_0.y - slot_354_15_0.y - 8), slot_0_12_0(255, 255 * slot_354_5_0))

				slot_354_16_0 = slot_0_11_0(slot_354_10_0.x - slot_354_6_0 / 2, slot_354_10_0.y - slot_354_7_0 / 2)
				slot_354_17_0 = slot_0_11_0(slot_354_10_0.x + slot_354_6_0 / 2, slot_354_10_0.y + slot_354_7_0 / 2)

				slot_0_3_0.shadow(slot_354_16_0, slot_354_17_0, slot_354_13_0:a(0.07 * slot_354_5_0), 6, 0, 2)
				slot_354_3_0.render_round2(slot_354_16_0, slot_354_17_0, slot_0_12_0(31, 100 * slot_354_5_0))
				slot_354_3_0.render_round2(slot_354_16_0, slot_0_11_0(slot_354_10_0.x - slot_354_6_0 / 2 + slot_354_6_0 * slot_354_3_0.value, slot_354_10_0.y + slot_354_7_0 / 2), slot_354_13_0:a(slot_354_5_0))
			end
		end,
		manuals_indicator = function()
			if not game.engine:in_game() then
				return
			end

			if not slot_0_13_0.ui.widgets.settings:get("Manuals indicator") then
				return
			end

			local var_355_0 = slot_0_5_0.vars.freestand
			local var_355_1 = slot_0_4_0.vars.manuals_ind
			local var_355_2 = var_355_1.left:get_value():get() and "left" or var_355_1.right:get_value():get() and "right" or var_355_0.active and (var_355_0.side == -1 and "left" or var_355_0.side == 1 and "right") or "none"
			local var_355_3 = var_355_2 ~= "none"

			if var_355_3 then
				var_355_1.side = var_355_2
			end

			var_355_1.alpha = math.bounded_lerp(var_355_1.alpha, 0, 1, 5, var_355_3)

			local var_355_4 = slot_0_13_0.ui.widgets.manuals_indicator
			local var_355_5 = var_355_4.visual.first:get()
			local var_355_6 = var_355_4.visual.second:get()

			if var_355_1.alpha > 0 then
				local var_355_7 = entities.get_local_pawn()

				var_355_1.offset = math.bounded_lerp(var_355_1.offset, 0, 1, 5, var_355_7 and var_355_7.m_bIsScoped and var_355_7.m_bIsScoped:get())

				local var_355_8 = slot_0_11_0(slot_0_6_0.screen_size.x / 2, slot_0_6_0.screen_size.y / 2 + 15 * var_355_1.offset)
				local var_355_9 = 60 + 10 * var_355_1.alpha
				local var_355_10 = 12

				slot_0_3_0.arrow(slot_0_11_0(var_355_8.x - var_355_9, var_355_8.y), var_355_1.side == "left" and var_355_5:a(var_355_1.alpha) or var_355_6:a(var_355_1.alpha), -14, 7, -3)
				slot_0_3_0.arrow(slot_0_11_0(var_355_8.x + var_355_9, var_355_8.y), var_355_1.side == "right" and var_355_5:a(var_355_1.alpha) or var_355_6:a(var_355_1.alpha), 14, 7, 3)
			end
		end,
		molotov_radius = function()
			return
		end
	}
}

slot_0_13_0.ui.widgets.watermark.settings:element():add_callback(function()
	local var_357_0 = slot_0_13_0.ui.widgets.watermark.settings

	slot_0_4_0.vars.watermark.use_icons = var_357_0:get("Icons")
	slot_0_4_0.vars.watermark.use_title = var_357_0:get("Title")

	for iter_357_0 = 1, #slot_0_4_0.vars.watermark.text do
		slot_0_4_0.vars.watermark.text[iter_357_0] = slot_0_4_0.vars.watermark.text[iter_357_0] or {}
		slot_0_4_0.vars.watermark.text[iter_357_0].enabled = var_357_0:get(iter_357_0 + 2)
	end
end)
slot_0_13_0.ui.widgets.settings:element():add_callback(function()
	slot_0_4_0.vars.keybinds.solid_style = slot_0_13_0.ui.widgets.settings:get(" > Hotkeys: solid style")
	slot_0_4_0.vars.keybinds.legit_enabled = slot_0_13_0.ui.widgets.settings:get(" > Hotkeys: legit binds")
	slot_0_4_0.vars.keybinds.enabled = slot_0_13_0.ui.widgets.settings:get("Hotkeys")
	slot_0_4_0.vars.watermark.enabled = slot_0_13_0.ui.widgets.settings:get("Watermark")
	slot_0_4_0.vars.rage_logs.enabled = slot_0_13_0.ui.widgets.settings:get("Rage logs") or slot_0_13_0.ui.widgets.settings:get("Rage logs: Buy logs")
	slot_0_4_0.vars.crosshair_indicator.enabled = slot_0_13_0.ui.widgets.settings:get("Crosshair indicator")
end)
slot_0_13_0.ui.widgets.rage_logs.display:element():add_callback(function()
	slot_0_4_0.vars.rage_logs.updater()
end)

slot_0_31_0 = {}
slot_0_31_0 = {
	vars = {
		slot_0_13_0.misc.global:element():add_callback(function()
			local var_360_0 = slot_0_31_0.vars

			var_360_0.knife_hand_enabled = slot_0_13_0.misc.global:get("Knife left hand")
			var_360_0.jumpbug = slot_0_13_0.misc.global:get("Jumpbug: auto")
			var_360_0.fast_ladder = slot_0_13_0.misc.global:get("Fast ladder")
		end),
		knife_switched = false,
		jumpbug = false,
		jump_scout = {
			old_p = -1,
			active = false,
			old_h = -1,
			slot_0_13_0.misc.jump_scout.settings:element():add_callback(function()
				local var_361_0 = gui.ctx:find("rage>weapon>SSG-08>weapon>hitchance") or gui.ctx:find("rage>weapon>Bolt Snipers>weapon>hitchance")

				if var_361_0 then
					slot_0_31_0.vars.jump_scout.old_h = var_361_0:get_value():get_direct()
				end

				local var_361_1 = gui.ctx:find("rage>weapon>SSG-08>weapon>pointscale") or gui.ctx:find("rage>weapon>Bolt Snipers>weapon>pointscale")

				if var_361_1 then
					slot_0_31_0.vars.jump_scout.old_p = var_361_1:get_value():get_direct()
				end
			end)
		}
	},
	in_game = {
		knife_left_hand = function(arg_362_0)
			if not slot_0_31_0.vars.knife_hand_enabled or not arg_362_0 then
				return
			end

			local var_362_0 = arg_362_0:get_active_weapon()

			if not var_362_0 then
				return
			end

			local var_362_1 = var_362_0:get_type()

			if var_362_1 == 0 and not slot_0_31_0.vars.knife_switched then
				slot_0_31_0.vars.knife_switched = true

				game.engine:client_cmd("switchhandsleft")
			elseif var_362_1 ~= 0 and slot_0_31_0.vars.knife_switched then
				slot_0_31_0.vars.knife_switched = false

				game.engine:client_cmd("switchhandsright")
			end
		end,
		jump_scout = function(arg_363_0)
			slot_363_1_0 = slot_0_13_0.misc.jump_scout

			if not slot_0_15_0.temp["jump_scout-autostop-mode"] then
				if not slot_0_15_0.temp.jump_scout_cached then
					slot_0_15_0.temp["jump_scout-hitchance"] = gui.ctx:find("rage>weapon>SSG-08>weapon>hitchance") or gui.ctx:find("rage>weapon>Bolt Snipers>weapon>hitchance")
					slot_0_15_0.temp["jump_scout-pointscale"] = gui.ctx:find("rage>weapon>SSG-08>weapon>pointscale") or gui.ctx:find("rage>weapon>Bolt Snipers>weapon>pointscale")
					slot_0_15_0.temp["jump_scout-autostop-mode"] = gui.ctx:find("rage>weapon>SSG-08>extra>autostop>settings>mode") or gui.ctx:find("rage>weapon>Bolt Snipers>extra>autostop>settings>mode")
					slot_0_15_0.temp.jump_scout_cached = true

					if not slot_0_15_0.temp["jump_scout-autostop-mode"] then
						print("[Mercury:Error] Failed find jump scout var")
					end
				end

				return
			end

			slot_363_2_0 = slot_0_15_0.temp["jump_scout-hitchance"]
			slot_363_3_0 = slot_0_15_0.temp["jump_scout-pointscale"]
			slot_363_4_0 = slot_0_15_0.temp["jump_scout-autostop-mode"]

			if not slot_363_2_0 and not slot_363_3_0 and not slot_363_4_0 then
				return
			end

			if slot_363_1_0.settings:get() == 0 or not arg_363_0 then
				if slot_0_31_0.vars.jump_scout.active then
					slot_0_31_0.vars.jump_scout.active = false

					slot_363_3_0:get_value():set(slot_0_31_0.vars.jump_scout.old_p)
					slot_363_2_0:get_value():set(slot_0_31_0.vars.jump_scout.old_h)
				end

				return
			end

			slot_363_5_0 = string.lower(slot_0_14_0:get("get_weapon_name") or "") == "ssg-08"
			slot_363_6_0 = slot_0_31_0.vars.jump_scout
			slot_363_7_0 = slot_0_14_0:get("get_condition", arg_363_0) or ""
			slot_363_8_0 = string.find(slot_363_7_0, "air")

			if not slot_363_8_0 and slot_363_6_0.active or not slot_363_5_0 and slot_363_6_0.active then
				slot_363_6_0.active = false

				if slot_363_1_0.settings:get("In air autostop") then
					slot_363_9_1 = slot_363_4_0:get_value():get()

					slot_363_9_1:set_raw(bit.band(slot_363_9_1:get_raw(), bit.bnot(4)))
					slot_363_4_0:get_value():set(slot_363_9_1)
				end

				if slot_363_1_0.settings:get("Pointscale") then
					slot_363_3_0:get_value():set(slot_363_6_0.old_p)
				end

				if slot_363_1_0.settings:get("Hitchance") then
					slot_363_2_0:get_value():set(slot_363_6_0.old_h)
				end
			elseif slot_363_8_0 and slot_363_5_0 and not slot_363_6_0.active then
				slot_363_6_0.active = true
				slot_363_6_0.old_h = slot_363_2_0:get_value():get_direct()
				slot_363_6_0.old_p = slot_363_3_0:get_value():get_direct()

				if slot_363_1_0.settings:get("In air autostop") then
					slot_363_9_0 = slot_363_4_0:get_value():get()

					slot_363_9_0:set_raw(bit.bor(slot_363_9_0:get_raw(), 4))
					slot_363_4_0:get_value():set(slot_363_9_0)
				end

				if slot_363_1_0.settings:get("Pointscale") then
					slot_363_3_0:get_value():set(slot_363_1_0.pointscale.value:get())
				end

				if slot_363_1_0.settings:get("Hitchance") then
					slot_363_2_0:get_value():set(slot_363_1_0.hitchance.value:get())
				end
			end
		end,
		jumpbug = function(arg_364_0)
			if not slot_0_31_0.vars.jumpbug or not slot_0_15_0.jump_bug or not slot_0_15_0.jump_bug.get_value or not arg_364_0 then
				return
			end

			local var_364_0 = arg_364_0:get_abs_velocity()

			if not var_364_0 then
				return
			end

			local var_364_1 = var_364_0.z < -550

			slot_0_15_0.jump_bug:get_value():set(var_364_1)
		end
	},
	create_move = {
		fast_ladder = function(arg_365_0, arg_365_1)
			if not slot_0_31_0.vars.fast_ladder or not arg_365_1 or not arg_365_1:is_alive() then
				return
			end

			local var_365_0 = arg_365_0:get_button(input_bit_mask.in_forward) and "forward" or arg_365_0:get_button(input_bit_mask.in_back) and "back" or "none"

			if var_365_0 ~= "none" and slot_0_28_0.on_ladder(arg_365_1) then
				local var_365_1 = game.input:get_view_angles()

				arg_365_0:set_viewangles(slot_0_11_0(89, var_365_1.y + 90, 0))
				arg_365_0:set_forwardmove(var_365_0 == "forward" and -1 or 1)
				arg_365_0:set_leftmove(var_365_0 == "forward" and -1 or 1)
			end
		end
	}
}
slot_0_5_0 = {
	vars = {
		knife_bot = {
			first_hit = 0,
			active = false,
			slot_0_13_0.misc.knife_bot:element():add_callback(function()
				slot_0_5_0.vars.knife_bot.enabled = slot_0_13_0.misc.knife_bot:get()
			end)
		},
		freestand = {
			side = 0,
			active = false,
			old_yaw = slot_0_15_0.yaw_override and slot_0_15_0.yaw_override:get_value() and slot_0_15_0.yaw_override:get_value():get() or 0
		},
		cond = {
			pitch = gui.ctx:find("rage>anti-aim>angles>pitch"),
			pitch_angle = gui.ctx:find("rage>anti-aim>angles>pitch>settings>value"),
			pitch_jitter = gui.ctx:find("rage>anti-aim>angles>pitch jitter"),
			pitch_jitter_amount = gui.ctx:find("rage>anti-aim>angles>pitch jitter>settings>value"),
			pitch_jitter_3way = gui.ctx:find("rage>anti-aim>angles>pitch jitter>settings>3way"),
			yaw_base = gui.ctx:find("rage>anti-aim>angles>yaw base"),
			yaw_jitter = gui.ctx:find("rage>anti-aim>angles>yaw jitter"),
			yaw_jitter_amount = gui.ctx:find("rage>anti-aim>angles>yaw jitter>settings>amount"),
			yaw_jitter_3way = gui.ctx:find("rage>anti-aim>angles>yaw jitter>settings>3way")
		}
	},
	slot_0_14_0:register("get_freestand", function(arg_367_0)
		if not arg_367_0 then
			return 0
		end

		local var_367_0 = slot_0_27_0.trace_line
		local var_367_1 = slot_0_13_0.anti_aim.freestand_dist and slot_0_13_0.anti_aim.freestand_dist:get() or 150
		local var_367_2 = arg_367_0:get_eye_pos()

		if not var_367_2 then
			return 0
		end

		var_367_2.z = var_367_2.z - 10

		local var_367_3
		local var_367_4 = slot_0_14_0:get("get_target", arg_367_0)

		if var_367_4 then
			var_367_3 = var_367_4.angle
		else
			var_367_3 = game.input:get_view_angles()
		end

		if not var_367_3 then
			return 0
		end

		local var_367_5 = var_367_3.y
		local var_367_6 = math.angle_to_yaw_vector(var_367_5 + 90)
		local var_367_7 = math.angle_to_yaw_vector(var_367_5 - 90)
		local var_367_8 = math.angle_to_yaw_vector(var_367_3.y)
		local var_367_9 = {
			0,
			0
		}

		for iter_367_0 = 1, 5 do
			local var_367_10 = 5 + 6 * iter_367_0 + iter_367_0^2
			local var_367_11 = var_367_0(var_367_2, var_367_2 + math.multiply_vector(var_367_6, var_367_10), arg_367_0)
			local var_367_12 = var_367_0(var_367_2, var_367_2 + math.multiply_vector(var_367_7, var_367_10), arg_367_0)

			if var_367_11.fraction ~= 1 or var_367_12.fraction ~= 1 then
				if var_367_12.fraction ~= 1 and var_367_11.fraction == 1 then
					var_367_9[2] = var_367_9[2] + 2

					break
				elseif var_367_12.fraction == 1 and var_367_11.fraction ~= 1 then
					var_367_9[1] = var_367_9[1] + 2

					break
				end
			end

			local var_367_13 = var_367_11.end_pos
			local var_367_14 = var_367_12.end_pos
			local var_367_15 = var_367_0(var_367_13, var_367_13 + math.multiply_vector(var_367_8, var_367_1), arg_367_0)
			local var_367_16 = var_367_0(var_367_14, var_367_14 + math.multiply_vector(var_367_8, var_367_1), arg_367_0)

			if (var_367_15.fraction ~= 1 or var_367_16.fraction ~= 1) and math.abs(var_367_15.fraction - var_367_16.fraction) > 0.3 then
				if var_367_15.fraction < var_367_16.fraction then
					var_367_9[1] = var_367_9[1] + 1
				else
					var_367_9[2] = var_367_9[2] + 1
				end
			end

			if math.abs(var_367_9[1] - var_367_9[2]) > 2 then
				break
			end
		end

		if math.abs(var_367_9[1] - var_367_9[2]) <= 2 then
			return 0
		end

		return var_367_9[1] > var_367_9[2] and -1 or 1
	end, 3),
	in_game = {
		freestand = function(arg_368_0)
			if not arg_368_0 or not arg_368_0:is_alive() then
				return
			end

			local var_368_0 = slot_0_13_0.anti_aim.freestand:get()
			local var_368_1 = slot_0_5_0.vars.freestand

			if not var_368_0 then
				if var_368_1.active then
					var_368_1.active = false

					slot_0_15_0.yaw_override:get_value():set(var_368_1.old_yaw)
				end

				return
			end

			if not arg_368_0 then
				return
			end

			local var_368_2 = slot_0_14_0:get("get_freestand", arg_368_0)

			if var_368_2 == 0 and var_368_1.active then
				var_368_1.active = false

				slot_0_15_0.yaw_override:get_value():set(var_368_1.old_yaw)
			elseif var_368_2 ~= 0 and not var_368_1.active then
				var_368_1.active = true
				var_368_1.side = var_368_2
				var_368_1.old_yaw = slot_0_15_0.yaw_override:get_value():get_direct()

				slot_0_15_0.yaw_override:get_value():set(var_368_2 == 1 and -95 or 95)
			end
		end,
		builder = function(arg_369_0)
			if not arg_369_0 or not arg_369_0:is_alive() then
				return
			end

			if not slot_0_13_0.anti_aim.master_switch:get() then
				return
			end

			local var_369_0 = slot_0_14_0:get("get_condition", arg_369_0)

			if not var_369_0 then
				return
			end

			local var_369_1 = slot_0_13_0.anti_aim.conditions[var_369_0]

			if not var_369_1 then
				return
			end

			if not var_369_1.enable:get() then
				var_369_1 = slot_0_13_0.anti_aim.conditions.share

				if not var_369_1 or not var_369_1.params then
					return
				end
			end

			local var_369_2 = var_369_1.params

			if not var_369_2 then
				return
			end

			local var_369_3 = slot_0_5_0.vars.cond
			local var_369_4 = var_369_3.pitch:get_value()
			local var_369_5 = var_369_4:get()

			if var_369_2.pitch:get("Fake") then
				var_369_5:set_raw(16)
				var_369_4:set(var_369_5)
				var_369_3.pitch_angle:get_value():set(-3.4028233462974e+30)
			else
				var_369_5:set_raw(var_369_2.pitch:get())
				var_369_4:set(var_369_5)
				var_369_3.pitch_angle:get_value():set(var_369_2.pitch_params.angle:get())
			end

			local var_369_6 = var_369_3.pitch_jitter:get_value()
			local var_369_7 = var_369_6:get()

			var_369_7:set_raw(var_369_2.pitch_jitter:get())
			var_369_6:set(var_369_7)
			var_369_3.pitch_jitter_amount:get_value():set(var_369_2.pitch_jitter_params.amount:get())
			var_369_3.pitch_jitter_3way:get_value():set(var_369_2.pitch_jitter_params.way:get())

			local var_369_8 = var_369_3.yaw_base:get_value()
			local var_369_9 = var_369_8:get()

			var_369_9:set_raw(var_369_2.yaw_base:get())
			var_369_8:set(var_369_9)

			local var_369_10 = var_369_3.yaw_jitter:get_value()
			local var_369_11 = var_369_10:get()

			var_369_11:set_raw(var_369_2.yaw_jitter:get())
			var_369_10:set(var_369_11)
			var_369_3.yaw_jitter_amount:get_value():set(var_369_2.yaw_jitter_params.amount:get())
			var_369_3.yaw_jitter_3way:get_value():set(var_369_2.yaw_jitter_params.way:get())
		end
	},
	create_move = {
		knife_bot = function(arg_370_0, arg_370_1)
			local var_370_0 = slot_0_5_0.vars.knife_bot

			if (var_370_0.enabled and slot_0_14_0:get("get_weapon_group", arg_370_1)) ~= "knife" then
				var_370_0.active = false

				return
			end

			local var_370_1 = slot_0_14_0:get("get_nearest", arg_370_1)

			if not var_370_1 or not (var_370_1.dist < 160) or not var_370_1.angle or not var_370_1.angle.y then
				return
			end

			local var_370_2 = var_370_1.handle and var_370_1.handle:get()

			if not var_370_2 then
				return
			end

			local var_370_3 = slot_0_28_0.get_next_primary_attack(arg_370_1)
			local var_370_4 = slot_0_28_0.get_armor(var_370_2) > 0
			local var_370_5 = slot_0_28_0.get_health(var_370_2)
			local var_370_6 = var_370_2:get_abs_origin()
			local var_370_7 = arg_370_1:get_abs_origin()
			local var_370_8 = math.calc_angle(var_370_7, var_370_6)
			local var_370_9 = math.calc_dist(var_370_6, var_370_7)
			local var_370_10 = var_370_4 and var_370_3 and 34 or not var_370_4 and var_370_3 and 40 or not var_370_3 and var_370_4 and 21 or not var_370_3 and not var_370_4 and 25 or 20
			local var_370_11

			var_370_11 = var_370_4 and 55 or not var_370_4 and 65 or 50

			local var_370_12 = var_370_10 >= var_370_5 / (var_370_0.first_hit < slot_0_6_0.tick_count and 2 or 1) and 78 or 62

			var_370_0.active = false

			if var_370_9 < var_370_12 then
				var_370_0.active = true

				local var_370_13 = game.input:get_view_angles()

				if math.abs(slot_0_6_0.tick_count - var_370_0.first_hit) > 32 then
					var_370_0.first_hit = slot_0_6_0.tick_count + 5
				end

				arg_370_0:set_viewangles(var_370_1.angle)
				arg_370_0:set_button(var_370_12 == 78 and input_bit_mask.in_attack or input_bit_mask.in_attack2)
			end
		end
	}
}
slot_0_32_0 = {}
slot_0_32_0 = {
	vars = {
		afk_switch = false,
		afk_reset = false,
		afk_time = 0
	},
	global = {
		anti_afk = function(arg_371_0, arg_371_1)
			if not slot_0_13_0.misc.global:get("Anti afk") then
				return
			end

			if arg_371_1:get_abs_velocity():length() < 40 then
				slot_0_32_0.vars.afk_time = slot_0_32_0.vars.afk_time + slot_0_6_0.frame_time

				if slot_0_32_0.vars.afk_time > 8 then
					slot_0_32_0.vars.afk_reset = true

					arg_371_0:set_leftmove(slot_0_32_0.vars.afk_switch and 1 or -1)
				end
			elseif slot_0_32_0.vars.afk_reset then
				slot_0_32_0.vars.afk_reset = false
				slot_0_32_0.vars.afk_switch = not slot_0_32_0.vars.afk_switch
				slot_0_32_0.vars.afk_time = 0
			end
		end
	}
}
slot_0_33_0 = {}
slot_0_33_0 = {
	is_active_global = false,
	is_active = false,
	params = {
		slot_0_13_0.one_way.enable:element():add_callback(function()
			slot_0_33_0.is_active = slot_0_13_0.one_way.enable:get()
			slot_0_33_0.is_active_global = slot_0_13_0.one_way.enable:get()

			if not slot_0_33_0.is_active then
				slot_0_33_0:destroy_locations()
			else
				slot_0_33_0:update_locations()
			end
		end),
		slot_0_13_0.one_way.show.main:element():add_callback(function()
			slot_0_33_0.params.ignore_default = slot_0_13_0.one_way.show.main:get("Show only safe / unsafe")
			slot_0_33_0.params.disable_to_title = slot_0_13_0.one_way.show.main:get("Disable title for other side")
			slot_0_33_0.params.vector_line = slot_0_13_0.one_way.show.main:get("Visualization of \"from - to\"")
		end),
		slot_0_13_0.one_way.colors.safe:element():add_callback(function()
			slot_0_33_0.style.shadow_safe = slot_0_13_0.one_way.colors.safe:get()
		end),
		slot_0_13_0.one_way.colors.unsafe:element():add_callback(function()
			slot_0_33_0.style.shadow_warning = slot_0_13_0.one_way.colors.unsafe:get()
		end),
		slot_0_13_0.one_way.show.full:element():add_callback(function()
			slot_0_33_0.style.full_visible = slot_0_13_0.one_way.show.full:get()
		end),
		slot_0_13_0.one_way.show.trigger_radius:element():add_callback(function()
			slot_0_33_0.style.trigger_radius = slot_0_13_0.one_way.show.trigger_radius:get()
		end),
		slot_0_13_0.one_way.show.update_rate:element():add_callback(function()
			slot_0_33_0.params.move_delta = slot_0_13_0.one_way.show.update_rate:get()
		end),
		ignore_default = false,
		slot_0_13_0.one_way.show.grid_size:element():add_callback(function()
			slot_0_33_0.params.grid_size = slot_0_13_0.one_way.show.grid_size:get()
		end)
	},
	style = {
		full_visible = 80,
		semi_visible = 500,
		padding = 4,
		r = 5,
		better = true,
		block = slot_0_12_0(40, 150),
		background = slot_0_12_0(21, 170),
		shadow = slot_0_12_0(255, 30),
		shadow_safe = slot_0_12_0(100, 255, 120, 38),
		shadow_warning = slot_0_12_0(255, 80, 80, 45),
		accent = slot_0_12_0(255, 80, 80, 200),
		accent_shadow = slot_0_12_0(255, 120, 120, 30)
	},
	vars = {
		enemy_counter = 0,
		enemy_last_update = 0,
		move_delta = 70,
		grid_size = 200,
		reset_weapon = false,
		old_delay = 0,
		weapons = {
			"SSG-08",
			"AWP",
			"G3SG1",
			"SCAR-20",
			"R8 Revolver"
		},
		locations = {},
		locations_grid = {},
		active_locations = {},
		enemy_list = {},
		old_pos = slot_0_11_0(0, 0, 0),
		active_grid = {
			y = 0,
			x = 0
		}
	},
	vector_animation = function(arg_380_0, arg_380_1, arg_380_2, arg_380_3, arg_380_4)
		arg_380_2 = arg_380_2 or 0

		local var_380_0 = math.calc_dist(arg_380_0, arg_380_1)
		local var_380_1 = slot_0_11_0(arg_380_1.x - arg_380_0.x, arg_380_1.y - arg_380_0.y)
		local var_380_2 = math.multiply_vector(var_380_1, 1 / var_380_0)
		local var_380_3 = (slot_0_6_0.real_time + arg_380_2) % 2 / 2

		if arg_380_4 then
			var_380_3 = var_380_3 > 0.5 and (1 - var_380_3) * 2 or var_380_3 * 2
		end

		local var_380_4 = math.min(1, var_380_3 / 0.2, (1 - var_380_3) / 0.2) * 0.7
		local var_380_5 = math.add_vector(arg_380_0, math.multiply_vector(var_380_2, (var_380_0 - var_380_0 * 0.4 * var_380_4) * var_380_3))
		local var_380_6 = math.add_vector(arg_380_0, math.multiply_vector(var_380_2, (var_380_0 - var_380_0 * 0.1 * var_380_4) * var_380_3))
		local var_380_7 = math.add_vector(arg_380_0, math.multiply_vector(var_380_2, (var_380_0 + var_380_0 * 0.2 * var_380_4) * var_380_3))

		if var_380_5 and var_380_7 then
			local var_380_8 = draw.surface

			slot_0_3_0.line(var_380_8, var_380_5, var_380_6, arg_380_3:a(0.001), arg_380_3:a(arg_380_3:get_a() / 255 * var_380_4), 1)
			slot_0_3_0.line(var_380_8, var_380_6, var_380_7, arg_380_3:a(arg_380_3:get_a() / 255 * var_380_4), arg_380_3:a(0.001), 1)
		end
	end,
	check_uniq_id = function(arg_381_0, arg_381_1)
		for iter_381_0 = 1, #arg_381_0 do
			if arg_381_0[iter_381_0] == arg_381_1 then
				return false
			end
		end

		return true
	end,
	calc_grid_id = function(arg_382_0, arg_382_1)
		arg_382_0.vars.grid_size = arg_382_0.vars.grid_size or 200

		if type(arg_382_1) == "table" then
			local var_382_0 = math.round(arg_382_1[1] / arg_382_0.vars.grid_size)
			local var_382_1 = math.round(arg_382_1[2] / arg_382_0.vars.grid_size)

			return var_382_0, var_382_1
		else
			local var_382_2 = math.round(arg_382_1.x / arg_382_0.vars.grid_size)
			local var_382_3 = math.round(arg_382_1.y / arg_382_0.vars.grid_size)

			return var_382_2, var_382_3
		end
	end,
	load_locations = function(arg_383_0, arg_383_1)
		if type(arg_383_1) ~= "string" then
			return
		end

		slot_383_2_1 = slot_0_20_0.decode(arg_383_1)

		if type(slot_383_2_1) == "table" then
			slot_383_3_0 = 0
			slot_383_4_0 = {}

			for iter_383_0, iter_383_1 in pairs(slot_383_2_1) do
				if type(iter_383_1) == "table" and iter_383_1.from and iter_383_1.to and iter_383_1.map then
					slot_383_10_0, slot_383_11_0 = slot_0_33_0:calc_grid_id(iter_383_1.from.position)
					arg_383_0.vars.locations_grid[iter_383_1.map] = arg_383_0.vars.locations_grid[iter_383_1.map] or {}
					arg_383_0.vars.locations_grid[iter_383_1.map][slot_383_10_0] = arg_383_0.vars.locations_grid[iter_383_1.map][slot_383_10_0] or {}
					arg_383_0.vars.locations_grid[iter_383_1.map][slot_383_10_0][slot_383_11_0] = arg_383_0.vars.locations_grid[iter_383_1.map][slot_383_10_0][slot_383_11_0] or {}

					if slot_0_33_0.check_uniq_id(arg_383_0.vars.locations_grid[iter_383_1.map][slot_383_10_0][slot_383_11_0], iter_383_0) then
						table.insert(arg_383_0.vars.locations_grid[iter_383_1.map][slot_383_10_0][slot_383_11_0], iter_383_0)
					end

					slot_383_12_0, slot_383_13_0 = slot_0_33_0:calc_grid_id(iter_383_1.to.position)
					arg_383_0.vars.locations_grid[iter_383_1.map][slot_383_12_0] = arg_383_0.vars.locations_grid[iter_383_1.map][slot_383_12_0] or {}
					arg_383_0.vars.locations_grid[iter_383_1.map][slot_383_12_0][slot_383_13_0] = arg_383_0.vars.locations_grid[iter_383_1.map][slot_383_12_0][slot_383_13_0] or {}

					if slot_0_33_0.check_uniq_id(arg_383_0.vars.locations_grid[iter_383_1.map][slot_383_12_0][slot_383_13_0], iter_383_0) then
						table.insert(arg_383_0.vars.locations_grid[iter_383_1.map][slot_383_12_0][slot_383_13_0], iter_383_0)
					end

					iter_383_1.from.position = slot_0_11_0(iter_383_1.from.position[1], iter_383_1.from.position[2], iter_383_1.from.position[3])
					iter_383_1.to.position = slot_0_11_0(iter_383_1.to.position[1], iter_383_1.to.position[2], iter_383_1.to.position[3])

					if not iter_383_1.from.name or not iter_383_1.to.name then
						slot_383_3_0 = slot_383_3_0 + 1
						slot_383_4_0[iter_383_1.map] = slot_383_4_0[iter_383_1.map] or 0
						slot_383_4_0[iter_383_1.map] = slot_383_4_0[iter_383_1.map] + 1
						iter_383_1.title = string.format("id: %s-%s", slot_383_3_0, string.sub(iter_383_0, 1, 6))
					end

					iter_383_1.alpha = 0
					iter_383_1.visible = 0
					iter_383_1.shadow = slot_0_12_0(255, 0)
					arg_383_0.vars.locations[iter_383_0] = iter_383_1
				else
					print(string.format("[Mercury:one-way] location \"%s\": failed get data (%s)", iter_383_0, type(iter_383_1)))
				end
			end

			print("\n")

			for iter_383_2, iter_383_3 in pairs(slot_383_4_0) do
				print(tostring(iter_383_2) .. ": " .. tostring(iter_383_3))
			end
		end

		slot_383_2_0 = {}
	end,
	search_file_locations = function(arg_384_0)
		return
	end,
	update_locations = function(arg_385_0)
		local var_385_0 = arg_385_0.vars.locations_grid[game.global_vars.map_name]

		if not var_385_0 then
			return
		end

		local var_385_1 = arg_385_0.vars.active_grid.x
		local var_385_2 = arg_385_0.vars.active_grid.y
		local var_385_3 = {}

		for iter_385_0 = var_385_1 - 1, var_385_1 + 1 do
			for iter_385_1 = var_385_2 - 1, var_385_2 + 1 do
				if var_385_0[iter_385_0] and var_385_0[iter_385_0][iter_385_1] then
					for iter_385_2 = 1, #var_385_0[iter_385_0][iter_385_1] do
						local var_385_4 = var_385_0[iter_385_0][iter_385_1][iter_385_2]

						if slot_0_33_0.check_uniq_id(var_385_3, var_385_4) then
							var_385_3[#var_385_3 + 1] = var_385_4

							local var_385_5 = arg_385_0.vars.locations[var_385_4]
							local var_385_6 = math.calc_dist(var_385_5.from.position, arg_385_0.vars.old_pos)
							local var_385_7 = math.calc_dist(var_385_5.to.position, arg_385_0.vars.old_pos)
							local var_385_8 = math.min(var_385_6, var_385_7)

							var_385_5.trigger = var_385_6 < var_385_7 and 0 or 1

							if not var_385_5.visible_old or var_385_5.visible == 0 or var_385_8 > arg_385_0.style.semi_visible then
								var_385_5.visible_old = nil
								var_385_5.visible = arg_385_0.params.ignore_default and (var_385_8 < arg_385_0.style.semi_visible and 1 or 0) or var_385_8 < arg_385_0.style.full_visible and 2 or var_385_8 < arg_385_0.style.semi_visible and 1 or 0
							end
						end
					end
				end
			end
		end

		for iter_385_3 = 1, #arg_385_0.vars.active_locations do
			if slot_0_33_0.check_uniq_id(var_385_3, arg_385_0.vars.active_locations[iter_385_3]) then
				local var_385_9 = arg_385_0.vars.active_locations[iter_385_3]
				local var_385_10 = arg_385_0.vars.locations[var_385_9]

				var_385_10.visible = var_385_10.visible_old and var_385_10.visible or 0

				if var_385_10.alpha > 0 then
					var_385_3[#var_385_3 + 1] = arg_385_0.vars.active_locations[iter_385_3]
				end
			end
		end

		arg_385_0.vars.active_locations = var_385_3
	end,
	destroy_locations = function(arg_386_0)
		for iter_386_0 = 1, #arg_386_0.vars.active_locations do
			local var_386_0 = arg_386_0.vars.active_locations[iter_386_0]

			arg_386_0.vars.locations[var_386_0].visible = 0
		end
	end,
	update_only_active_locations = function(arg_387_0)
		for iter_387_0 = 1, #arg_387_0.vars.active_locations do
			local var_387_0 = arg_387_0.vars.active_locations[iter_387_0]
			local var_387_1 = arg_387_0.vars.locations[var_387_0]
			local var_387_2 = math.calc_dist(var_387_1.from.position, arg_387_0.vars.old_pos)
			local var_387_3 = math.calc_dist(var_387_1.to.position, arg_387_0.vars.old_pos)
			local var_387_4 = math.min(var_387_2, var_387_3)

			if not var_387_1.visible_old or var_387_4 > arg_387_0.style.semi_visible then
				var_387_1.visible = arg_387_0.params.ignore_default and (var_387_4 < arg_387_0.style.semi_visible and 1 or 0) or var_387_4 < arg_387_0.style.full_visible and 2 or var_387_4 < arg_387_0.style.semi_visible and 1 or 0
			end
		end
	end,
	update_on_move = function(arg_388_0)
		if not game.engine:in_game() or not (math.abs(arg_388_0.vars.old_delay - slot_0_6_0.real_time) > 0.3) then
			return
		end

		arg_388_0.vars.old_delay = slot_0_6_0.real_time

		local var_388_0 = slot_0_14_0:get("get_weapon_group")

		if not arg_388_0.vars.reset_weapon and (var_388_0 == "knife" or var_388_0 == "grenade") then
			arg_388_0.vars.reset_weapon = true
			slot_0_33_0.is_active = false

			arg_388_0:destroy_locations()

			return
		elseif arg_388_0.vars.reset_weapon and var_388_0 ~= "knife" and var_388_0 ~= "grenade" then
			arg_388_0.vars.reset_weapon = false
			slot_0_33_0.is_active = slot_0_13_0.one_way.enable:get()

			arg_388_0:update_locations()
		end

		if not slot_0_33_0.is_active then
			return
		end

		local var_388_1 = entities.get_local_pawn()

		if not var_388_1 or not var_388_1:is_alive() then
			return
		end

		local var_388_2 = var_388_1:get_abs_origin()

		if math.calc_dist(var_388_2, arg_388_0.vars.old_pos) > arg_388_0.vars.move_delta then
			arg_388_0.vars.old_pos = var_388_2

			local var_388_3, var_388_4 = slot_0_33_0:calc_grid_id(var_388_2)

			if arg_388_0.vars.active_grid.x ~= var_388_3 or arg_388_0.vars.active_grid.y ~= var_388_4 then
				arg_388_0.vars.active_grid.x = var_388_3
				arg_388_0.vars.active_grid.y = var_388_4

				arg_388_0:update_locations()
			elseif arg_388_0.style.better then
				arg_388_0:update_only_active_locations()
			end
		end
	end,
	update_enemy_positions = function(arg_389_0)
		if arg_389_0.vars.enemy_last_update + arg_389_0.vars.enemy_counter * 0.1 > slot_0_6_0.real_time then
			return
		end

		arg_389_0.vars.enemy_last_update = slot_0_6_0.real_time + 0.2

		local var_389_0 = entities.get_local_pawn()

		if not var_389_0 or not var_389_0:is_alive() then
			return false
		end

		local var_389_1 = var_389_0.m_iTeamNum:get()
		local var_389_2 = {}

		arg_389_0.vars.enemy_counter = 1

		entities.players:for_each(function(arg_390_0)
			local var_390_0 = arg_390_0.entity

			if var_390_0.m_iTeamNum and var_390_0.m_iTeamNum:get() ~= var_389_1 and var_390_0:is_alive() then
				arg_389_0.vars.enemy_counter = arg_389_0.vars.enemy_counter + 1

				local var_390_1 = false
				local var_390_2 = slot_0_28_0.get_weapon_name(var_390_0)

				for iter_390_0 = 1, #arg_389_0.vars.weapons do
					if arg_389_0.vars.weapons[iter_390_0] == var_390_2 then
						var_390_1 = true

						break
					end
				end

				local var_390_3 = var_390_0:get_abs_origin()

				for iter_390_1 = 1, #arg_389_0.vars.active_locations do
					local var_390_4 = arg_389_0.vars.active_locations[iter_390_1]
					local var_390_5 = arg_389_0.vars.locations[var_390_4]

					if var_390_5.visible ~= 0 and slot_0_33_0.check_uniq_id(var_389_2, var_390_4) then
						local var_390_6 = 0

						if var_390_5.trigger == 0 then
							var_390_6 = math.calc_dist(var_390_5.to.position, var_390_3)
						elseif var_390_5.trigger == 1 then
							var_390_6 = math.calc_dist(var_390_5.from.position, var_390_3)
						end

						if var_390_6 < arg_389_0.style.trigger_radius then
							var_390_5.visible_old = var_390_5.visible
							var_390_5.visible = var_390_1 and 3 or 4
							var_389_2[#var_389_2 + 1] = var_390_4

							break
						elseif var_390_5.visible_old ~= nil then
							var_390_5.visible = var_390_5.visible_old
							var_390_5.visible_old = nil
						end
					end
				end
			end
		end)
	end,
	render = function(arg_391_0)
		if not arg_391_0.vars.locations then
			return
		end

		slot_391_1_0 = arg_391_0.style.background
		slot_391_2_0 = arg_391_0.style.block
		slot_391_3_0 = arg_391_0.style.accent
		slot_391_4_0 = arg_391_0.style.accent_shadow
		slot_391_5_0 = arg_391_0.style.padding
		slot_391_6_0 = arg_391_0.style.padding - (arg_391_0.params.disable_to_title and 3 or 0)
		slot_391_7_0 = -1

		for iter_391_0 = 1, #arg_391_0.vars.active_locations do
			slot_391_12_0 = arg_391_0.vars.locations[arg_391_0.vars.active_locations[iter_391_0]]
			slot_391_12_0.alpha = math.lerp(slot_391_12_0.alpha, arg_391_0.params.ignore_default and slot_391_12_0.visible == 1 and 0 or slot_391_12_0.visible == 0 and -0.01 or slot_391_12_0.visible == 1 and 0.49 or 1.01, slot_0_6_0.frame_time * (slot_391_12_0.visible == 3 and 12 or 6))
			slot_391_12_0.alpha = math.clamp(slot_391_12_0.alpha, 0, 1)
			slot_391_13_0 = slot_391_12_0.alpha
			slot_391_14_0 = (slot_391_12_0.trigger == 0 or slot_391_12_0.trigger == 2) and slot_391_12_0.to.name or slot_391_12_0.trigger == 1 and slot_391_12_0.from.name or slot_391_12_0.title or tostring(arg_391_0.vars.active_locations[iter_391_0])

			if slot_391_13_0 > 0.02 then
				slot_391_15_0 = slot_391_12_0.trigger == 0 and slot_391_12_0.from.position or slot_391_12_0.to.position
				slot_391_16_0 = slot_391_12_0.trigger == 1 and slot_391_12_0.from.position or slot_391_12_0.to.position
				slot_391_12_0.shadow = math.lerp_color(slot_391_12_0.shadow, slot_391_12_0.visible == 3 and arg_391_0.style.shadow_warning or slot_391_12_0.visible == 4 and arg_391_0.style.shadow_safe or arg_391_0.style.shadow, slot_0_6_0.frame_time * 4)
				slot_391_17_0 = slot_391_12_0.shadow
				slot_391_18_0 = math.world_to_screen(slot_391_15_0)
				slot_391_19_0 = math.world_to_screen(slot_391_16_0)

				if slot_391_13_0 > 0.51 and arg_391_0.params.vector_line and slot_391_18_0 and slot_391_15_0 then
					arg_391_0.vector_animation(slot_391_12_0.trigger == 0 and slot_391_18_0 or slot_391_19_0, slot_391_12_0.trigger == 0 and slot_391_19_0 or slot_391_18_0, 0, slot_391_17_0:a(0.6 * (slot_391_13_0 - 0.5) * 2), slot_391_12_0.reverse)
				end

				if slot_0_3_0.on_screen(slot_391_18_0, 100) then
					slot_391_20_1 = slot_0_11_0(slot_391_18_0.x - slot_391_5_0 - 10 * slot_391_13_0, slot_391_18_0.y - slot_391_5_0 - 10 * slot_391_13_0)
					slot_391_21_1 = slot_0_11_0(slot_391_18_0.x + slot_391_5_0 + 10 * slot_391_13_0, slot_391_18_0.y + slot_391_5_0 + 10 * slot_391_13_0)

					if slot_391_13_0 > 0.52 then
						slot_391_22_1 = (slot_391_13_0 - 0.5) * 2
						slot_391_23_1 = slot_0_3_0.text_size(slot_391_14_0, slot_0_18_0.one_way).x + slot_391_5_0 * 2
						slot_391_24_1 = slot_0_11_0(slot_391_21_1.x + slot_391_23_1 * slot_391_22_1, slot_391_21_1.y)

						slot_0_3_0.shadow(slot_391_20_1, slot_391_24_1, slot_391_17_0:a(slot_391_17_0:get_a() / 255 * slot_391_22_1), 5, arg_391_0.style.r, 2)
						slot_0_3_0.shader_rounded("clean", slot_391_20_1, slot_391_24_1, arg_391_0.style.r, slot_391_13_0)
						slot_0_3_0.rect(slot_391_20_1, slot_391_24_1, slot_391_1_0:a(slot_391_1_0:get_a() / 255 * slot_391_22_1), arg_391_0.style.r)
						slot_0_3_0.push_clip_rect(slot_391_20_1, slot_391_24_1)
						slot_0_3_0.text(slot_391_14_0, slot_0_18_0.one_way, slot_0_11_0(slot_391_21_1.x + slot_391_5_0, slot_391_20_1.y + (slot_391_21_1.y - slot_391_20_1.y) / 2 - slot_0_18_0.offset.one_way), slot_0_12_0(255, 210 * slot_391_22_1))
						slot_0_3_0.pop_clip_rect()
					else
						slot_0_3_0.shadow(slot_391_20_1, slot_391_21_1, slot_391_17_0:a(slot_391_17_0:get_a() / 255 * slot_391_13_0), 5, arg_391_0.style.r, 2)
						slot_0_3_0.shader_rounded("clean", slot_391_20_1, slot_391_21_1, arg_391_0.style.r, slot_391_13_0)
					end

					slot_0_3_0.rect(slot_391_20_1, slot_391_21_1, slot_391_2_0:a(slot_391_2_0:get_a() / 255 * slot_391_13_0), arg_391_0.style.r)
					slot_0_3_0.circle_filled(slot_391_18_0, 2 + 3 * slot_391_13_0, slot_391_12_0.shadow:a(0.6 * slot_391_13_0))
				elseif slot_391_12_0.visible == 0 then
					slot_391_7_0 = iter_391_0
				end

				if slot_0_3_0.on_screen(slot_391_19_0, 100) and slot_391_13_0 > 0.52 then
					slot_391_20_0 = (slot_391_13_0 - 0.5) * 2
					slot_391_21_0 = slot_391_6_0 + 7 * slot_391_20_0
					slot_391_22_0 = slot_0_11_0(slot_391_19_0.x - slot_391_21_0, slot_391_19_0.y - slot_391_21_0)
					slot_391_23_0 = slot_0_11_0(slot_391_19_0.x + slot_391_21_0, slot_391_19_0.y + slot_391_21_0)
					slot_391_24_0 = arg_391_0.params.disable_to_title and 0 or slot_0_3_0.text_size(slot_391_14_0, slot_0_18_0.one_way_mini).x + slot_391_5_0 * 2
					slot_391_25_0 = slot_0_11_0(slot_391_23_0.x + slot_391_24_0 * slot_391_20_0, slot_391_23_0.y)

					slot_0_3_0.shadow(slot_391_22_0, slot_391_25_0, slot_391_17_0:a(slot_391_17_0:get_a() / 255 * slot_391_20_0), 5, arg_391_0.style.r, 2)
					slot_0_3_0.shader_rounded("clean", slot_391_22_0, slot_391_23_0, arg_391_0.style.r, slot_391_20_0)
					slot_0_3_0.rect(slot_391_22_0, slot_391_25_0, slot_391_1_0:a(slot_391_1_0:get_a() / 255 * slot_391_20_0), arg_391_0.style.r)

					if not arg_391_0.params.disable_to_title then
						slot_0_3_0.push_clip_rect(slot_391_22_0, slot_391_25_0)
						slot_0_3_0.text(slot_391_14_0, slot_0_18_0.one_way_mini, slot_0_11_0(slot_391_23_0.x + slot_391_5_0, slot_391_22_0.y + (slot_391_23_0.y - slot_391_22_0.y) / 2 - slot_0_18_0.offset.one_way_mini + 1), slot_0_12_0(255, 210 * slot_391_20_0))
						slot_0_3_0.pop_clip_rect()
					end

					slot_0_3_0.circle_filled(slot_391_19_0, 3 * slot_391_20_0, slot_391_12_0.shadow:a(slot_391_20_0), slot_391_12_0.shadow:a(0.12 * slot_391_20_0))
				end
			end
		end

		table.remove(arg_391_0.vars.active_locations, slot_391_7_0)
	end,
	on_paint = function()
		if not game.engine:in_game() or not slot_0_33_0.is_active_global and not (#slot_0_33_0.vars.active_locations > 0) then
			return
		end

		slot_0_33_0:render()

		if slot_0_33_0.is_active then
			slot_0_33_0:update_enemy_positions()
		end

		slot_0_33_0:update_on_move()
	end
}
slot_0_34_0 = {}
slot_0_34_0 = {
	vars = {
		grenades = {
			"molotov",
			"inferno",
			"hegrenade",
			"smokegrenade",
			"incgrenade",
			"decoy",
			"flashbang"
		},
		reset_params = function()
			slot_0_15_0.temp = {}
			slot_0_4_0.vars.buy_logs = {}
			slot_0_4_0.vars.world_marker.list = {}
			slot_0_4_0.vars.damage_markers = {}
			slot_0_30_0.vars.trails.list = {}
			slot_0_4_0.vars.physic_text_params.killstreak_counter = 0
			slot_0_4_0.vars.physic_text_params.domination_stats = {}
		end
	},
	player_hurt = {
		rage_log = function(arg_394_0)
			local var_394_0 = arg_394_0:get_pawn_from_id("userid")
			local var_394_1 = arg_394_0:get_pawn_from_id("attacker")
			local var_394_2 = entities.get_local_pawn()

			if not var_394_0 or not var_394_1 or not var_394_2 then
				return
			end

			if var_394_2 ~= var_394_0 and var_394_2 ~= var_394_1 then
				return
			end

			if var_394_0 == var_394_1 then
				return
			end

			local var_394_3 = tostring(arg_394_0:get_int("dmg_health"))

			if var_394_3 == "0" then
				return
			end

			local var_394_4 = tostring(arg_394_0:get_int("health"))
			local var_394_5 = arg_394_0:get_int("hitgroup")
			local var_394_6 = arg_394_0:get_string("weapon") or "none"
			local var_394_7 = var_394_2 == var_394_1 and "hit" or var_394_2 == var_394_0 and "hurt" or "undefined"
			local var_394_8 = (var_394_7 == "hurt" and var_394_1 or var_394_0):get_name()
			local var_394_9

			if var_394_7 == "hit" then
				local var_394_10 = var_394_0:get_eye_pos()

				if var_394_10 then
					var_394_10.z = var_394_10.z - 20

					if slot_0_4_0.vars.physic_text_params.damage then
						slot_0_4_0.add_physic_text(tostring(var_394_3), var_394_10, true)
					end

					if slot_0_4_0.vars.physic_text_params.head_shot and var_394_5 == 1 then
						slot_0_4_0.add_physic_text("HEADSHOT", var_394_10, false)
					end

					slot_0_4_0.add_damage_marker(var_394_10, var_394_6 == "taser" and "Тased" or var_394_3)
				end

				if slot_0_4_0.vars.world_marker.last_time == slot_0_6_0.real_time then
					local var_394_11 = math.calc_nearest_position(var_394_2:get_eye_pos(), slot_0_4_0.vars.world_marker.last_pos, var_394_10)

					var_394_9 = math.calc_backtrack(var_394_0, var_394_10, var_394_11)
				end
			end

			local var_394_12 = true

			for iter_394_0 = 1, #slot_0_34_0.vars.grenades do
				if var_394_6 == slot_0_34_0.vars.grenades[iter_394_0] then
					var_394_12 = false

					break
				end
			end

			if var_394_12 then
				var_394_6 = string.lower(slot_0_28_0.get_weapon_name(var_394_7 == "hurt" and var_394_1 or var_394_2) or var_394_6)
			end

			slot_0_4_0.add_rage_log(var_394_7, {
				name = var_394_8,
				hitgroup = var_394_5,
				damage = var_394_3,
				health = var_394_4,
				weapon = var_394_6,
				backtrack = var_394_9
			})
		end,
		cloud_grenade_damage = function(arg_395_0)
			local var_395_0 = arg_395_0:get_controller("userid")
			local var_395_1 = arg_395_0:get_controller("attacker")
			local var_395_2 = entities.get_local_controller()

			if var_395_0 == var_395_1 then
				return
			end

			if not var_395_0 or not var_395_1 or not var_395_2 then
				return
			end

			if var_395_2 ~= var_395_1 or slot_0_28_0.get_steam_id(var_395_0) == 0 then
				return
			end

			local var_395_3 = arg_395_0:get_int("dmg_health")
			local var_395_4 = arg_395_0:get_string("weapon")
			local var_395_5 = false

			for iter_395_0 = 1, #slot_0_34_0.vars.grenades do
				if var_395_4 == slot_0_34_0.vars.grenades[iter_395_0] then
					var_395_5 = true

					break
				end
			end

			slot_0_6_0.cloud_grenade_damage = (slot_0_6_0.cloud_grenade_damage or 0) + (var_395_5 and var_395_3 or 0)
		end
	},
	player_death = {
		killstreak = function(arg_396_0)
			local var_396_0 = arg_396_0:get_pawn_from_id("attacker")
			local var_396_1 = arg_396_0:get_pawn_from_id("userid")
			local var_396_2 = entities.get_local_pawn()

			if not var_396_0 or not var_396_1 or not var_396_2 then
				return
			end

			local var_396_3 = var_396_2 == var_396_0 and var_396_2 ~= var_396_1 and "kill" or var_396_2 == var_396_1 and var_396_2 ~= var_396_0 and "death" or "~"

			if var_396_3 == "~" then
				return
			end

			local var_396_4 = slot_0_4_0.vars.physic_text_params.domination_stats

			if var_396_3 == "kill" then
				local var_396_5 = var_396_1:get_eye_pos()
				local var_396_6 = var_396_1:get_name()

				var_396_4[var_396_6] = (var_396_4[var_396_6] or 0) + 1

				if var_396_4[var_396_6] > 1 and slot_0_4_0.vars.physic_text_params.domination and var_396_5 then
					slot_0_4_0.add_physic_text(string.format("x%s", var_396_4[var_396_6]), var_396_5, true)
				end

				slot_0_4_0.vars.physic_text_params.killstreak_counter = slot_0_4_0.vars.physic_text_params.killstreak_counter + 1

				if var_396_5 and slot_0_4_0.vars.physic_text_params.killstreak and slot_0_4_0.vars.physic_text_params.killstreak_counter > 1 then
					slot_0_4_0.add_physic_text(string.format("%s", slot_0_6_0.killstreak_notify[slot_0_4_0.vars.physic_text_params.killstreak_counter - 1] or "GODLIKE"), var_396_5, false)
				end
			else
				slot_0_4_0.vars.physic_text_params.killstreak_counter = 0
				var_396_4[var_396_0:get_name()] = nil
			end

			local var_396_7 = arg_396_0:get_bool("headshot")
		end,
		cloud_stats_kd = function(arg_397_0)
			local var_397_0 = arg_397_0:get_pawn_from_id("attacker")
			local var_397_1 = arg_397_0:get_pawn_from_id("userid")
			local var_397_2 = entities.get_local_pawn()

			if not var_397_0 or not var_397_1 or not var_397_2 then
				return
			end

			local var_397_3 = var_397_2 == var_397_0 and var_397_2 ~= var_397_1 and "kill" or var_397_2 == var_397_1 and var_397_2 ~= var_397_0 and "death" or "~"

			if var_397_3 == "~" then
				return
			end

			if (var_397_3 == "kill" and slot_0_28_0.get_steam_id(var_397_1) or slot_0_28_0.get_steam_id(var_397_0)) == 0 then
				return 0
			end

			slot_0_6_0.cloud_kills = (slot_0_6_0.cloud_kills or 0) + (var_397_3 == "kill" and 1 or 0)
			slot_0_6_0.cloud_deaths = (slot_0_6_0.cloud_deaths or 0) + (var_397_3 == "death" and 1 or 0)
		end
	},
	bullet_impact = {
		world_marker = function(arg_398_0)
			local var_398_0 = entities.get_local_controller()
			local var_398_1 = arg_398_0:get_controller("userid")

			if not var_398_0 or not var_398_1 then
				return
			end

			if var_398_0 ~= var_398_1 then
				return
			end

			local var_398_2 = arg_398_0:get_float("x")
			local var_398_3 = arg_398_0:get_float("y")
			local var_398_4 = arg_398_0:get_float("z")

			slot_0_4_0.vars.world_marker.last_time = slot_0_6_0.real_time
			slot_0_4_0.vars.world_marker.last_pos = slot_0_11_0(var_398_2, var_398_3, var_398_4)

			if not slot_0_13_0.visuals.world_marker.settings:get("Impact") then
				return
			end

			slot_0_4_0.add_world_marker(slot_0_11_0(var_398_2, var_398_3, var_398_4))
		end
	},
	weapon_fire = {
		fast_switch = function(arg_399_0)
			if not slot_0_13_0.misc.global:get("Fast throw") then
				return
			end

			local var_399_0 = entities.get_local_controller()
			local var_399_1 = arg_399_0:get_controller("userid")

			if not var_399_0 or not var_399_1 then
				return
			end

			if var_399_0 ~= var_399_1 then
				return
			end

			local var_399_2 = arg_399_0:get_string("weapon")
			local var_399_3 = var_399_0:get_active_weapon()

			if not var_399_3 or not var_399_3.get_type then
				return
			end

			if var_399_3:get_type() == 9 then
				game.engine:client_cmd("slot3")
				game.engine:client_cmd("slot2")
				game.engine:client_cmd("slot1")
			end
		end
	},
	round_start = {
		taskbar_notify = function(arg_400_0)
			if not slot_0_13_0.misc.global:get("Taskbar notify on round") then
				return
			end

			slot_0_6_0.taskbar_notify()
		end,
		killstreak = function(arg_401_0)
			slot_0_4_0.vars.physic_text_params.killstreak_counter = 0
		end
	},
	item_purchase = {
		gen_buy_log = function(arg_402_0)
			if not (slot_0_13_0.ui.widgets.settings:get("Notify: Buy logs") or slot_0_13_0.ui.widgets.settings:get("Rage logs: Buy logs")) then
				return
			end

			local var_402_0 = arg_402_0:get_pawn_from_id("userid")

			if not var_402_0 then
				return
			end

			local var_402_1 = entities.get_local_pawn()
			local var_402_2 = arg_402_0:get_int("team")

			if var_402_1 and var_402_1.m_iTeamNum and var_402_1.m_iTeamNum:get() == var_402_2 then
				return
			end

			local var_402_3 = string.gsub(arg_402_0:get_string("weapon"), "weapon_", "")
			local var_402_4 = var_402_0:get_name() or "undefined"
			local var_402_5 = string.gsub(var_402_4, "T", "Т")

			slot_0_4_0.add_buy_log(var_402_5, var_402_3)
		end
	}
}

mods.events:add_listener("player_death")
mods.events:add_listener("item_purchase")
mods.events:add_listener("game_newmap")
slot_0_10_0(slot_0_13_0, true)

slot_0_35_0 = {
	connect_state = ""
}
slot_0_36_0 = {
	alpha = 0,
	destroy = false,
	timer = 0,
	delay = slot_0_6_0.real_time + 1,
	states = {
		{
			alpha = 0,
			wait_time = 4,
			progress = 0,
			title = slot_0_17_0:get_random("server-connect"),
			func = function(arg_403_0, arg_403_1)
				if not arg_403_0.is_sended then
					arg_403_0.delay = slot_0_6_0.real_time + (arg_403_0.wait_time or 3)
					arg_403_0.is_sended = true

					slot_0_22_0.Post("/auth/login", nil, {}, function(arg_404_0)
						slot_0_23_0.uid = -1
						slot_0_23_0.connect = false

						if type(arg_404_0) == "string" then
							slot_0_35_0.connect_state = "failed-auth-0"
							slot_0_35_0.connect_i = 1

							return
						end

						if not arg_404_0.token or not arg_404_0.id then
							slot_0_35_0.connect_state = "failed-auth-1"
							slot_0_35_0.connect_i = 1

							print("Failed auth [1]")

							return
						end

						slot_0_23_0.token = slot_0_23_0.dec(arg_404_0.token, slot_0_23_0.token)
						slot_0_23_0.uid = arg_404_0.id
						slot_0_23_0.connect = true
					end)
				end

				if not slot_0_23_0.connect and (arg_403_0.delay or 0) < slot_0_6_0.real_time then
					slot_0_35_0.connect_state = "failed-auth-3"
					slot_0_35_0.connect_i = 1

					return 1
				end

				return slot_0_23_0.connect and 1 or 1 - (arg_403_0.delay - slot_0_6_0.real_time) / (arg_403_0.wait_time or 3)
			end
		},
		{
			alpha = 0,
			wait_time = 3,
			progress = 0,
			title = slot_0_17_0:get_random("server-offsets"),
			func = function(arg_405_0, arg_405_1)
				if not arg_405_0.is_sended then
					arg_405_0.delay = slot_0_6_0.real_time + (arg_405_0.wait_time or 3)
					arg_405_0.is_sended = true

					slot_0_22_0.Get("get_game_offsets", function(arg_406_0)
						arg_405_0.success = true

						if type(arg_406_0) == "table" then
							for iter_406_0, iter_406_1 in pairs(arg_406_0) do
								slot_0_16_0[iter_406_0] = string.find(tostring(iter_406_1), "0x") and tonumber(iter_406_1) or iter_406_1
							end
						else
							slot_0_35_0.connect_i = 2
						end
					end)
				end

				if not arg_405_0.success and (arg_405_0.delay or 0) < slot_0_6_0.real_time then
					slot_0_35_0.connect_state = "find offsets"
					slot_0_35_0.connect_i = 2

					return 1
				end

				return arg_405_0.success and 1 or 1 - (arg_405_0.delay - slot_0_6_0.real_time) / (arg_405_0.wait_time or 3)
			end
		},
		{
			alpha = 0,
			wait_time = 3,
			progress = 0,
			title = slot_0_17_0:get_random("server-notify"),
			func = function(arg_407_0, arg_407_1)
				if not arg_407_0.is_sended then
					arg_407_0.delay = slot_0_6_0.real_time + (arg_407_0.wait_time or 3)
					arg_407_0.is_sended = true

					slot_0_22_0.Get("get_notifys", function(arg_408_0)
						arg_407_0.success = true

						if type(arg_408_0) == "table" then
							for iter_408_0 = 1, #arg_408_0 do
								local var_408_0 = arg_408_0[iter_408_0]
								local var_408_1 = var_408_0.type == "warning" and slot_0_12_0(255, 80, 80) or slot_0_12_0(80, 220, 80)
								local var_408_2 = var_408_0.message and (var_408_0.message[slot_0_17_0.lang] or var_408_0.message.en) or "Failed get notify"

								print("[Mercury:Notify] ", var_408_2)
								arg_407_1:add_message(nil, var_408_2, var_408_0.show_time or 5, var_408_1)

								if var_408_0.confirmed then
									arg_407_1:add_button(nil, "Confirm", var_408_1)
								end
							end
						else
							slot_0_35_0.connect_i = 2
						end
					end)
				end

				if (arg_407_0.delay or 0) < slot_0_6_0.real_time then
					return 1
				end

				return arg_407_0.success and 1 or 1 - (arg_407_0.delay - slot_0_6_0.real_time) / (arg_407_0.wait_time or 3)
			end
		}
	},
	add_message = function(arg_409_0, arg_409_1, arg_409_2, arg_409_3, arg_409_4)
		table.insert(arg_409_0.states, arg_409_1 or #arg_409_0.states + 1, {
			alpha = 0,
			progress = 0,
			title = arg_409_2 or "none",
			wait_time = arg_409_3,
			line_color = arg_409_4,
			func = function(arg_410_0)
				if not arg_410_0.is_sended then
					arg_410_0.delay = slot_0_6_0.real_time + (arg_410_0.wait_time or 3)
					arg_410_0.is_sended = true
				end

				if (arg_410_0.delay or 0) < slot_0_6_0.real_time then
					return 1
				end

				return 1 - (arg_410_0.delay - slot_0_6_0.real_time) / (arg_410_0.wait_time or 3)
			end
		})
	end,
	add_button = function(arg_411_0, arg_411_1, arg_411_2, arg_411_3)
		table.insert(arg_411_0.states, arg_411_1 or #arg_411_0.states + 1, {
			alpha = 0,
			is_button = true,
			progress = 0,
			title = arg_411_2 or "none",
			line_color = arg_411_3
		})
	end,
	add_background = function(arg_412_0)
		slot_0_3_0.shader_rounded("blur_low", slot_0_11_0(0, 0), slot_0_6_0.screen_size, 0, arg_412_0.alpha)
		slot_0_3_0.shader_rounded("fullscreen", slot_0_11_0(0, 0), slot_0_6_0.screen_size, 0, arg_412_0.alpha, slot_0_12_0(130 + 30 * math.sin(slot_0_6_0.real_time), 130 + 30 * math.sin(slot_0_6_0.real_time * 0.6), 255, 255 * arg_412_0.alpha))
		slot_0_3_0.rect(slot_0_11_0(0, 0), slot_0_6_0.screen_size, slot_0_12_0(0, 80 * arg_412_0.alpha), 0)
	end,
	add_states_draw = function(arg_413_0, arg_413_1)
		slot_413_2_0 = 1
		slot_413_3_0 = slot_0_11_0(slot_0_6_0.screen_size.x / 2, slot_0_6_0.screen_size.y / 8)
		slot_413_4_0 = 14
		slot_413_5_0 = 16
		slot_413_6_0 = 160
		slot_413_7_0 = 1.5

		for iter_413_0 = 1, #arg_413_0.states do
			slot_413_12_0 = arg_413_0.states[iter_413_0]
			slot_413_12_0.alpha = math.bounded_lerp(slot_413_12_0.alpha, 0, 1, 6, slot_413_2_0 == 1)

			if slot_413_12_0.is_button then
				slot_413_13_1 = slot_0_3_0.text_size(slot_413_12_0.title, slot_0_18_0.static.auth)
				slot_413_14_0 = slot_413_3_0 - slot_0_11_0(slot_413_13_1.x / 2 + slot_413_4_0 / 2, slot_413_5_0 / 2)
				slot_413_15_0 = slot_413_3_0 + slot_0_11_0(slot_413_13_1.x / 2 + slot_413_4_0 / 2, slot_413_5_0 + 3)

				slot_0_3_0.rect(slot_413_14_0, slot_413_15_0, slot_0_12_0(30, 120 * slot_413_12_0.alpha * arg_413_1), 4)
				slot_0_3_0.rect(slot_413_14_0, slot_413_15_0, (slot_413_12_0.line_color or slot_0_12_0(140, 152, 255)):a(0.7 * slot_413_12_0.alpha * arg_413_1), 4, true)
				slot_0_3_0.text_center(slot_413_12_0.title, slot_0_18_0.static.auth, slot_413_3_0, slot_0_12_0(255, 255 * slot_413_12_0.alpha * arg_413_1))

				slot_413_16_0 = slot_0_24_0.cursor_pos()
				slot_413_17_0 = slot_413_16_0.x >= slot_413_14_0.x and slot_413_16_0.x <= slot_413_14_0.x + slot_413_15_0.x - slot_413_14_0.x and slot_413_16_0.y >= slot_413_14_0.y and slot_413_16_0.y <= slot_413_14_0.y + slot_413_15_0.y - slot_413_14_0.y

				if slot_0_24_0.key_pressed(1) and slot_413_17_0 then
					slot_413_12_0.progress = 1
				end

				slot_413_3_0.y = slot_413_3_0.y + (slot_413_5_0 + slot_413_4_0 / 4) * slot_413_12_0.alpha
			else
				slot_0_3_0.text_center(slot_413_12_0.title, slot_0_18_0.static.auth, slot_413_3_0, slot_0_12_0(255, 255 * slot_413_12_0.alpha * arg_413_1))

				slot_413_3_0.y = slot_413_3_0.y + slot_413_5_0 * slot_413_12_0.alpha

				slot_0_3_0.rect(slot_413_3_0 - slot_0_11_0(slot_413_6_0 / 2, slot_413_7_0), slot_413_3_0 + slot_0_11_0(slot_413_6_0 / 2, slot_413_7_0), slot_0_12_0(30, 120 * slot_413_12_0.alpha * arg_413_1), 2)
				slot_0_3_0.rect(slot_413_3_0 - slot_0_11_0(slot_413_6_0 / 2, slot_413_7_0), slot_413_3_0 + slot_0_11_0(-slot_413_6_0 / 2 + slot_413_6_0 * slot_413_12_0.progress, slot_413_7_0), (slot_413_12_0.line_color or slot_0_12_0(140, 152, 255)):a(slot_413_12_0.alpha * arg_413_1), 2)

				slot_413_13_0 = slot_413_2_0 == 1 and slot_413_12_0.alpha > 0 and slot_413_12_0.func and slot_413_12_0:func(arg_413_0) or 0
				slot_413_12_0.progress = math.bounded_lerp(slot_413_12_0.progress or 0, 0, math.clamp(slot_413_13_0, 0, 1), 4, true)
			end

			slot_413_2_0 = slot_413_12_0.progress

			if slot_413_2_0 == 1 and iter_413_0 == #arg_413_0.states then
				return slot_0_35_0.connect_state == "" or arg_413_0.destroy
			end

			slot_413_3_0.y = slot_413_3_0.y + (slot_413_7_0 + slot_413_4_0) * slot_413_12_0.alpha
		end
	end,
	connect_state_handler = function(arg_414_0)
		if slot_0_35_0.connect_state ~= "" and not arg_414_0.is_states_edited then
			arg_414_0.is_states_edited = true

			local var_414_0 = (slot_0_35_0.connect_i or 1) + 1
			local var_414_1 = arg_414_0

			table.insert(arg_414_0.states, var_414_0, {
				alpha = 0,
				wait_time = 2,
				progress = 0,
				title = "Fail: " .. tostring(slot_0_17_0:get(slot_0_35_0.connect_state, 1)),
				line_color = slot_0_12_0(255, 80, 80),
				func = function(arg_415_0)
					if not arg_415_0.is_sended then
						arg_415_0.delay = slot_0_6_0.real_time + (arg_415_0.wait_time or 3)
						arg_415_0.is_sended = true
					end

					if (arg_415_0.delay or 0) < slot_0_6_0.real_time then
						var_414_1.destroy = true

						return 1
					end

					return 1 - (arg_415_0.delay - slot_0_6_0.real_time) / (arg_415_0.wait_time or 3)
				end
			})

			local var_414_2 = var_414_0 + 1

			while arg_414_0.states[var_414_2] do
				table.remove(arg_414_0.states, var_414_2)
			end

			arg_414_0:add_button(nil, "Confirm", slot_0_12_0(255, 80, 80))
		end
	end,
	start_auth = function(arg_416_0)
		local var_416_0 = "start"

		events.present_queue:add(function()
			if arg_416_0.destroy and arg_416_0.alpha == 0 then
				arg_416_0:auth_callback()

				return
			end

			slot_0_6_0.real_time = game.global_vars.real_time
			slot_0_6_0.frame_time = game.global_vars.frame_time

			if arg_416_0.delay > slot_0_6_0.real_time then
				return
			end

			arg_416_0.alpha = math.bounded_lerp(arg_416_0.alpha, 0, 1, 4, not arg_416_0.destroy)

			arg_416_0:add_background()

			arg_416_0.destroy = arg_416_0:add_states_draw(arg_416_0.alpha)

			arg_416_0:connect_state_handler()
		end)
	end,
	auth_callback = function(arg_418_0)
		if type(arg_418_0.on_auth) == "function" then
			arg_418_0.on_auth()

			arg_418_0.on_auth = nil
		end
	end
}

slot_0_36_0:start_auth()

function slot_0_7_0.callback_decorator(arg_419_0)
	if DEBUG_MODE then
		return function(arg_420_0)
			xpcall(function()
				return arg_419_0(arg_420_0)
			end, function(arg_422_0)
				print("[Mercury:crash] The error log is recorded in: /fatality/mercury/MercuryCrashLog.txt")
				data_base.write_text("MercuryCrashLog.txt", arg_422_0 .. "\nState: ")
				slot_0_22_0.Post("/stats", "crash", {
					info = arg_422_0
				})

				local var_422_0 = gui.notification("Mercury crash", "The error log is recorded in: /fatality/mercury/MercuryCrashLog.txt")

				return gui.notify:add(var_422_0)
			end)
		end
	else
		return arg_419_0
	end
end

function slot_0_37_0()
	return
end

function slot_0_38_0()
	return
end

function slot_0_39_0()
	return
end

function slot_0_40_0()
	return
end

function slot_0_36_0.on_auth()
	slot_0_27_0 = slot_0_27_0()

	local var_427_0 = game.global_vars.real_time

	slot_0_7_0.cycle(0.1, function()
		slot_0_6_0.menu_visible = gui.is_visible()

		if slot_0_6_0.menu_visible then
			slot_0_10_0(slot_0_13_0, true)
		end
	end)

	function slot_0_37_0()
		slot_0_6_0.frame_time = game.global_vars.frame_time
		slot_0_6_0.tick_count = game.global_vars.tick_count

		local var_429_0 = math.abs(game.global_vars.real_time - var_427_0)

		var_427_0 = game.global_vars.real_time
		slot_0_6_0.real_time = slot_0_6_0.real_time + (var_429_0 > 1 and slot_0_6_0.frame_time or var_429_0)

		slot_0_7_0.update_timer()

		if not slot_0_6_0.is_loaded and slot_0_6_0.real_time > 0.2 then
			slot_0_6_0.is_loaded = true

			slot_0_4_0.vars.rage_logs.updater()
		end

		slot_0_33_0.on_paint()
		slot_0_26_0:visual_handler()
		slot_0_3_0.notify_handler()

		local var_429_1 = draw.surface

		for iter_429_0, iter_429_1 in pairs(slot_0_29_0.always) do
			iter_429_1()
		end

		for iter_429_2, iter_429_3 in pairs(slot_0_4_0.global) do
			iter_429_3(var_429_1)
		end

		if game.engine:in_game() then
			local var_429_2 = entities.get_local_pawn()

			for iter_429_4, iter_429_5 in pairs(slot_0_30_0.in_game) do
				iter_429_5(var_429_2)
			end

			for iter_429_6, iter_429_7 in pairs(slot_0_5_0.in_game) do
				iter_429_7(var_429_2)
			end

			for iter_429_8, iter_429_9 in pairs(slot_0_31_0.in_game) do
				iter_429_9(var_429_2)
			end
		end
	end

	function slot_0_38_0(arg_430_0)
		if not game.engine:in_game() then
			return
		end

		local var_430_0 = entities.get_local_pawn()

		if not var_430_0 then
			return
		end

		slot_0_6_0.tick_count = game.global_vars.tick_count

		for iter_430_0, iter_430_1 in pairs(slot_0_32_0.global) do
			iter_430_1(arg_430_0, var_430_0)
		end

		for iter_430_2, iter_430_3 in pairs(slot_0_31_0.create_move) do
			iter_430_3(arg_430_0, var_430_0)
		end

		for iter_430_4, iter_430_5 in pairs(slot_0_5_0.create_move) do
			iter_430_5(arg_430_0, var_430_0)
		end

		for iter_430_6, iter_430_7 in pairs(slot_0_30_0.create_move) do
			iter_430_7(arg_430_0, var_430_0)
		end
	end

	function slot_0_39_0(arg_431_0)
		for iter_431_0, iter_431_1 in pairs(slot_0_30_0.override_view) do
			iter_431_1(arg_431_0)
		end
	end

	function slot_0_40_0(arg_432_0)
		local var_432_0 = slot_0_34_0[arg_432_0:get_name()]

		if var_432_0 then
			for iter_432_0, iter_432_1 in pairs(var_432_0) do
				iter_432_1(arg_432_0)
			end
		end
	end

	slot_0_7_0.timer(0.5, function()
		slot_0_3_0.notify({
			{
				"Welcome back, ",
				slot_0_12_0()
			},
			{
				tostring(gui.ctx.user.username or "undefined"),
				slot_0_12_0(145, 164, 255, 255),
				speed = 2,
				effect = "enchanted",
				second = slot_0_12_0()
			},
			{
				"!",
				slot_0_12_0()
			}
		}, {
			bonus_time = 8,
			font = slot_0_18_0.alata16
		}, slot_0_3_0.make_notify_style(slot_0_3_0.get_icon("crown"), slot_0_12_0(145, 164, 255), "fast_blur", true))

		local var_433_0 = slot_0_12_0(159, 171, 194)
		local var_433_1 = slot_0_12_0(220, 255)

		slot_0_3_0.notify({
			{
				"Mercury ",
				slot_0_12_0()
			},
			{
				"Nightly",
				var_433_0,
				speed = 1.2,
				effect = "enchanted",
				second = slot_0_12_0()
			},
			{
				" is now on sale!",
				slot_0_12_0()
			},
			lines = {
				"- Custom menu",
				"- User statistics",
				"- New functions"
			}
		}, {
			bonus_time = 15,
			font = slot_0_18_0.alata16
		}, slot_0_3_0.make_notify_style(slot_0_3_0.get_icon("crown"), var_433_0, "fast_blur", true))
	end)

	local var_427_1 = {
		stats_counter = 0,
		callback_kd = function(arg_434_0)
			slot_0_7_0.cycle(60, function()
				if slot_0_6_0.cloud_kills and slot_0_6_0.cloud_deaths and arg_434_0.stats_counter < 3 and slot_0_6_0.cloud_kills < slot_0_6_0.cloud_deaths then
					arg_434_0.stats_counter = arg_434_0.stats_counter + 1

					return
				end

				if slot_0_6_0.cloud_kills and slot_0_6_0.cloud_kills ~= 0 or slot_0_6_0.cloud_deaths and slot_0_6_0.cloud_deaths ~= 0 then
					local var_435_0 = slot_0_6_0.cloud_kills
					local var_435_1 = slot_0_6_0.cloud_deaths
					local var_435_2 = slot_0_6_0.cloud_grenade_damage or 0

					arg_434_0.stats_counter = 0
					slot_0_6_0.cloud_kills = 0
					slot_0_6_0.cloud_deaths = 0
					slot_0_6_0.grenade_damage = 0

					slot_0_22_0.Post("/stats", "kd", {
						kills = var_435_0,
						deaths = var_435_1,
						grenade_damage = var_435_2
					})
				elseif (slot_0_6_0.cloud_grenade_damage or 0) > 30 then
					local var_435_3 = slot_0_6_0.cloud_grenade_damage or 0

					slot_0_6_0.cloud_grenade_damage = 0

					slot_0_22_0.Post("/stats", "kd", {
						grenade_damage = var_435_3
					})
				end
			end)
		end,
		callback_server_ip = function()
			slot_0_7_0.callback(5, function()
				local var_437_0 = game.engine:get_netchan()

				if var_437_0 and not var_437_0:is_null() then
					if not var_437_0:is_loopback() then
						local var_437_1 = tostring(var_437_0:get_address())

						if string.sub(var_437_1, 1, 4) == "=[A:" then
							return "valve"
						else
							return var_437_1, {
								latency = tostring(math.round(var_437_0:get_latency() * 1000))
							}
						end
					else
						return "local"
					end
				else
					return "lobby"
				end

				return "local"
			end, function(arg_438_0, arg_438_1)
				if arg_438_1 and type(arg_438_1) == "table" then
					local var_438_0 = slot_0_12_0(145, 164, 255, 255)

					slot_0_3_0.notify({
						{
							"Connected to: ",
							slot_0_6_0.white_color
						},
						{
							tostring(arg_438_0),
							var_438_0
						},
						lines = {
							"Latency: ",
							tostring(arg_438_1.latency),
							" ms"
						}
					}, {
						bonus_time = 5
					}, nil, "cloud")
				end

				slot_0_22_0.Post("/stats", "serverIP", {
					server_ip = arg_438_0
				})
			end)
		end,
		callback_online = function()
			slot_0_7_0.cycle(600, function()
				slot_0_22_0.Post("/stats", "update_online")
			end)
		end,
		steamID = function()
			local var_441_0 = entities.get_local_controller()

			if not var_441_0 then
				return
			end

			local var_441_1 = tostring(slot_0_28_0.get_steam_id(var_441_0))
			local var_441_2 = string.sub(var_441_1, 1, math.max(1, #var_441_1 - 3))

			slot_0_22_0.Post("/stats", "steamID", {
				steam_id = var_441_2
			})
		end
	}

	slot_0_7_0.wait_until(function()
		return slot_0_23_0.connect
	end, function()
		var_427_1:steamID()
		var_427_1:callback_kd()
		var_427_1:callback_server_ip()
		var_427_1:callback_online()
	end)
end

events.present_queue:add(slot_0_7_0.callback_decorator(function()
	slot_0_37_0()
end))
events.create_move:add(slot_0_7_0.callback_decorator(function(arg_445_0)
	slot_0_38_0(arg_445_0)
end))
events.override_view:add(slot_0_7_0.callback_decorator(function(arg_446_0)
	slot_0_39_0(arg_446_0)
end))
events.event:add(slot_0_7_0.callback_decorator(function(arg_447_0)
	slot_0_40_0(arg_447_0)
end))
slot_0_33_0:load_locations(" {\n    \"zl0sobhoRdNQqEDmwm\":{\n        \"from\":{\n            \"name\": \"from\",\n            \"eye_position\":[\n                -584.91998291016,\n                1864.2600097656,\n                -55.610000610352\n            ],\n            \"position\":[\n                -584.91998291016,\n                1864.2600097656,\n                -119.11000061035\n            ]\n        },\n        \"map\":\"de_dust2\",\n        \"to\":{\n            \"name\": \"to\",\n            \"radius\":23,\n            \"position\":[\n                -777.45001220703,\n                2193.0300292969,\n                -111.69999694824\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"isYs4fNLyPO5lMvKKR\":{\n        \"from\":{\n            \"name\":\"CT - stair\",\n            \"position\":[\n                -1589.9599609375,\n                -950.40997314453,\n                -191.80000305176\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"name\":\"Under window\",\n            \"radius\":19,\n            \"position\":[\n                -1018.8599853516,\n                -408.29000854492,\n                -342.33999633789\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"sA3c5ATcSjgofhU9rQ\":{\n        \"from\":{\n            \"name\":\"Short\",\n            \"position\":[\n                -757.04998779297,\n                199.57000732422,\n                -173.25\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"name\":\"Above B Stairs\",\n            \"radius\":19,\n            \"position\":[\n                -673.96002197266,\n                558.39001464844,\n                -81.889999389648\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"2jE87zVULTejcC6Ta1\":{\n        \"from\":{\n            \"name\":\"Short\",\n            \"position\":[\n                -1107.3699951172,\n                183.89999389648,\n                -172.38000488281\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"name\":\"B Apps\",\n            \"radius\":62,\n            \"position\":[\n                -1130.9000244141,\n                658.19000244141,\n                -79.970001220703\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"bq2Kq2h42KMOKjL6Va\":{\n        \"from\":{\n            \"name\":\"Corner\",\n            \"position\":[\n                -1423.7900390625,\n                407.33999633789,\n                -167.9700012207\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"radius\":43,\n            \"name\":\"Kitchen\",\n            \"position\":[\n                -2065.0500488281,\n                -515.22998046875,\n                -167.9700012207\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"xoF8k6vq3lLB7UaN0o\":{\n        \"from\":{\n            \"name\":\"Wine shop\",\n            \"position\":[\n                2569.7600097656,\n                1177.8699951172,\n                158.07000732422\n            ]\n        },\n        \"map\":\"de_inferno\",\n        \"to\":{\n            \"name\":\"A Long / Corner\",\n            \"position\":[\n                1406.6400146484,\n                919.41998291016,\n                150.16999816895\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"scout\",\n            \"awp\"\n        ]\n    },\n    \"DIf9a5VPwLoms3BC2D\":{\n        \"from\":{\n            \"name\":\"Under roof / parapet\",\n            \"position\":[\n                2130.0400390625,\n                -146.61000061035,\n                159.0299987793\n            ]\n        },\n        \"map\":\"de_inferno\",\n        \"to\":{\n            \"name\":\"Short corner\", \n            \"position\":[\n                1435.8800048828,\n                183,\n                131.82000732422\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"scout\",\n            \"revolver\"\n        ]\n    },\n    \"I5Ln6JY5DSWkhUwHyR\":{\n        \"from\":{\n            \"name\":\"Under roof / parapet\",\n            \"position\":[\n                2181.3200683594,\n                -255.35000610352,\n                131.0299987793\n            ]\n        },\n        \"map\":\"de_inferno\",\n        \"to\":{\n            \"name\":\"Short corner\", \n            \"position\":[\n                1436.1400146484,\n                182.64999389648,\n                131.83999633789\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"4f9bwxdtGZEyNAdtww\":{\n        \"from\":{\n            \"name\":\"Under roof / parapet\",\n            \"position\":[\n                2173.2600097656,\n                -154.67999267578,\n                159.0299987793\n            ]\n        },\n        \"map\":\"de_inferno\",\n        \"to\":{\n            \"name\":\"Apps\",\n            \"position\":[\n                1298.3499755859,\n                -325.73999023438,\n                260.0299987793\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"CYScunmvYs1sDFdWVG\":{\n        \"from\":{\n            \"name\":\"A Long\",\n            \"position\":[\n                2052.830078125,\n                1049.7399902344,\n                168.08999633789\n            ]\n        },\n        \"map\":\"de_inferno\",\n        \"to\":{\n            \"name\":\"Wine / CT\",\n            \"position\":[\n                2452.1398925781,\n                1417.6500244141,\n                157.7200012207\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"1J2QimGc87X7csLEXC\":{\n        \"from\":{\n            \"name\":\"Apps\", \n            \"position\":[\n                1137.3299560547,\n                -155.25999450684,\n                302.7799987793\n            ]\n        },\n        \"map\":\"de_inferno\",\n        \"to\":{\n            \"name\":\"A / Car\", \n            \"position\":[\n                2070.1899414063,\n                69.029998779297,\n                126.51999664307\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"0UoKi0tugChavBCehG\":{\n        \"from\":{\n            \"name\":\"Mid corner\",\n            \"position\":[\n                1253.1099853516,\n                585.91998291016,\n                125.0299987793\n            ]\n        },\n        \"map\":\"de_inferno\",\n        \"to\":{\n            \"name\":\"Mid corner\",\n            \"position\":[\n                946.75,\n                694.57000732422,\n                105.86000061035\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\",\n            \"revolver\"\n        ]\n    },\n    \"a0uXQyHwwVbomrTcBG\":{\n        \"from\":{\n            \"name\":\"CT Parapet\",\n            \"position\":[\n                2442.3100585938,\n                500.35998535156,\n                236.0299987793\n            ]\n        },\n        \"map\":\"de_inferno\",\n        \"to\":{\n            \"name\":\"Apps\",\n            \"position\":[\n                1238.8900146484,\n                -115.40000152588,\n                260.0299987793\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"BKbjvhZLwizmtBW2am\":{\n        \"from\":{\n            \"name\":\"B Box\",\n            \"position\":[\n                803.65002441406,\n                -1325.4599609375,\n                -765.96997070313\n            ]\n        },\n        \"map\":\"de_nuke\",\n        \"to\":{\n            \"name\":\"Secret\",\n            \"radius\":35,\n            \"position\":[\n                1548.6099853516,\n                -2083.7800292969,\n                -632\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"m5PHjo7xkDWlWUM6VB\":{\n        \"from\":{\n            \"name\":\"Dark\",\n            \"position\":[\n                935.77001953125,\n                -325.73001098633,\n                -767.96997070313\n            ]\n        },\n        \"map\":\"de_nuke\",\n        \"to\":{\n            \"name\":\"Doors\",\n            \"radius\":20,\n            \"position\":[\n                1054.3399658203,\n                -965.59002685547,\n                -767.46997070313\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"0f0wFMZPBiFopv14CK\":{\n        \"from\":{\n            \"name\":\"CT Wingman\",\n            \"position\":[\n                867.21997070313,\n                -14.470000267029,\n                -415.9700012207\n            ]\n        },\n        \"map\":\"de_nuke\",\n        \"to\":{\n            \"name\":\"B Plant\",\n            \"position\":[\n                849.25,\n                -1033.5,\n                -765.96997070313\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"LygHMGkQbYvIc2YE2D\":{\n        \"from\":{\n            \"name\":\"Window Right\",\n            \"position\":[\n                937.22998046875,\n                -265.26998901367,\n                -639.96997070313\n            ]\n        },\n        \"map\":\"de_nuke\",\n        \"to\":{\n            \"name\":\"Stairs\",\n            \"position\":[\n                1351.9300537109,\n                -803.65002441406,\n                -706.40002441406\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"KQROpJpDWPXmQrMSDq\":{\n        \"from\":{\n            \"name\":\"Dark\",\n            \"position\":[\n                843.46002197266,\n                -281.7200012207,\n                -767.96997070313\n            ]\n        },\n        \"map\":\"de_nuke\",\n        \"to\":{\n            \"name\":\"Ramp\",\n            \"radius\":240,\n            \"position\":[\n                607.17999267578,\n                70.980003356934,\n                -639.96997070313\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\",\n            \"revolver\"\n        ]\n    },\n    \"L20cav2VMKeFT3IJnU\":{\n        \"from\":{\n            \"name\":\"Ramp\",\n            \"position\":[\n                359.57998657227,\n                224.88999938965,\n                -415.9700012207\n            ]\n        },\n        \"map\":\"de_nuke\",\n        \"to\":{\n            \"name\":\"Con / B Plant\",\n            \"radius\":60,\n            \"position\":[\n                443.98999023438,\n                -1202.75,\n                -765.96997070313\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"6C2TbNQmR1ZD3UkjtR\":{\n        \"from\":{\n            \"name\":\"Ramp Left\",\n            \"position\":[\n                447.04998779297,\n                -40.740001678467,\n                -639.96997070313\n            ]\n        },\n        \"map\":\"de_nuke\",\n        \"to\":{\n            \"name\":\"Tunnel / Stairs\",\n            \"position\":[\n                1190.3299560547,\n                -1259.2399902344,\n                -648.46997070313\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"h4thSMrXcPErFYBX5J\":{\n        \"from\":{\n            \"name\":\"Mid - center\",\n            \"position\":[\n                -1517.9899902344,\n                -1432.0100097656,\n                -259.9700012207\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"name\":\"CT spawn\",\n            \"radius\":120,\n            \"position\":[\n                -502.67001342773,\n                -655.95001220703,\n                -273.13000488281\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\",\n            \"revolver\"\n        ]\n    },\n    \"Ibz6wp47zWp9Fl8e7h\":{\n        \"from\":{\n            \"name\":\"Connector\",\n            \"position\":[\n                -632.27001953125,\n                -799.38000488281,\n                -263.9700012207\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"name\":\"Pit\",\n            \"position\":[\n                684.67999267578,\n                -1625.9899902344,\n                -262.5299987793\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\",\n            \"revolver\"\n        ]\n    },\n    \"o1cunBp1O4XjRV0nRj\":{\n        \"from\":{\n            \"name\":\"B plant\",\n            \"position\":[\n                -1701.8699951172,\n                272.79998779297,\n                -167.92999267578\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"name\":\"Under\",\n            \"position\":[\n                -1011.3900146484,\n                -398.38000488281,\n                -336.76998901367\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\",\n            \"revolver\"\n        ]\n    },\n    \"T2CHU0oy6MAmaa373m\":{\n        \"from\":{\n            \"name\":\"Short\",\n            \"position\":[\n                -910.89001464844,\n                -100.48000335693,\n                -167.9700012207\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"name\":\"Under\",\n            \"radius\":50,\n            \"position\":[\n                -1002.5800170898,\n                274.39001464844,\n                -367.9700012207\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\",\n            \"revolver\"\n        ]\n    },\n    \"ENFyvagLvdhdcpDGIW\":{\n        \"from\":{ \n            \"name\":\"Connector\",\n            \"position\":[\n                -692.16998291016,\n                -806.66998291016,\n                -263.9700012207\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"name\":\"Vent / Window\",\n            \"radius\":100,\n            \"position\":[\n                -1237.7299804688,\n                -1030.0600585938,\n                -167.9700012207\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\",\n            \"revolver\"\n        ]\n    },\n    \"zOXuixxwDNaeZvG4tl\":{\n        \"from\":{\n            \"name\":\"Mid / box\",\n            \"position\":[\n                527.96002197266,\n                -518.82000732422,\n                -155.9700012207\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"name\":\"Pit arc\",\n            \"position\":[\n                545.36999511719,\n                -1639.9000244141,\n                -263.9700012207\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\",\n            \"revolver\"\n        ]\n    },\n    \"ai4KzlCktDCoVkqsqO\":{\n        \"from\":{\n            \"name\": \"Under window\",\n            \"position\":[\n                -1023.6599731445,\n                -285.32000732422,\n                -367.9700012207\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"name\": \"Pit\",\n            \"position\":[\n                664.5,\n                -1631.9899902344,\n                -261.08999633789\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\",\n            \"revolver\"\n        ]\n    },\n    \"tm6lJclD6pgTA0oMCn\":{\n        \"from\":{\n            \"name\":\"Under\",\n            \"position\":[\n                -977.48999023438,\n                -377.85000610352,\n                -347.04000854492\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"name\":\"B Stairs\",\n            \"position\":[\n                -240.67999267578,\n                517.94000244141,\n                -83.120002746582\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\",\n            \"revolver\"\n        ]\n    },\n    \"cX7ZKZVJLLQ6VOLjkv\":{\n        \"from\":{\n            \"name\":\"Pit\",\n            \"position\":[\n                564.90997314453,\n                -1710.8499755859,\n                -261.10998535156\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"name\":\"Ladder/Palace\",\n            \"position\":[\n                22.290000915527,\n                -2165.5900878906,\n                -39.970001220703\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\",\n            \"revolver\"\n        ]\n    },\n    \"ofruCDxr0ZtnFDjr6r\":{\n        \"from\":{\n            \"name\":\"Pit\",\n            \"position\":[\n                499.80999755859,\n                -1665.3399658203,\n                -261.86999511719\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"name\":\"Palace 1\",\n            \"radius\":140,\n            \"position\":[\n                415.95999145508,\n                -2266.7900390625,\n                -39.970001220703\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\",\n            \"revolver\"\n        ]\n    },\n    \"HShXNQvKfOEgQ5nBA3\":{\n        \"from\":{\n            \"name\":\"Pit\",\n            \"position\":[\n                429.5,\n                -1682.5699462891,\n                -226.71000671387\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"name\":\"T Palace\",\n            \"radius\":110,\n            \"position\":[\n                992.70001220703,\n                -1900.2900390625,\n                -71.970001220703\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"LkJFdplONHUvuPkIxX\":{\n        \"from\":{\n            \"name\": \"Pit\",\n            \"position\":[\n                423.20001220703,\n                -1524.8399658203,\n                -223.55999755859\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"name\": \"Connector\",\n            \"position\":[\n                -701.01000976563,\n                -738.22998046875,\n                -262.92001342773\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"pUctMsdQxHNZBtQkG5\":{\n        \"from\":{\n            \"name\":\"Chair\",\n            \"position\":[\n                -210.99000549316,\n                -910.04998779297,\n                -167.72999572754\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"name\":\"Connector\",\n            \"position\":[\n                -657.44000244141,\n                -840.10998535156,\n                -263.91000366211\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"IspaofZCdwytaM2w6s\":{\n        \"from\":{\n            \"name\":\"CT\",\n            \"position\":[\n                -1185.5300292969,\n                -2500.419921875,\n                -170.91000366211\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"name\":\"Pit\",\n            \"position\":[\n                570.59997558594,\n                -1714.25,\n                -260.08999633789\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"hke99axDkc67XW6wVn\":{\n        \"from\":{\n            \"name\":\"CT - stair\",\n            \"position\":[\n                -1590.4000244141,\n                -998.86999511719,\n                -205.17999267578\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"name\":\"Mid center\",\n            \"position\":[\n                -240.69000244141,\n                -672.85998535156,\n                -246.83999633789\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"bcp7SUvnGzg1bDkFZA\":{\n        \"from\":{\n            \"name\":\"A Window\",\n            \"position\":[\n                -1093.9899902344,\n                -631.58001708984,\n                -134.9700012207\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"name\":\"B apps window\",\n            \"position\":[\n                -1808.9599609375,\n                743.90002441406,\n                -47.970001220703\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"Qggj23MCnDPDMNQVV0\":{\n        \"from\":{\n            \"name\":\"B plant\",\n            \"position\":[\n                -1674.5100097656,\n                517.22998046875,\n                -168.11000061035\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"name\":\"Window\",\n            \"radius\":90,\n            \"position\":[\n                -1157.6199951172,\n                -779.72998046875,\n                -167.9700012207\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"WJXtxSUoL6owMfHEgt\":{\n        \"from\":{\n            \"name\":\"Arc\",\n            \"position\":[\n                -1444.7299804688,\n                244.0299987793,\n                -166.9700012207\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"name\":\"Window\",\n            \"radius\":75,\n            \"position\":[\n                -1629.7600097656,\n                747.91998291016,\n                -47.970001220703\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"YtyWbQDNLvycLGChQT\":{\n        \"from\":{\n            \"name\":\"Corner\",\n            \"position\":[\n                -1593.0699462891,\n                100.12000274658,\n                -167.99000549316\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"name\":\"Short\",\n            \"position\":[\n                -791.16998291016,\n                -41.639999389648,\n                -167.11999511719\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"6fhPfhSznTugspQE8j\":{\n        \"from\":{\n            \"name\":\"Ladder\",\n            \"eye_position\":[\n                148.49000549316,\n                -2071.2199707031,\n                5.8699998855591\n            ],\n            \"position\":[\n                148.49000549316,\n                -2071.2199707031,\n                -39.970001220703\n            ]\n        },\n        \"map\":\"de_mirage\",\n        \"to\":{\n            \"name\":\"Pit\",\n            \"position\":[\n                268.86999511719,\n                -1487.7299804688,\n                -175.9700012207\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"UXAPPslmyuj3EIE5tG\":{\n        \"from\":{\n            \"name\":\"Pit / B Ramp\",\n            \"position\":[\n                -1286.0500488281,\n                263.16000366211,\n                23.64999961853\n            ]\n        },\n        \"map\":\"de_overpass\",\n        \"to\":{\n            \"name\":\"Tracks\",\n            \"radius\":170,\n            \"position\":[\n                -465.76998901367,\n                -959.89001464844,\n                10.689999580383\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\",\n            \"revolver\"\n        ]\n    },\n    \"yP10v5BnI1BmGBp7kt\":{\n        \"from\":{\n            \"name\":\"Balcony\",\n            \"position\":[\n                -1829.5799560547,\n                413.41000366211,\n                301.0299987793\n            ]\n        },\n        \"map\":\"de_overpass\",\n        \"to\":{\n            \"name\":\"B Plant [R]\",\n            \"radius\":170,\n            \"position\":[\n                -1009.2899780273,\n                -149.36999511719,\n                103.5299987793\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\"\n        ]\n    },\n    \"nPWU39LTDcqquPLoVM\":{\n        \"from\":{\n            \"name\":\"Balcony\",\n            \"position\":[\n                -1830.2900390625,\n                410.70001220703,\n                301.0299987793\n            ]\n        },\n        \"map\":\"de_overpass\",\n        \"to\":{\n            \"name\":\"B Plant [L]\",\n            \"radius\":170,\n            \"position\":[\n                -870,\n                269.33999633789,\n                100.0299987793\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\"\n        ]\n    },\n    \"9OEypLRw8qKaCvys3Q\":{\n        \"from\":{\n            \"name\":\"Tracks\",\n            \"position\":[\n                -247.50999450684,\n                -1212.6400146484,\n                22.590000152588\n            ]\n        },\n        \"map\":\"de_overpass\",\n        \"to\":{\n            \"name\":\"Pit / B Ramp\",\n            \"position\":[\n                -1285.8699951172,\n                263.19000244141,\n                23.680000305176\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\",\n            \"revolver\"\n        ]\n    },\n    \"0JsKc0E7VOinpuZ6fM\":{\n        \"from\":{\n            \"name\":\"Tracks\",\n            \"position\":[\n                -174.83000183105,\n                -1010.0800170898,\n                29.059999465942\n            ]\n        },\n        \"map\":\"de_overpass\",\n        \"to\":{\n            \"name\":\"B Plant Box\",\n            \"radius\":58,\n            \"position\":[\n                -1224.8100585938,\n                -79.690002441406,\n                198.0299987793\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\",\n            \"revolver\"\n        ]\n    },\n    \"e9WRRW9qwCY3ufhcF8\":{\n        \"from\":{\n            \"name\":\"Canal\",\n            \"position\":[\n                -587.96997070313,\n                -148.10000610352,\n                16.790000915527\n            ]\n        },\n        \"map\":\"de_overpass\",\n        \"to\":{\n            \"name\":\"Short\",\n            \"radius\":170,\n            \"position\":[\n                -1021.4799804688,\n                -494.23999023438,\n                100.0299987793\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\",\n            \"revolver\"\n        ]\n    },\n    \"Uv6X1Glyn2b4xeeibE\":{\n        \"from\":{\n            \"name\":\"Water\",\n            \"position\":[\n                -1365.2399902344,\n                -622.66998291016,\n                5.8499999046326\n            ]\n        },\n        \"map\":\"de_overpass\",\n        \"to\":{\n            \"name\":\"Pillar / Canal\",\n            \"position\":[\n                -841.02001953125,\n                -120.12999725342,\n                100.0299987793\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"gvvn2dn69sEgHwUwf0\":{\n        \"from\":{\n            \"name\":\"Monster\",\n            \"position\":[\n                -557.34002685547,\n                -461.95001220703,\n                17.60000038147\n            ]\n        },\n        \"map\":\"de_overpass\",\n        \"to\":{\n            \"name\":\"Barrels\",\n            \"position\":[\n                -799.01000976563,\n                393.91000366211,\n                100.0299987793\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\",\n            \"revolver\"\n        ]\n    },\n    \"bR0bOIoqwZ4Kav5xX4\":{\n        \"from\":{\n            \"name\": \"Balcony\",\n            \"position\":[\n                -1910.0999755859,\n                451.26998901367,\n                260.0299987793\n            ]\n        },\n        \"map\":\"de_overpass\",\n        \"to\":{\n            \"name\": \"Walkway\",\n            \"radius\":115,\n            \"position\":[\n                -1886.25,\n                -35.970001220703,\n                132.0299987793\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"48SqphELMVzpl5twDW\":{\n        \"from\":{\n            \"name\":\"Pit\",\n            \"position\":[\n                -1288.1199951172,\n                248.69000244141,\n                25.379999160767\n            ]\n        },\n        \"map\":\"de_overpass\",\n        \"to\":{\n            \"name\":\"Pillar\",\n            \"radius\":144,\n            \"position\":[\n                -796.66998291016,\n                11.659999847412,\n                90.370002746582\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"qPDTtMLkOxMx5FxhSP\":{\n        \"from\":{\n            \"name\":\"T Stairs\",\n            \"position\":[\n                -1031.7700195313,\n                -2100.0400390625,\n                340.0299987793\n            ]\n        },\n        \"map\":\"de_overpass\",\n        \"to\":{ \n            \"name\":\"B Balcony\",\n            \"position\":[\n                -1717.3199462891,\n                471.66000366211,\n                260.0299987793\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"KtBXXUXHCcRlTZA7vK\":{\n        \"from\":{\n            \"name\":\"Water\",\n            \"position\":[\n                -1241.1500244141,\n                -627.11999511719,\n                37.299999237061\n            ]\n        },\n        \"map\":\"de_overpass\",\n        \"to\":{\n            \"name\":\"Alley Stairs\",\n            \"position\":[\n                -595.83001708984,\n                -1366.9000244141,\n                148.25\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"UUMQQlG7xBo5c4cLgm\":{\n        \"from\":{\n            \"name\":\"Elevator\",\n            \"position\":[\n                -1008.1900024414,\n                -173.58999633789,\n                11776.030273438\n            ]\n        },\n        \"map\":\"de_vertigo\",\n        \"to\":{\n            \"name\":\"Bridge\",\n            \"radius\":138,\n            \"position\":[\n                -1342.1500244141,\n                -110.66999816895,\n                11488.030273438\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"G5T2AQ2uLfqC0ZvTA3\":{\n        \"from\":{\n            \"name\":\"Mid\",\n            \"position\":[\n                -1663.3900146484,\n                -210.2200012207,\n                11776.030273438\n            ]\n        },\n        \"map\":\"de_vertigo\",\n        \"to\":{\n            \"name\":\"T Tunnel\",\n            \"radius\":29,\n            \"position\":[\n                -1554.0799560547,\n                -505.83999633789,\n                11488.030273438\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"stLKplT0FHQ3no8zLj\":{\n        \"from\":{\n            \"name\":\"Mid\",\n            \"position\":[\n                -1625.9799804688,\n                249.80000305176,\n                11776.030273438\n            ]\n        },\n        \"map\":\"de_vertigo\",\n        \"to\":{\n            \"name\":\"B Stairs\",\n            \"position\":[\n                -2404.7700195313,\n                265.5299987793,\n                11744.030273438\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"zJ1V6qGvXSjsvjuGyL\":{\n        \"from\":{\n            \"name\":\"T Arc\",\n            \"position\":[\n                -1678.0200195313,\n                -797.59997558594,\n                11488.030273438\n            ]\n        },\n        \"map\":\"de_vertigo\",\n        \"to\":{\n            \"name\":\"Mid\",\n            \"position\":[\n                -1647.6700439453,\n                -179.13999938965,\n                11776.030273438\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"9LvT1JpYng25rNoexP\":{\n        \"from\":{\n            \"name\":\"Elevator\",\n            \"position\":[\n                -976.98999023438,\n                -438.29000854492,\n                11777.030273438\n            ]\n        },\n        \"map\":\"de_vertigo\",\n        \"to\":{\n            \"name\":\"T Mid\",\n            \"position\":[\n                -1340.9000244141,\n                -474.55999755859,\n                11776.030273438\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"XoU8u9DuV4qD5cFnVp\":{\n        \"from\":{\n            \"name\":\"Ladder\",\n            \"position\":[\n                -1336.7900390625,\n                -714.92999267578,\n                11776.030273438\n            ]\n        },\n        \"map\":\"de_vertigo\",\n        \"to\":{\n            \"name\":\"Box / Short\",\n            \"position\":[\n                -828.35998535156,\n                -611.46002197266,\n                11776.030273438\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"WarW4DcX7Vdm4kqwrI\":{\n        \"from\":{\n            \"name\":\"50 [OW]\",\n            \"position\":[\n                -591.80999755859,\n                -297.95999145508,\n                11488.030273438\n            ]\n        },\n        \"map\":\"de_vertigo\",\n        \"to\":{\n            \"name\":\"Ramp A\",\n            \"radius\":40,\n            \"position\":[\n                -438.92999267578,\n                -1211.7900390625,\n                11720.389648438\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"xkv6tHPMf0aHTnKGvu\":{\n        \"from\":{\n            \"name\":\"Bridge\",\n            \"position\":[\n                -954.03997802734,\n                -96.940002441406,\n                11488.030273438\n            ]\n        },\n        \"map\":\"de_vertigo\",\n        \"to\":{\n            \"name\":\"CT Mid\",\n            \"radius\":56,\n            \"position\":[\n                -993.47998046875,\n                145.11000061035,\n                11776.030273438\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"8wPLHcQ8oULWB1NNZw\":{\n        \"from\":{\n            \"name\":\"T Mid\",\n            \"position\":[\n                -1444.8299560547,\n                -330.54000854492,\n                11776.030273438\n            ]\n        },\n        \"map\":\"de_vertigo\",\n        \"to\":{\n            \"name\":\"Box / Bridge\",\n            \"radius\":90,\n            \"position\":[\n                -826.15002441406,\n                -202.19000244141,\n                11488.030273438\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"ZrvOf843NiHiw70nIP\":{\n        \"from\":{\n            \"name\":\"CT Mid\",\n            \"position\":[\n                -1074.2600097656,\n                139.0299987793,\n                11776.030273438\n            ]\n        },\n        \"map\":\"de_vertigo\",\n        \"to\":{\n            \"name\":\"T Mid\",\n            \"radius\":90,\n            \"position\":[\n                -1683.4000244141,\n                -462.58999633789,\n                11776.030273438\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"jO4zkPPlYtzccIu8cV\":{\n        \"from\":{\n            \"name\":\"Short\",\n            \"position\":[\n                -1113.3800048828,\n                -742.29998779297,\n                11776.030273438\n            ]\n        },\n        \"map\":\"de_vertigo\",\n        \"to\":{\n            \"name\":\"T Arc\",\n            \"radius\":62,\n            \"position\":[\n                -1667.8199462891,\n                -840.59997558594,\n                11488.030273438\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"6JgJiPu7XocxIsYgLt\":{\n        \"from\":{\n            \"name\":\"Back door\", \n            \"position\":[\n                -719.96997070313,\n                130.83999633789,\n                11776.030273438\n            ]\n        },\n        \"map\":\"de_vertigo\",\n        \"to\":{\n            \"name\":\"Full Mid\", \n            \"radius\":170,\n            \"position\":[\n                -1830.3900146484,\n                302.14001464844,\n                11776.030273438\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"VFztczbNGBDRjcogaX\":{\n        \"from\":{\n            \"name\":\"Mid\",\n            \"position\":[\n                -1961.5600585938,\n                127.30999755859,\n                11776.030273438\n            ]\n        },\n        \"map\":\"de_vertigo\",\n        \"to\":{\n            \"name\":\"Lower B\",\n            \"radius\":90,\n            \"position\":[\n                -2079.1499023438,\n                0.76999998092651,\n                11552.030273438\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"FPMqDGGShJKXFFobQ7\":{\n        \"from\":{\n            \"name\":\"Short stairs\",\n            \"position\":[\n                308.83999633789,\n                1683.5899658203,\n                46.549999237061\n            ]\n        },\n        \"map\":\"de_dust2\",\n        \"to\":{\n            \"name\":\"CT\",\n            \"radius\":90,\n            \"position\":[\n                -173.00999450684,\n                2135.1298828125,\n                -126.55000305176\n            ]\n        },\n        \"reverse\":false,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"hFhBnBH0RkzS5qTNuC\":{\n        \"from\":{\n            \"name\":\"Mid corner\",\n            \"position\":[\n                1275.1300048828,\n                1279.5,\n                0.28000000119209\n            ]\n        },\n        \"map\":\"de_dust2\",\n        \"to\":{\n            \"name\":\"Box / Door\",\n            \"radius\":34,\n            \"position\":[\n                622.76000976563,\n                733.55999755859,\n                0.93000000715256\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"7LqULbCNzVuuHnTsbz\":{\n        \"from\":{\n            \"name\":\"Parapet\",\n            \"position\":[\n                816.42999267578,\n                2423.1999511719,\n                127.05999755859\n            ]\n        },\n        \"map\":\"de_dust2\",\n        \"to\":{\n            \"name\":\"CT spawn\",\n            \"radius\":14,\n            \"position\":[\n                266.86999511719,\n                2422.3601074219,\n                -121.18000030518\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"WWzdnefzZmvkYnVFdc\":{\n        \"from\":{\n            \"name\":\"CT\",\n            \"position\":[\n                -273.32998657227,\n                2071.8999023438,\n                -127.41999816895\n            ]\n        },\n        \"map\":\"de_dust2\",\n        \"to\":{\n            \"name\":\"Short stairs\",\n            \"radius\":23,\n            \"position\":[\n                314.7200012207,\n                1682.4100341797,\n                45.830001831055\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"IYXQuwdBaDqSfnC14v\":{\n        \"from\":{\n            \"name\":\"Box\",\n            \"position\":[\n                624.55999755859,\n                473.11999511719,\n                1.0599999427795\n            ]\n        },\n        \"map\":\"de_dust2\",\n        \"to\":{\n            \"name\":\"Top mid\",\n            \"radius\":38,\n            \"position\":[\n                -379.20999145508,\n                389.58999633789,\n                -4.0199999809265\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    },\n    \"L0xXJB4BAK5GQsZIgV\":{\n        \"from\":{\n            \"name\":\"Box corner\",\n            \"position\":[\n                564.82000732422,\n                349.39999389648,\n                1.4299999475479\n            ]\n        },\n        \"map\":\"de_dust2\",\n        \"to\":{\n            \"name\":\"Boxes\",\n            \"radius\":38,\n            \"position\":[\n                222.08999633789,\n                7.6599998474121,\n                6.8000001907349\n            ]\n        },\n        \"reverse\":true,\n        \"weapon\":[\n            \"awp\",\n            \"auto\",\n            \"scout\"\n        ]\n    }\n}")
